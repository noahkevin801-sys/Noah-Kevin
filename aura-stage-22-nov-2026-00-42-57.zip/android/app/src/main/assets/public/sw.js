/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-5d155c7a'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "54830639981b50940ccc7dbc7ec1c7cc"
  }, {
    "url": "pwa-512x512.png",
    "revision": "646d5be5cf4301bff68fa97a5a962194"
  }, {
    "url": "pwa-192x192.png",
    "revision": "affed54540a880894e48c549989b36d3"
  }, {
    "url": "index.html",
    "revision": "cfe75082692383aa5b75ba496d2f6412"
  }, {
    "url": "icon.svg",
    "revision": "52d0593bc07e12968f9213672ee0ebc1"
  }, {
    "url": "icon-maskable.svg",
    "revision": "849180e823cdaa1f443f8f54cc21c8a5"
  }, {
    "url": "favicon.ico",
    "revision": "c6f532ebd4fa511629f32c57a438726f"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "b95dabcde8d3a6b0511d43565b142899"
  }, {
    "url": "assets/index-eF-Mz6Gk.css",
    "revision": null
  }, {
    "url": "assets/index-DzrftR4u.js",
    "revision": null
  }, {
    "url": "assets/aistudio/Canvas__20__a80a59c2.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Canvas__19__e7de920c.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Canvas__18__a0bbebd6.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Canvas__17__d84626b6.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Canvas__16__71c16176.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Canvas__15__a182916b.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Canvas__12__74f785c3.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "b95dabcde8d3a6b0511d43565b142899"
  }, {
    "url": "favicon.ico",
    "revision": "c6f532ebd4fa511629f32c57a438726f"
  }, {
    "url": "icon.svg",
    "revision": "52d0593bc07e12968f9213672ee0ebc1"
  }, {
    "url": "pwa-192x192.png",
    "revision": "affed54540a880894e48c549989b36d3"
  }, {
    "url": "pwa-512x512.png",
    "revision": "646d5be5cf4301bff68fa97a5a962194"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "54830639981b50940ccc7dbc7ec1c7cc"
  }, {
    "url": "manifest.webmanifest",
    "revision": "a939ba67b89d4960340398c1ef80d3db"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html"), {
    denylist: [/^\/api/, /^\/ws/]
  }));
  workbox.registerRoute(/^https:\/\/fonts\.(?:googleapis|gstatic)\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "allstarz-google-fonts",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 16,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^\/api\/world\/init$/, new workbox.NetworkFirst({
    "cacheName": "allstarz-world-snapshot",
    "networkTimeoutSeconds": 4,
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 4,
      maxAgeSeconds: 86400
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
