import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Home,
  Mic,
  BarChart3,
  Smartphone,
  MessageCircle,
  Settings,
} from 'lucide-react';
import {
  AppSubId,
  ArtistSkills,
  EventChoice,
  GameState,
  GenreId,
  NotificationItem,
  OriginId,
  ProjectFormat,
  TabId,
} from './types/game';
import {
  ServerWsEvent,
  SharedChatMessage,
  SharedComment,
  SharedSocialPost,
  SocialPlatform,
  WorldSnapshot,
} from './types/network';
import {
  addTourDate,
  advanceSingleDay,
  advanceSingleWeek,
  applyEventChoice,
  claimMissionReward,
  completeAndArchiveTour,
  createCustomTour,
  createInitialGameState,
  createMusicVideoForSong,
  hireStaffMember,
  moveTourDate,
  performConcertShow,
  playTourDateById,
  postponeTourDate,
  promoteReleasedSong,
  publishAllTubVlog,
  publishBuzzPost,
  recordNewSong,
  releaseProjectFromVault,
  releaseSongWithPromo,
  removeTourDate,
  reorderTourDates,
  signLabelContract,
  startOrOpenChatThread,
  trainArtistSkill,
  unlockMerchItem,
  updateArtistProfile,
  updateCustomTourSettings,
  updateTourDate,
} from './engine/simulation';
import {
  generateOfflineAiChatReply,
  generateOfflineAiSocialPost,
} from './engine/offlineAi';
import {
  applyOfflineAiComment,
  createPostHttp,
  fetchWorldSnapshot,
  getOrCreatePlayerId,
  getWsUrl,
  loadCachedWorld,
  mergeWsEventIntoWorld,
  requestAiChatReply,
  requestAiSocialReact,
  saveCachedWorld,
  sendPresenceHttp,
} from './services/realtimeClient';
import { formatShortDate } from './utils/format';
import { LiquidBackground } from './components/LiquidBackground';
import { ArtistOnboarding } from './components/ArtistOnboarding';
import { CareerHomeView } from './components/CareerHomeView';
import { MusicCenterView } from './components/MusicCenterView';
import { ChartsView } from './components/ChartsView';
import { AppsHubView } from './components/AppsHubView';
import { ChatView } from './components/ChatView';
import { SettingsView } from './components/SettingsView';
import { RandomEventModal } from './components/RandomEventModal';
import { NotificationsDrawer } from './components/NotificationsDrawer';
import {
  CertificationMilestone,
  CertificationRevealOverlay,
  extractCertifiedMilestones,
  loadSeenCertificationKeys,
  markCertificationKeysSeen,
  resetSeenCertificationKeys,
} from './components/PalmaresBadges';
import { OfflineIndicator } from './components/OfflineIndicator';
import { soundEngine } from './utils/audio';

const STORAGE_KEY = 'all_starz_save_v3';
const THEME_KEY = 'all_starz_theme';
const OFFLINE_MODE_KEY = 'all_starz_offline_ai_v1';

const CENTER_DOCK_TABS: Array<{
  id: Extract<TabId, 'accueil' | 'music' | 'charts' | 'apps'>;
  label: string;
  Icon: React.FC<{ className?: string }>;
}> = [
  { id: 'accueil', label: 'Accueil', Icon: Home },
  { id: 'music', label: 'Music', Icon: Mic },
  { id: 'charts', label: 'Charts', Icon: BarChart3 },
  { id: 'apps', label: 'Apps', Icon: Smartphone },
];

function makeHandle(stageName: string): string {
  return `@${stageName.toLowerCase().replace(/[^a-z0-9]/g, '') || 'artiste'}`;
}

export default function App() {
  const playerId = useMemo(() => getOrCreatePlayerId(), []);

  const [gameState, setGameState] = useState<GameState | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved) as GameState;
        if (parsed && parsed.version === 3 && parsed.artist) {
          return parsed;
        }
      }
    } catch {
      return null;
    }
    return null;
  });

  const [world, setWorld] = useState<WorldSnapshot>(() => loadCachedWorld());
  const [wsConnected, setWsConnected] = useState(false);
  const [isBrowserOnline, setIsBrowserOnline] = useState(() =>
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [forceOfflineAi, setForceOfflineAi] = useState<boolean>(() => {
    try {
      return localStorage.getItem(OFFLINE_MODE_KEY) === 'true';
    } catch {
      return false;
    }
  });
  const [isSendingAi, setIsSendingAi] = useState(false);

  const wsRef = useRef<WebSocket | null>(null);

  const [activeTab, setActiveTab] = useState<TabId>('accueil');
  const [activeApp, setActiveApp] = useState<AppSubId>('home');
  const [isDark, setIsDark] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem(THEME_KEY);
      return stored ? stored === 'dark' : true;
    } catch {
      return true;
    }
  });
  const [isMuted, setIsMuted] = useState(false);
  const [showNotifs, setShowNotifs] = useState(false);
  const [showResetModal, setShowResetModal] = useState(false);
  const [eventToast, setEventToast] = useState<{
    title: string;
    outcome: string;
  } | null>(null);
  const [recentCertKeys, setRecentCertKeys] = useState<string[]>([]);
  const [certRevealQueue, setCertRevealQueue] = useState<CertificationMilestone[]>([]);

  const isOfflineMode = forceOfflineAi || !isBrowserOnline || !wsConnected;

  // Browser online/offline listener
  useEffect(() => {
    const onOnline = () => setIsBrowserOnline(true);
    const onOffline = () => setIsBrowserOnline(false);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(OFFLINE_MODE_KEY, String(forceOfflineAi));
    } catch {
      // ignore
    }
  }, [forceOfflineAi]);

  // Persist world snapshot locally so Offline mode keeps every post & message
  useEffect(() => {
    saveCachedWorld(world);
  }, [world]);

  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    try {
      localStorage.setItem(THEME_KEY, isDark ? 'dark' : 'light');
    } catch {
      // ignore
    }
  }, [isDark]);

  useEffect(() => {
    if (!gameState) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(gameState));
    } catch {
      // ignore
    }

    const milestones = extractCertifiedMilestones(gameState);
    const seen = new Set(loadSeenCertificationKeys());
    const newlyUnlocked = milestones.filter((m) => !seen.has(m.key));
    if (newlyUnlocked.length > 0) {
      const freshKeys = newlyUnlocked.map((m) => m.key);
      markCertificationKeysSeen(freshKeys);
      setRecentCertKeys((prev) => Array.from(new Set([...prev, ...freshKeys])));
      setCertRevealQueue((prev) => {
        const existingKeys = new Set(prev.map((x) => x.key));
        const toAdd = newlyUnlocked.filter((m) => !existingKeys.has(m.key));
        return [...prev, ...toAdd];
      });
      soundEngine.playSuccessChord();
    }
  }, [gameState]);

  const topSongTitle = useMemo(() => {
    if (!gameState) return undefined;
    const released = gameState.songs.filter((s) => s.released);
    return [...released].sort((a, b) => b.totalStreams - a.totalStreams)[0]?.title;
  }, [gameState]);

  const sendPresence = useCallback(
    (ws?: WebSocket | null) => {
      if (!gameState) return;
      const { artist } = gameState;
      const payload = {
        playerId,
        stageName: artist.stageName,
        handle: makeHandle(artist.stageName),
        genre: artist.genre,
        avatarUrl: artist.avatarUrl,
        fans: artist.fans,
        monthlyListeners: artist.monthlyListeners,
        totalStreams: artist.totalStreams,
        fame: artist.fame,
        hype: artist.hype,
        topSongTitle,
      };
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'player:presence', payload }));
      } else if (!forceOfflineAi && isBrowserOnline) {
        sendPresenceHttp(playerId, artist, topSongTitle).catch(() => undefined);
      }
    },
    [gameState, playerId, topSongTitle, forceOfflineAi, isBrowserOnline]
  );

  // Real-time WebSocket connection + HTTP snapshot fallback + auto-reconnect
  useEffect(() => {
    if (!gameState || forceOfflineAi || !isBrowserOnline) {
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
      setWsConnected(false);
      return;
    }

    let cancelled = false;
    let reconnectTimer: number | null = null;

    fetchWorldSnapshot()
      .then((snap) => {
        if (!cancelled) setWorld(snap);
      })
      .catch(() => undefined);

    const connect = () => {
      if (cancelled) return;
      const wsUrl = getWsUrl();
      if (!wsUrl) {
        setWsConnected(false);
        return;
      }
      try {
        const socket = new WebSocket(wsUrl);
        wsRef.current = socket;

        socket.addEventListener('open', () => {
          if (cancelled) return;
          setWsConnected(true);
          sendPresence(socket);
        });

        socket.addEventListener('message', (evt) => {
          try {
            const parsed = JSON.parse(evt.data as string) as ServerWsEvent;
            setWorld((prev) => mergeWsEventIntoWorld(prev, parsed));
          } catch {
            // ignore malformed frame
          }
        });

        socket.addEventListener('close', () => {
          if (wsRef.current === socket) wsRef.current = null;
          setWsConnected(false);
          if (!cancelled) {
            reconnectTimer = window.setTimeout(connect, 4000);
          }
        });

        socket.addEventListener('error', () => {
          setWsConnected(false);
        });
      } catch {
        setWsConnected(false);
      }
    };

    connect();

    return () => {
      cancelled = true;
      if (reconnectTimer !== null) window.clearTimeout(reconnectTimer);
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
      setWsConnected(false);
    };
  }, [Boolean(gameState), forceOfflineAi, isBrowserOnline]);

  // Keep player presence synced when artist stats/name change
  useEffect(() => {
    if (!gameState || isOfflineMode) return;
    sendPresence(wsRef.current);
  }, [
    gameState?.artist.stageName,
    gameState?.artist.fans,
    gameState?.artist.monthlyListeners,
    gameState?.artist.totalStreams,
    gameState?.artist.fame,
    gameState?.artist.hype,
    topSongTitle,
    isOfflineMode,
    sendPresence,
  ]);

  const navigateTo = (tab: TabId, app?: AppSubId) => {
    setActiveTab(tab);
    if (tab === 'apps') {
      setActiveApp(app ?? 'home');
    }
  };

  const handleStartCareer = (params: {
    stageName: string;
    genre: GenreId;
    origin: OriginId;
    avatarUrl: string;
  }) => {
    const fresh = createInitialGameState(params);
    setGameState(fresh);
    setActiveTab('accueil');
    setActiveApp('home');
    setEventToast(null);
  };

  const handleAdvanceDay = () => {
    if (!gameState) return;
    const next = advanceSingleDay(gameState);
    if (next.pendingEvent) {
      soundEngine.playAlertTone();
    }
    setGameState(next);
  };

  const handleAdvanceWeek = () => {
    if (!gameState) return;
    const next = advanceSingleWeek(gameState);
    if (next.pendingEvent) {
      soundEngine.playAlertTone();
    }
    setGameState(next);
    // In Offline AI mode, generate a fresh AI social post each week so feeds stay alive
    if (isOfflineMode) {
      const platforms: SocialPlatform[] = ['allgram', 'alltok', 'allx', 'alltub', 'allcloud'];
      const pick = platforms[Math.floor(Math.random() * platforms.length)];
      const aiPost = generateOfflineAiSocialPost(pick);
      setWorld((prev) => ({
        ...prev,
        posts: [aiPost, ...prev.posts].slice(0, 120),
      }));
    }
  };

  const handleResolveEvent = (choice: EventChoice) => {
    if (!gameState || !gameState.pendingEvent) return;
    const evtTitle = gameState.pendingEvent.title;
    const next = applyEventChoice(gameState, choice);
    setGameState(next);
    setEventToast({ title: evtTitle, outcome: choice.outcomeText });
  };

  const handleSelectNotification = (notif: NotificationItem) => {
    if (!gameState) return;
    setGameState({
      ...gameState,
      notifications: gameState.notifications.map((n) =>
        n.id === notif.id ? { ...n, read: true } : n
      ),
    });
    setShowNotifs(false);
    navigateTo(notif.targetTab, notif.targetApp);
  };

  const handleImportSave = (jsonStr: string): boolean => {
    try {
      const parsed = JSON.parse(jsonStr) as GameState;
      if (parsed && parsed.artist && Array.isArray(parsed.songs)) {
        setGameState({ ...parsed, version: 3 });
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const handleResetConfirm = () => {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // ignore
    }
    resetSeenCertificationKeys();
    setRecentCertKeys([]);
    setCertRevealQueue([]);
    setGameState(null);
    setShowResetModal(false);
    setEventToast(null);
  };

  const toggleMute = () => {
    const nextMute = !isMuted;
    setIsMuted(nextMute);
    soundEngine.setMuted(nextMute);
  };

  // ============================================================================
  // SHARED SOCIAL NETWORKS HANDLERS (Live WebSocket Server + Offline AI)
  // ============================================================================
  const handleCreateSharedPost = useCallback(
    (params: {
      platform: SocialPlatform;
      content: string;
      title?: string;
      location?: string;
      tag?: string;
      mediaTone?: string;
      attachedSongTitle?: string;
      videoDuration?: string;
    }) => {
      if (!gameState) return;
      const { artist } = gameState;
      const handle = makeHandle(artist.stageName);
      const id = `post_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;

      const postPayload = {
        id,
        platform: params.platform,
        authorId: playerId,
        authorName: artist.stageName,
        authorHandle: handle,
        authorAvatar: artist.avatarUrl,
        verified: artist.fans >= 10000,
        location: params.location,
        tag: params.tag,
        title: params.title,
        content: params.content,
        mediaTone: params.mediaTone || 'from-violet-600/80 via-indigo-700/80 to-slate-900',
        attachedSongTitle: params.attachedSongTitle,
        videoDuration: params.videoDuration,
        initialLikes: Math.max(1, Math.round(artist.fans * 0.02)),
      };

      const optimisticPost: SharedSocialPost = {
        ...postPayload,
        isPlayer: true,
        likes: postPayload.initialLikes,
        likedByIds: [],
        reposts: 0,
        repostedByIds: [],
        views: postPayload.initialLikes * 12,
        comments: [],
        createdAt: Date.now(),
      };

      // Update career simulation (fans + hype)
      setGameState((prev) => (prev ? publishBuzzPost(prev, params.content || params.title || '') : prev));

      if (!isOfflineMode && wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ type: 'social:create', payload: postPayload }));
        setWorld((prev) =>
          prev.posts.some((p) => p.id === id)
            ? prev
            : { ...prev, posts: [optimisticPost, ...prev.posts].slice(0, 120) }
        );
      } else if (!forceOfflineAi && isBrowserOnline) {
        setWorld((prev) => ({ ...prev, posts: [optimisticPost, ...prev.posts].slice(0, 120) }));
        createPostHttp(postPayload).catch(() => undefined);
      } else {
        // Offline AI: add post + generate an instant AI fan/media comment!
        setWorld((prev) => {
          const withPost: WorldSnapshot = {
            ...prev,
            posts: [optimisticPost, ...prev.posts].slice(0, 120),
          };
          return applyOfflineAiComment(withPost, id, artist.stageName);
        });
      }
    },
    [gameState, playerId, isOfflineMode, forceOfflineAi, isBrowserOnline]
  );

  const handleToggleSharedLike = useCallback(
    (postId: string) => {
      setWorld((prev) => ({
        ...prev,
        posts: prev.posts.map((p) => {
          if (p.id !== postId) return p;
          const already = p.likedByIds.includes(playerId);
          return {
            ...p,
            likedByIds: already
              ? p.likedByIds.filter((x) => x !== playerId)
              : [...p.likedByIds, playerId],
            likes: Math.max(0, p.likes + (already ? -1 : 1)),
          };
        }),
      }));
      if (!isOfflineMode && wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(
          JSON.stringify({ type: 'social:like', payload: { postId, playerId } })
        );
      }
    },
    [playerId, isOfflineMode]
  );

  const handleToggleSharedRepost = useCallback(
    (postId: string) => {
      setWorld((prev) => ({
        ...prev,
        posts: prev.posts.map((p) => {
          if (p.id !== postId) return p;
          const already = p.repostedByIds.includes(playerId);
          return {
            ...p,
            repostedByIds: already
              ? p.repostedByIds.filter((x) => x !== playerId)
              : [...p.repostedByIds, playerId],
            reposts: Math.max(0, p.reposts + (already ? -1 : 1)),
          };
        }),
      }));
      if (!isOfflineMode && wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(
          JSON.stringify({ type: 'social:repost', payload: { postId, playerId } })
        );
      }
    },
    [playerId, isOfflineMode]
  );

  const handleAddSharedComment = useCallback(
    (postId: string, text: string) => {
      if (!gameState) return;
      const { artist } = gameState;
      const commentId = `cmt_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
      const cmt: SharedComment = {
        id: commentId,
        authorId: playerId,
        authorName: artist.stageName,
        authorHandle: makeHandle(artist.stageName),
        authorAvatar: artist.avatarUrl,
        text,
        createdAt: Date.now(),
      };

      setWorld((prev) => ({
        ...prev,
        posts: prev.posts.map((p) =>
          p.id === postId ? { ...p, comments: [...p.comments, cmt].slice(-40) } : p
        ),
      }));

      if (!isOfflineMode && wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(
          JSON.stringify({
            type: 'social:comment',
            payload: {
              postId,
              commentId,
              authorId: playerId,
              authorName: artist.stageName,
              authorHandle: makeHandle(artist.stageName),
              authorAvatar: artist.avatarUrl,
              text,
            },
          })
        );
      }
    },
    [gameState, playerId, isOfflineMode]
  );

  const handleAskAiReact = useCallback(
    async (postId: string) => {
      if (!gameState) return;
      if (!isOfflineMode) {
        const updated = await requestAiSocialReact(postId);
        if (updated) {
          setWorld((prev) => ({
            ...prev,
            posts: prev.posts.map((p) => (p.id === postId ? updated : p)),
          }));
          soundEngine.playSuccessChord();
          return;
        }
      }
      setWorld((prev) => applyOfflineAiComment(prev, postId, gameState.artist.stageName));
      soundEngine.playSuccessChord();
    },
    [gameState, isOfflineMode]
  );

  // ============================================================================
  // MULTIPLAYER CHAT & AI CHAT HANDLERS
  // ============================================================================
  const handleSendRoomOrDmMessage = useCallback(
    (roomId: string, text: string) => {
      if (!gameState) return;
      const { artist } = gameState;
      const msgId = `msg_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      const msg: SharedChatMessage = {
        id: msgId,
        roomId,
        senderId: playerId,
        senderName: artist.stageName,
        senderHandle: makeHandle(artist.stageName),
        senderAvatar: artist.avatarUrl,
        text,
        createdAt: Date.now(),
      };

      setWorld((prev) => ({
        ...prev,
        chatMessages: [...prev.chatMessages, msg].slice(-250),
      }));

      if (!isOfflineMode && wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ type: 'chat:send', payload: msg }));
      } else {
        // Offline AI auto-reply in salons / DMs when server is offline
        const replyText = generateOfflineAiChatReply(roomId, text, gameState);
        const aiReply: SharedChatMessage = {
          id: `msg_ai_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
          roomId,
          senderId: 'ai_offline',
          senderName: 'IA Réseau Artistes',
          senderHandle: '@allstarz_ia',
          senderAvatar: '/src/assets/images/artist_portrait_urban_1795252245054.jpg',
          isAi: true,
          text: replyText,
          createdAt: Date.now() + 10,
        };
        setWorld((prev) => ({
          ...prev,
          chatMessages: [...prev.chatMessages, aiReply].slice(-250),
        }));
      }
    },
    [gameState, playerId, isOfflineMode]
  );

  const handleSendNpcChatMessage = useCallback(
    async (threadId: string, text: string) => {
      if (!gameState) return;
      const trimmed = text.trim();
      if (!trimmed) return;
      const thread = gameState.chatThreads.find((t) => t.id === threadId);
      if (!thread) return;

      const dateLabel = formatShortDate(gameState.artist.dayOffset);
      const playerMsg = {
        id: `msg_p_${Date.now()}`,
        sender: 'player' as const,
        text: trimmed,
        timeLabel: dateLabel,
      };

      setGameState((prev) =>
        prev
          ? {
              ...prev,
              chatThreads: prev.chatThreads.map((t) =>
                t.id === threadId
                  ? { ...t, unread: false, messages: [...t.messages, playerMsg] }
                  : t
              ),
            }
          : prev
      );

      let replyText: string | null = null;
      if (!isOfflineMode) {
        setIsSendingAi(true);
        const summary = `Artiste: ${gameState.artist.stageName}, Genre: ${gameState.artist.genre}, Fans: ${gameState.artist.fans}, Auditeurs: ${gameState.artist.monthlyListeners}, Solde: ${gameState.artist.cash}€, Popularité: ${gameState.artist.hype}/100`;
        replyText = await requestAiChatReply({
          contactName: thread.contactName,
          contactRole: thread.contactRole,
          userMessage: trimmed,
          artistSummary: summary,
        });
        setIsSendingAi(false);
      }

      if (!replyText) {
        replyText = generateOfflineAiChatReply(thread.contactId, trimmed, gameState);
      }

      const aiMsg = {
        id: `msg_c_${Date.now() + 1}`,
        sender: 'contact' as const,
        text: replyText,
        timeLabel: dateLabel,
      };

      setGameState((prev) =>
        prev
          ? {
              ...prev,
              chatThreads: prev.chatThreads.map((t) =>
                t.id === threadId ? { ...t, messages: [...t.messages, aiMsg] } : t
              ),
            }
          : prev
      );
    },
    [gameState, isOfflineMode]
  );

  // Radio & Synchro submission
  const handleSubmitToRadio = useCallback(
    (
      songId: string,
      stationName: string,
      fee: number,
      listenerBoost: number,
      royaltyBonus: number
    ): { error?: string; message?: string } => {
      if (!gameState) return { error: 'Partie inactive.' };
      const song = gameState.songs.find((s) => s.id === songId && s.released);
      if (!song) return { error: 'Morceau introuvable.' };
      if (gameState.artist.cash < fee) return { error: 'Solde insuffisant.' };

      const netDelta = royaltyBonus - fee;
      setGameState((prev) => {
        if (!prev) return prev;
        return {
          ...prev,
          artist: {
            ...prev.artist,
            cash: prev.artist.cash - fee + royaltyBonus,
            totalRevenue: prev.artist.totalRevenue + royaltyBonus,
            totalExpenses: prev.artist.totalExpenses + fee,
            monthlyListeners: prev.artist.monthlyListeners + listenerBoost,
            fans: prev.artist.fans + Math.round(listenerBoost * 0.15),
            hype: Math.min(100, prev.artist.hype + 3),
          },
          songs: prev.songs.map((s) =>
            s.id === songId
              ? {
                  ...s,
                  totalStreams: s.totalStreams + listenerBoost * 2,
                  revenueEarned: s.revenueEarned + royaltyBonus,
                }
              : s
          ),
          finances: [
            {
              id: `fin_rad_${Date.now()}`,
              week: prev.artist.weeksActive,
              label: `AllRadio · ${stationName} (« ${song.title} »)`,
              category: 'promo' as const,
              amount: netDelta,
            },
            ...prev.finances,
          ].slice(0, 40),
        };
      });

      return {
        message: `« ${song.title} » diffusé sur ${stationName} (+${listenerBoost.toLocaleString('fr-FR')} auditeurs) !`,
      };
    },
    [gameState]
  );

  if (!gameState) {
    return (
      <>
        <LiquidBackground hype={25} />
        <OfflineIndicator isOnline={isBrowserOnline} />
        <ArtistOnboarding onStartCareer={handleStartCareer} />
      </>
    );
  }

  const { artist, pendingEvent, notifications, chatThreads } = gameState;
  const unreadNotifCount = notifications.filter((n) => !n.read).length;
  const unreadChatCount = chatThreads.filter((t) => t.unread).length;
  const onlineCount = world.players.filter((p) => p.isOnline).length;

  return (
    <div className="min-h-screen pb-28 lg:pb-12">
      <LiquidBackground hype={artist.hype} />
      <OfflineIndicator isOnline={isBrowserOnline} />

      {/* Desktop Top Bar */}
      <header className="hidden lg:block mx-auto max-w-6xl px-6 pt-5">
        <div className="liquid-glass rounded-3xl px-6 py-2.5 flex items-center justify-between gap-4">
          <span className="font-display text-lg font-extrabold tracking-tight text-slate-900 dark:text-white whitespace-nowrap">
            ALL STARZ
          </span>

          <nav aria-label="Navigation principale" className="flex items-center gap-1.5">
            {[
              { id: 'chat' as const, label: 'Chat' },
              { id: 'accueil' as const, label: 'Accueil' },
              { id: 'music' as const, label: 'Music' },
              { id: 'charts' as const, label: 'Charts' },
              { id: 'apps' as const, label: 'Apps' },
              { id: 'parametres' as const, label: 'Paramètres' },
            ].map(({ id, label }) => {
              const active = activeTab === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => {
                    soundEngine.playGlassTap();
                    navigateTo(id);
                  }}
                  className={`relative px-4 py-2 text-sm font-bold rounded-full transition-colors whitespace-nowrap ${
                    active
                      ? 'text-white dark:text-slate-950'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {active && (
                    <motion.span
                      layoutId="desktop-nav-liquid"
                      transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                      className="absolute inset-0 rounded-full bg-slate-900 dark:bg-white"
                    />
                  )}
                  <span className="relative z-10">{label}</span>
                </button>
              );
            })}
          </nav>

          <button
            type="button"
            onClick={() => {
              soundEngine.playGlassTap();
              setShowNotifs(true);
            }}
            className="text-xs font-bold text-violet-600 dark:text-violet-300 whitespace-nowrap"
          >
            Notifs ({unreadNotifCount})
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="mx-auto max-w-5xl px-4 pt-4 sm:px-6 sm:pt-6">
        <AnimatePresence>
          {eventToast && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              className="mb-4 liquid-glass rounded-2xl p-4 flex items-start justify-between gap-4"
            >
              <div>
                <div className="text-xs font-bold text-violet-600 dark:text-violet-300">
                  Conséquence · {eventToast.title}
                </div>
                <p className="mt-0.5 text-sm text-slate-800 dark:text-slate-100">
                  {eventToast.outcome}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setEventToast(null)}
                className="min-h-[36px] px-3 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300"
              >
                OK
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
          >
            {activeTab === 'accueil' && (
              <CareerHomeView
                gameState={gameState}
                unreadNotifications={unreadNotifCount}
                onOpenNotifications={() => setShowNotifs(true)}
                onTrainSkill={(skill: keyof ArtistSkills | 'rest') =>
                  setGameState(trainArtistSkill(gameState, skill))
                }
                onAdvanceDay={handleAdvanceDay}
                onAdvanceWeek={handleAdvanceWeek}
                onClaimMission={(id) =>
                  setGameState(claimMissionReward(gameState, id))
                }
                onNavigate={navigateTo}
              />
            )}

            {activeTab === 'music' && (
              <MusicCenterView
                gameState={gameState}
                onRecordSong={(params) => {
                  const res = recordNewSong(gameState, params);
                  if (!res.error) setGameState(res.nextState);
                  return { error: res.error };
                }}
                onReleaseSong={(songId, promoIds) => {
                  const releasedSong = gameState.songs.find((s) => s.id === songId);
                  const res = releaseSongWithPromo(gameState, songId, promoIds);
                  if (!res.error) {
                    setGameState(res.nextState);
                    if (releasedSong) {
                      handleCreateSharedPost({
                        platform: 'allgram',
                        content: `Mon nouveau single « ${releasedSong.title} » est disponible partout sur Alltify !`,
                        attachedSongTitle: releasedSong.title,
                        tag: 'Nouvelle Sortie',
                      });
                    }
                  }
                  return { error: res.error };
                }}
                onReleaseProject={(title, format: ProjectFormat, trackIds, parentAlbumId) => {
                  const res = releaseProjectFromVault(
                    gameState,
                    title,
                    format,
                    trackIds,
                    parentAlbumId
                  );
                  if (!res.error) {
                    setGameState(res.nextState);
                    handleCreateSharedPost({
                      platform: 'allx',
                      content: `Nouveau projet « ${title} » (${format.toUpperCase()}) maintenant disponible en streaming ! #AllStarz`,
                      tag: '#NouveauProjet',
                    });
                  }
                  return { error: res.error };
                }}
                onPromoteSong={(songId, promoId) => {
                  const res = promoteReleasedSong(gameState, songId, promoId);
                  if (!res.error) setGameState(res.nextState);
                  return { error: res.error };
                }}
                onCreateClip={(songId, clipId) => {
                  const songObj = gameState.songs.find((s) => s.id === songId);
                  const res = createMusicVideoForSong(gameState, songId, clipId);
                  if (!res.error) {
                    setGameState(res.nextState);
                    if (songObj) {
                      handleCreateSharedPost({
                        platform: 'alltub',
                        title: `${artist.stageName} — ${songObj.title} (Clip Officiel)`,
                        content: `Le clip officiel de « ${songObj.title} » vient de sortir sur AllTub !`,
                        attachedSongTitle: songObj.title,
                        videoDuration: '03:45',
                        tag: 'Clip Officiel',
                      });
                    }
                  }
                  return { error: res.error };
                }}
              />
            )}

            {activeTab === 'charts' && (
              <ChartsView
                gameState={gameState}
                playerId={playerId}
                players={world.players}
                wsConnected={wsConnected}
                isOfflineMode={isOfflineMode}
              />
            )}

            {activeTab === 'apps' && (
              <AppsHubView
                playerId={playerId}
                gameState={gameState}
                world={world}
                isOfflineMode={isOfflineMode}
                onToggleOfflineMode={() => setForceOfflineAi((v) => !v)}
                activeApp={activeApp}
                onSelectApp={setActiveApp}
                onCreateSharedPost={handleCreateSharedPost}
                onToggleSharedLike={handleToggleSharedLike}
                onToggleSharedRepost={handleToggleSharedRepost}
                onAddSharedComment={handleAddSharedComment}
                onAskAiReact={handleAskAiReact}
                onPublishVlog={(title, videoType) => {
                  const res = publishAllTubVlog(gameState, title, videoType);
                  if (!res.error) setGameState(res.nextState);
                  return { error: res.error };
                }}
                onSubmitToRadio={handleSubmitToRadio}
                onSignLabel={(labelId) =>
                  setGameState(signLabelContract(gameState, labelId))
                }
                onHireStaff={(staffId) =>
                  setGameState(hireStaffMember(gameState, staffId))
                }
                onUnlockMerch={(merchId) =>
                  setGameState(unlockMerchItem(gameState, merchId))
                }
                tourCallbacks={{
                  onPerformSoloConcert: (venueId, ticketPrice, logistics) => {
                    const res = performConcertShow(gameState, venueId, ticketPrice, logistics);
                    if (!res.error) setGameState(res.nextState);
                    return { log: res.log, error: res.error };
                  },
                  onCreateCustomTour: (params) => {
                    const res = createCustomTour(gameState, params);
                    if (!res.error) setGameState(res.nextState);
                    return { error: res.error };
                  },
                  onUpdateTourSettings: (updates) => {
                    setGameState(updateCustomTourSettings(gameState, updates));
                  },
                  onAddTourDate: (params) => {
                    const res = addTourDate(gameState, params);
                    if (!res.error) setGameState(res.nextState);
                    return { error: res.error };
                  },
                  onUpdateTourDate: (dateId, updates) => {
                    setGameState(updateTourDate(gameState, dateId, updates));
                  },
                  onMoveTourDate: (dateId, direction) => {
                    setGameState(moveTourDate(gameState, dateId, direction));
                  },
                  onReorderTourDates: (orderedUnplayedIds) => {
                    setGameState(reorderTourDates(gameState, orderedUnplayedIds));
                  },
                  onPostponeTourDate: (dateId, newDayOffset) => {
                    setGameState(postponeTourDate(gameState, dateId, newDayOffset));
                  },
                  onRemoveTourDate: (dateId) => {
                    setGameState(removeTourDate(gameState, dateId));
                  },
                  onPlayTourDateById: (dateId) => {
                    const res = playTourDateById(gameState, dateId);
                    if (!res.error) setGameState(res.nextState);
                    return {
                      log: res.log,
                      tourFinished: res.tourFinished,
                      error: res.error,
                    };
                  },
                  onArchiveTour: () => {
                    setGameState(completeAndArchiveTour(gameState));
                  },
                }}
              />
            )}

            {activeTab === 'chat' && (
              <ChatView
                playerId={playerId}
                gameState={gameState}
                world={world}
                isOfflineMode={isOfflineMode}
                isSendingAi={isSendingAi}
                onToggleOfflineMode={() => setForceOfflineAi((v) => !v)}
                onStartOrOpenThread={(contactId) =>
                  setGameState(startOrOpenChatThread(gameState, contactId))
                }
                onSendNpcMessage={handleSendNpcChatMessage}
                onSendRoomOrDmMessage={handleSendRoomOrDmMessage}
              />
            )}

            {activeTab === 'parametres' && (
              <SettingsView
                gameState={gameState}
                recentCertKeys={recentCertKeys}
                isDark={isDark}
                isMuted={isMuted}
                forceOfflineAi={forceOfflineAi}
                wsConnected={wsConnected}
                onlineCount={onlineCount}
                onToggleTheme={() => setIsDark((d) => !d)}
                onToggleMute={toggleMute}
                onToggleOfflineAi={() => setForceOfflineAi((v) => !v)}
                onUpdateProfile={(updates) =>
                  setGameState(updateArtistProfile(gameState, updates))
                }
                onImportSave={handleImportSave}
                onRequestReset={() => setShowResetModal(true)}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* 3-ISLAND FLOATING LIQUID GLASS BOTTOM DOCK */}
      <nav
        aria-label="Navigation mobile"
        className="lg:hidden fixed bottom-3 inset-x-2.5 z-40 pb-safe"
      >
        <div className="mx-auto max-w-md flex items-center justify-between gap-2">
          {/* Island 1: Chat Round Button */}
          <button
            type="button"
            onClick={() => {
              soundEngine.playGlassTap();
              navigateTo('chat');
            }}
            aria-label="Chat"
            className="relative h-[58px] w-[58px] rounded-full liquid-dock flex items-center justify-center shrink-0 text-slate-900 dark:text-white active:scale-95 transition"
          >
            <MessageCircle
              className={`h-6 w-6 ${
                activeTab === 'chat' ? 'text-sky-500 dark:text-sky-400' : ''
              }`}
            />
            {unreadChatCount > 0 && (
              <span className="absolute top-2.5 right-2.5 h-2.5 w-2.5 rounded-full bg-rose-500" />
            )}
            {activeTab === 'chat' && (
              <motion.span
                layoutId="dock-active-bar"
                transition={{ type: 'spring', stiffness: 460, damping: 34 }}
                className="absolute bottom-1.5 w-7 h-1 rounded-full bg-slate-950 dark:bg-white"
              />
            )}
          </button>

          {/* Island 2: Center 4-Tab Capsule (Accueil, Music, Charts, Apps) */}
          <div className="flex-1 liquid-dock rounded-full px-1.5 py-1 grid grid-cols-4 gap-0.5">
            {CENTER_DOCK_TABS.map(({ id, label, Icon }) => {
              const active = activeTab === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => {
                    soundEngine.playGlassTap();
                    navigateTo(id);
                  }}
                  aria-label={label}
                  className={`relative min-h-[50px] rounded-full flex flex-col items-center justify-center transition-colors ${
                    active
                      ? 'text-slate-950 dark:text-white'
                      : 'text-slate-500 dark:text-slate-400'
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  <span className="mt-0.5 text-[9px] font-bold tracking-tight leading-none">
                    {label}
                  </span>
                  {active && (
                    <motion.span
                      layoutId="dock-active-bar"
                      transition={{ type: 'spring', stiffness: 460, damping: 34 }}
                      className="absolute bottom-1 w-7 h-1 rounded-full bg-slate-950 dark:bg-white shadow"
                    />
                  )}
                </button>
              );
            })}
          </div>

          {/* Island 3: Settings Round Button */}
          <button
            type="button"
            onClick={() => {
              soundEngine.playGlassTap();
              navigateTo('parametres');
            }}
            aria-label="Paramètres"
            className="relative h-[58px] w-[58px] rounded-full liquid-dock flex items-center justify-center shrink-0 text-slate-900 dark:text-white active:scale-95 transition"
          >
            <Settings
              className={`h-6 w-6 ${
                activeTab === 'parametres' ? 'text-violet-600 dark:text-violet-300' : ''
              }`}
            />
            {activeTab === 'parametres' && (
              <motion.span
                layoutId="dock-active-bar"
                transition={{ type: 'spring', stiffness: 460, damping: 34 }}
                className="absolute bottom-1.5 w-7 h-1 rounded-full bg-slate-950 dark:bg-white"
              />
            )}
          </button>
        </div>
      </nav>

      {/* Notifications Drawer */}
      <NotificationsDrawer
        open={showNotifs}
        notifications={notifications}
        onClose={() => setShowNotifs(false)}
        onSelectNotification={handleSelectNotification}
        onMarkAllRead={() =>
          setGameState({
            ...gameState,
            notifications: gameState.notifications.map((n) => ({
              ...n,
              read: true,
            })),
          })
        }
        onClearRead={() =>
          setGameState({
            ...gameState,
            notifications: gameState.notifications.filter((n) => !n.read),
          })
        }
      />

      {/* Random Event Modal */}
      <RandomEventModal
        event={pendingEvent}
        gameState={gameState}
        onSelectChoice={handleResolveEvent}
      />

      {/* Dynamic Certification Reveal Animation Overlay */}
      <CertificationRevealOverlay
        milestone={!pendingEvent ? (certRevealQueue[0] ?? null) : null}
        onClose={() => setCertRevealQueue((prev) => prev.slice(1))}
      />

      {/* Reset Career Confirmation Modal */}
      <AnimatePresence>
        {showResetModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 backdrop-blur-md p-4"
            role="dialog"
            aria-modal="true"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm liquid-glass rounded-3xl p-6"
            >
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                Réinitialiser la carrière ?
              </h3>
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                Ta progression actuelle avec {artist.stageName} sera effacée pour créer un nouvel artiste.
              </p>
              <div className="mt-6 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setShowResetModal(false)}
                  className="min-h-[44px] rounded-xl liquid-glass-subtle px-4 py-2 text-sm font-semibold text-slate-800 dark:text-slate-100"
                >
                  Annuler
                </button>
                <button
                  type="button"
                  onClick={handleResetConfirm}
                  className="min-h-[44px] rounded-xl bg-rose-600 text-white px-4 py-2 text-sm font-semibold"
                >
                  Confirmer
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
