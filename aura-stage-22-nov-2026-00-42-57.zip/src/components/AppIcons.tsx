import React from 'react';

export const AlltifyIcon: React.FC<{ className?: string }> = ({ className = 'h-12 w-12' }) => (
  <svg viewBox="0 0 64 64" fill="none" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="alltify-bg" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#1e1142" />
        <stop offset="100%" stopColor="#090714" />
      </linearGradient>
      <linearGradient id="alltify-accent" x1="14" y1="12" x2="50" y2="52" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#e879f9" />
        <stop offset="50%" stopColor="#a855f7" />
        <stop offset="100%" stopColor="#38bdf8" />
      </linearGradient>
    </defs>
    <rect width="64" height="64" rx="18" fill="url(#alltify-bg)" />
    <rect x="0.75" y="0.75" width="62.5" height="62.5" rx="17.25" stroke="white" strokeOpacity="0.16" strokeWidth="1.5" />
    <path
      d="M17 44L29.5 16.5C30.4 14.5 33.3 14.8 33.8 16.9L38.2 35.5"
      stroke="url(#alltify-accent)"
      strokeWidth="4.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <circle cx="34.5" cy="40.5" r="5.5" fill="url(#alltify-accent)" />
    <rect x="43" y="25" width="3.5" height="16" rx="1.75" fill="#c084fc" />
    <rect x="49" y="20" width="3.5" height="24" rx="1.75" fill="#38bdf8" />
  </svg>
);

export const AllGramIcon: React.FC<{ className?: string }> = ({ className = 'h-12 w-12' }) => (
  <svg viewBox="0 0 64 64" fill="none" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="allgram-bg" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#1b1426" />
        <stop offset="100%" stopColor="#09090d" />
      </linearGradient>
      <linearGradient id="allgram-accent" x1="12" y1="52" x2="54" y2="12" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#fb923c" />
        <stop offset="50%" stopColor="#ec4899" />
        <stop offset="100%" stopColor="#8b5cf6" />
      </linearGradient>
    </defs>
    <rect width="64" height="64" rx="18" fill="url(#allgram-bg)" />
    <rect x="0.75" y="0.75" width="62.5" height="62.5" rx="17.25" stroke="white" strokeOpacity="0.16" strokeWidth="1.5" />
    <path
      d="M22 17H42C45.866 17 49 20.134 49 24V38C49 41.866 45.866 45 42 45H27L19 50V44.2C16.6 43 15 40.7 15 38V24C15 20.134 18.134 17 22 17Z"
      stroke="url(#allgram-accent)"
      strokeWidth="4"
      strokeLinejoin="round"
    />
    <circle cx="32" cy="31" r="7" stroke="url(#allgram-accent)" strokeWidth="3.8" />
    <circle cx="41.5" cy="23.5" r="2.2" fill="#f472b6" />
  </svg>
);

export const AllTubIcon: React.FC<{ className?: string }> = ({ className = 'h-12 w-12' }) => (
  <svg viewBox="0 0 64 64" fill="none" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="alltub-bg" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#3b0a0a" />
        <stop offset="100%" stopColor="#0f0404" />
      </linearGradient>
      <linearGradient id="alltub-btn" x1="14" y1="22" x2="50" y2="48" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#ef4444" />
        <stop offset="100%" stopColor="#b91c1c" />
      </linearGradient>
    </defs>
    <rect width="64" height="64" rx="18" fill="url(#alltub-bg)" />
    <rect x="0.75" y="0.75" width="62.5" height="62.5" rx="17.25" stroke="white" strokeOpacity="0.16" strokeWidth="1.5" />
    <path d="M23 20L26.5 14L32 18L37.5 14L41 20H23Z" fill="#fca5a5" />
    <rect x="13" y="23" width="38" height="26" rx="8" fill="url(#alltub-btn)" />
    <path d="M28 30.5L39 36L28 41.5V30.5Z" fill="white" />
  </svg>
);

export const AllTokIcon: React.FC<{ className?: string }> = ({ className = 'h-12 w-12' }) => (
  <svg viewBox="0 0 64 64" fill="none" className={className} aria-hidden="true">
    <rect width="64" height="64" rx="18" fill="#09090b" />
    <rect x="0.75" y="0.75" width="62.5" height="62.5" rx="17.25" stroke="white" strokeOpacity="0.18" strokeWidth="1.5" />
    <path
      d="M36 16V38.5C36 43.194 32.194 47 27.5 47C22.806 47 19 43.194 19 38.5C19 33.806 22.806 30 27.5 30C28.8 30 30 30.3 31 30.8"
      stroke="#22d3ee"
      strokeWidth="4.5"
      strokeLinecap="round"
      transform="translate(-1.5 -1.5)"
    />
    <path
      d="M36 16C37.8 21.2 41.8 24.8 47 25.5"
      stroke="#f43f5e"
      strokeWidth="4.5"
      strokeLinecap="round"
      transform="translate(1.5 1.5)"
    />
    <path
      d="M36 16V38.5C36 43.194 32.194 47 27.5 47C22.806 47 19 43.194 19 38.5C19 33.806 22.806 30 27.5 30C28.8 30 30 30.3 31 30.8M36 16C37.8 21.2 41.8 24.8 47 25.5"
      stroke="white"
      strokeWidth="4.2"
      strokeLinecap="round"
    />
  </svg>
);

export const AllXIcon: React.FC<{ className?: string }> = ({ className = 'h-12 w-12' }) => (
  <svg viewBox="0 0 64 64" fill="none" className={className} aria-hidden="true">
    <rect width="64" height="64" rx="18" fill="#090d16" />
    <rect x="0.75" y="0.75" width="62.5" height="62.5" rx="17.25" stroke="white" strokeOpacity="0.18" strokeWidth="1.5" />
    <path
      d="M19 18L34.5 36.5M45 18L29.5 36.5M19 46L29.5 36.5M45 46L34.5 36.5"
      stroke="white"
      strokeWidth="4.2"
      strokeLinecap="round"
    />
    <path d="M18 18H25L46 46H39L18 18Z" fill="white" fillOpacity="0.15" />
  </svg>
);

export const AllCloudIcon: React.FC<{ className?: string }> = ({ className = 'h-12 w-12' }) => (
  <svg viewBox="0 0 64 64" fill="none" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="allcloud-bg" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#ea580c" />
        <stop offset="100%" stopColor="#9a3412" />
      </linearGradient>
    </defs>
    <rect width="64" height="64" rx="18" fill="url(#allcloud-bg)" />
    <rect x="0.75" y="0.75" width="62.5" height="62.5" rx="17.25" stroke="white" strokeOpacity="0.2" strokeWidth="1.5" />
    <rect x="14" y="33" width="3.5" height="10" rx="1.75" fill="white" />
    <rect x="20" y="27" width="3.5" height="16" rx="1.75" fill="white" />
    <rect x="26" y="23" width="3.5" height="20" rx="1.75" fill="white" />
    <path
      d="M32 23.5C33.5 21.5 36 20 39 20C43.97 20 48 24.03 48 29C48 29.3 47.98 29.6 47.95 29.9C50.25 30.8 52 33 52 35.6C52 39.1 49.1 42 45.6 42H32V23.5Z"
      fill="white"
    />
  </svg>
);

export const AllPressIcon: React.FC<{ className?: string }> = ({ className = 'h-12 w-12' }) => (
  <svg viewBox="0 0 64 64" fill="none" className={className} aria-hidden="true">
    <rect width="64" height="64" rx="18" fill="#18181b" />
    <rect x="0.75" y="0.75" width="62.5" height="62.5" rx="17.25" stroke="white" strokeOpacity="0.18" strokeWidth="1.5" />
    <rect x="15" y="16" width="34" height="32" rx="6" fill="#facc15" />
    <rect x="20" y="22" width="18" height="4" rx="2" fill="#09090b" />
    <rect x="20" y="29" width="24" height="3.5" rx="1.75" fill="#09090b" />
    <rect x="20" y="36" width="20" height="3.5" rx="1.75" fill="#09090b" />
  </svg>
);

export const AllRadioIcon: React.FC<{ className?: string }> = ({ className = 'h-12 w-12' }) => (
  <svg viewBox="0 0 64 64" fill="none" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="allradio-bg" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#0284c7" />
        <stop offset="100%" stopColor="#1e3a8a" />
      </linearGradient>
    </defs>
    <rect width="64" height="64" rx="18" fill="url(#allradio-bg)" />
    <rect x="0.75" y="0.75" width="62.5" height="62.5" rx="17.25" stroke="white" strokeOpacity="0.2" strokeWidth="1.5" />
    <circle cx="32" cy="34" r="5" fill="white" />
    <path d="M23 26C19.5 30 19.5 38 23 42M41 26C44.5 30 44.5 38 41 42" stroke="white" strokeWidth="3.2" strokeLinecap="round" />
    <path d="M17 21C11.5 28 11.5 40 17 47M47 21C52.5 28 52.5 40 47 47" stroke="white" strokeOpacity="0.75" strokeWidth="3.2" strokeLinecap="round" />
  </svg>
);
