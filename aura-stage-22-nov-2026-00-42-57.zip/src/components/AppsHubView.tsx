import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  ArrowLeft,
  BadgeCheck,
  Building2,
  Check,
  Plane,
  Play,
  Radio,
  ShoppingBag,
  Sparkles,
  Trophy,
  Users,
  Wallet,
  Wifi,
  WifiOff,
} from 'lucide-react';
import {
  LABEL_OFFERS,
  STAFF_CATALOG,
} from '../data/gameData';
import { AppSubId, GameState } from '../types/game';
import { SocialPlatform, WorldSnapshot } from '../types/network';
import {
  formatCompactNumber,
  formatCurrency,
  getCertificationLabel,
  getGenreLabel,
} from '../utils/format';
import {
  AllCloudIcon,
  AllGramIcon,
  AllPressIcon,
  AllRadioIcon,
  AllTokIcon,
  AllTubIcon,
  AllXIcon,
  AlltifyIcon,
} from './AppIcons';
import {
  AllCloudView,
  AllGramView,
  AllPressView,
  AllTokView,
  AllTubView,
  AllXView,
  SocialActionCallbacks,
} from './SocialNetworksViews';
import { TourManagerCallbacks, TourManagerView } from './TourManagerView';
import { soundEngine } from '../utils/audio';

const RADIO_STATIONS = [
  {
    id: 'allstar_fm',
    name: 'AllStar FM National',
    format: 'Hits & Pop / Urbain',
    minListeners: 500,
    fee: 180,
    listenerBoost: 1400,
    royaltyBonus: 320,
  },
  {
    id: 'skybeat_rap',
    name: 'SkyBeat 104.5',
    format: 'Rap, Trap & Afrobeat',
    minListeners: 2500,
    fee: 420,
    listenerBoost: 3800,
    royaltyBonus: 780,
  },
  {
    id: 'nova_wave',
    name: 'Nova Wave Électro/Indie',
    format: 'Électro, Indie & R&B',
    minListeners: 8000,
    fee: 850,
    listenerBoost: 7500,
    royaltyBonus: 1650,
  },
  {
    id: 'synchro_tv',
    name: 'Synchro Séries & Cinéma',
    format: 'Placement Bande Originale',
    minListeners: 20000,
    fee: 1800,
    listenerBoost: 18000,
    royaltyBonus: 4500,
  },
];

interface AppsHubViewProps {
  playerId: string;
  gameState: GameState;
  world: WorldSnapshot;
  isOfflineMode: boolean;
  onToggleOfflineMode: () => void;
  activeApp: AppSubId;
  onSelectApp: (app: AppSubId) => void;
  onCreateSharedPost: (params: {
    platform: SocialPlatform;
    content: string;
    title?: string;
    location?: string;
    tag?: string;
    mediaTone?: string;
    attachedSongTitle?: string;
    videoDuration?: string;
  }) => void;
  onToggleSharedLike: (postId: string) => void;
  onToggleSharedRepost: (postId: string) => void;
  onAddSharedComment: (postId: string, text: string) => void;
  onAskAiReact: (postId: string) => void;
  onPublishVlog: (
    title: string,
    videoType: 'Session Studio' | 'Live Performance' | 'Interview'
  ) => { error?: string };
  onSubmitToRadio: (
    songId: string,
    stationName: string,
    fee: number,
    listenerBoost: number,
    royaltyBonus: number
  ) => { error?: string; message?: string };
  onSignLabel: (labelId: string) => void;
  onHireStaff: (staffId: string) => void;
  onUnlockMerch: (merchId: string) => void;
  tourCallbacks: TourManagerCallbacks;
}

export const AppsHubView: React.FC<AppsHubViewProps> = ({
  playerId,
  gameState,
  world,
  isOfflineMode,
  onToggleOfflineMode,
  activeApp,
  onSelectApp,
  onCreateSharedPost,
  onToggleSharedLike,
  onToggleSharedRepost,
  onAddSharedComment,
  onAskAiReact,
  onPublishVlog,
  onSubmitToRadio,
  onSignLabel,
  onHireStaff,
  onUnlockMerch,
  tourCallbacks,
}) => {
  const {
    artist,
    songs,
    finances,
    merch,
    awards,
  } = gameState;

  const [appFeedback, setAppFeedback] = useState<string | null>(null);
  const [playingTrackId, setPlayingTrackId] = useState<string | null>(null);

  // AllRadio state
  const releasedSongs = songs.filter((s) => s.released);
  const [radioSongId, setRadioSongId] = useState<string>(releasedSongs[0]?.id ?? '');

  const topSong = [...releasedSongs].sort((a, b) => b.totalStreams - a.totalStreams)[0] ?? null;
  const allGramLatest = world.posts.find((p) => p.platform === 'allgram') ?? null;
  const onlinePlayersCount = world.players.filter((p) => p.isOnline).length;

  const sharedCallbacks: SocialActionCallbacks = {
    playerId,
    gameState,
    posts: world.posts,
    onlinePlayers: world.players,
    isOfflineMode,
    onCreatePost: onCreateSharedPost,
    onToggleLike: onToggleSharedLike,
    onToggleRepost: onToggleSharedRepost,
    onAddComment: onAddSharedComment,
    onAskAiReact,
  };

  // HOME LAUNCHER (Preserves Canvas__15 + Expanded Real Networks & Studio Apps)
  if (activeApp === 'home') {
    return (
      <div className="space-y-5">
        <div className="flex items-center justify-between gap-3">
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
            Apps
          </h1>
          <button
            type="button"
            onClick={() => {
              soundEngine.playGlassTap();
              onToggleOfflineMode();
            }}
            className="liquid-glass rounded-full px-3.5 py-1.5 text-[11px] font-extrabold flex items-center gap-1.5 text-slate-900 dark:text-white active:scale-95 transition"
          >
            {isOfflineMode ? (
              <>
                <WifiOff className="h-3.5 w-3.5 text-amber-400" />
                <span>Mode IA Hors-ligne</span>
              </>
            ) : (
              <>
                <Wifi className="h-3.5 w-3.5 text-emerald-400" />
                <span>Serveur Live · {Math.max(1, onlinePlayersCount)} en ligne</span>
              </>
            )}
          </button>
        </div>

        {/* Top 2 Live Preview Cards (Alltify & AllGram) */}
        <div className="grid grid-cols-2 gap-3.5">
          <button
            type="button"
            onClick={() => {
              soundEngine.playGlassTap();
              onSelectApp('alltify');
            }}
            className="liquid-interactive liquid-glass rounded-[32px] p-4 min-h-[210px] flex flex-col justify-between text-left active:scale-[0.98] transition"
          >
            <div className="space-y-1.5">
              <div className="text-[11px] font-bold uppercase tracking-wider text-violet-600 dark:text-violet-300">
                Alltify Live
              </div>
              <div className="text-xl sm:text-2xl font-extrabold font-mono tabular-nums text-slate-900 dark:text-white">
                {formatCompactNumber(artist.monthlyListeners)}
              </div>
              <div className="text-xs text-slate-600 dark:text-slate-300">
                auditeurs mensuels
              </div>
              <p className="pt-1 text-[11px] font-semibold text-slate-700 dark:text-slate-200 line-clamp-2">
                {topSong
                  ? `Top : « ${topSong.title} » (${formatCompactNumber(topSong.totalStreams)})`
                  : 'Aucun morceau publié sur la plateforme'}
              </p>
            </div>
            <div className="flex justify-center pt-3">
              <AlltifyIcon className="h-14 w-14 shadow-lg" />
            </div>
          </button>

          <button
            type="button"
            onClick={() => {
              soundEngine.playGlassTap();
              onSelectApp('allgram');
            }}
            className="liquid-interactive liquid-glass rounded-[32px] p-4 min-h-[210px] flex flex-col justify-between text-left active:scale-[0.98] transition"
          >
            <div className="space-y-1.5">
              <div className="text-[11px] font-bold uppercase tracking-wider text-pink-600 dark:text-pink-300">
                AllGram Feed
              </div>
              <div className="text-xl sm:text-2xl font-extrabold font-mono tabular-nums text-slate-900 dark:text-white">
                {formatCompactNumber(artist.fans)}
              </div>
              <div className="text-xs text-slate-600 dark:text-slate-300">
                abonnés actifs
              </div>
              <p className="pt-1 text-[11px] font-medium text-slate-700 dark:text-slate-200 line-clamp-2">
                {allGramLatest
                  ? `${allGramLatest.authorName} : « ${allGramLatest.content} »`
                  : 'Fil social partagé actif'}
              </p>
            </div>
            <div className="flex justify-center pt-3">
              <AllGramIcon className="h-14 w-14 shadow-lg" />
            </div>
          </button>
        </div>

        {/* 4 Shortcut Tiles (Canvas__15): Palmarès, Labels, Finances, Tournées */}
        <div className="grid grid-cols-4 gap-2.5">
          {[
            { id: 'awards' as const, label: 'Palmarès', Icon: Trophy, color: 'text-amber-500' },
            { id: 'labels' as const, label: 'Labels', Icon: Building2, color: 'text-violet-500' },
            { id: 'finances' as const, label: 'Finances', Icon: Wallet, color: 'text-emerald-500' },
            { id: 'tours' as const, label: 'Tournées', Icon: Plane, color: 'text-sky-500' },
          ].map(({ id, label, Icon, color }) => (
            <button
              key={id}
              type="button"
              onClick={() => {
                soundEngine.playGlassTap();
                onSelectApp(id);
              }}
              className="liquid-interactive liquid-glass rounded-3xl py-3 px-1.5 min-h-[76px] flex flex-col items-center justify-center gap-1.5 active:scale-95 transition"
            >
              <Icon className={`h-6 w-6 ${color}`} />
              <span className="text-[11px] font-bold text-slate-800 dark:text-slate-100 truncate max-w-full">
                {label}
              </span>
            </button>
          ))}
        </div>

        {/* 3 Main App Directory Rows with 'Ouvrir' Violet Pill Buttons (Canvas__15) */}
        <div className="space-y-3">
          {[
            {
              id: 'alltify' as const,
              name: 'Alltify',
              tagline: 'Écoute, découvre, progresse',
              Icon: AlltifyIcon,
            },
            {
              id: 'allgram' as const,
              name: 'AllGram',
              tagline: 'Photos, Stories & Fil partagé',
              Icon: AllGramIcon,
            },
            {
              id: 'alltub' as const,
              name: 'AllTub',
              tagline: 'Clips, Vlogs & Sessions Live',
              Icon: AllTubIcon,
            },
          ].map(({ id, name, tagline, Icon }) => (
            <div key={id} className="flex items-center gap-2.5">
              <div className="flex-1 liquid-glass rounded-3xl p-2.5 pr-4 flex items-center gap-3.5 min-w-0">
                <Icon className="h-14 w-14 shrink-0 shadow-md" />
                <div className="min-w-0 flex-1">
                  <div className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white truncate">
                    {name}
                  </div>
                  <div className="text-xs font-semibold text-slate-600 dark:text-slate-300 truncate">
                    {tagline}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  soundEngine.playGlassTap();
                  onSelectApp(id);
                }}
                className="liquid-interactive h-[68px] w-[68px] rounded-full bg-violet-500 hover:bg-violet-400 text-white font-extrabold text-xs sm:text-sm flex items-center justify-center shadow-lg shadow-violet-600/30 shrink-0 active:scale-95 transition"
              >
                Ouvrir
              </button>
            </div>
          ))}
        </div>

        {/* Expanded Social Networks & Industry Apps */}
        <div className="space-y-3 pt-1">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-sm font-extrabold uppercase tracking-wider text-slate-600 dark:text-slate-300">
              Réseaux sociaux & Outils studio
            </h2>
            <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
              {world.posts.length} posts synchronisés
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {[
              {
                id: 'alltok' as const,
                name: 'AllTok',
                desc: 'Vidéos courtes virales & défis sonores',
                count: `${world.posts.filter((p) => p.platform === 'alltok').length} vidéos`,
                Icon: AllTokIcon,
              },
              {
                id: 'allx' as const,
                name: 'AllX',
                desc: 'Posts en direct, débats & tendances',
                count: `${world.posts.filter((p) => p.platform === 'allx').length} posts`,
                Icon: AllXIcon,
              },
              {
                id: 'allcloud' as const,
                name: 'AllCloud',
                desc: 'Maquettes, freestyles & ondes audio',
                count: `${world.posts.filter((p) => p.platform === 'allcloud').length} sons`,
                Icon: AllCloudIcon,
              },
              {
                id: 'allpress' as const,
                name: 'AllPress',
                desc: 'Notes critiques /10 & presse musicale',
                count: `${releasedSongs.length} critiques`,
                Icon: AllPressIcon,
              },
              {
                id: 'allradio' as const,
                name: 'AllRadio & Synchro',
                desc: 'Rotation FM & placements TV/Cinéma',
                count: '4 stations',
                Icon: AllRadioIcon,
              },
            ].map(({ id, name, desc, count, Icon }) => (
              <button
                key={id}
                type="button"
                onClick={() => {
                  soundEngine.playGlassTap();
                  onSelectApp(id);
                }}
                className="liquid-interactive liquid-glass rounded-3xl p-3.5 flex items-center gap-3.5 text-left active:scale-[0.98] transition"
              >
                <Icon className="h-12 w-12 shrink-0 shadow-md" />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-extrabold text-slate-900 dark:text-white truncate">
                      {name}
                    </span>
                    <span className="text-[10px] font-mono font-bold text-violet-500 dark:text-violet-300 shrink-0">
                      {count}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300 truncate mt-0.5">
                    {desc}
                  </p>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const subAppTitleMap: Record<Exclude<AppSubId, 'home'>, string> = {
    alltify: 'Alltify',
    allgram: 'AllGram',
    alltok: 'AllTok',
    allx: 'AllX',
    alltub: 'AllTub',
    allcloud: 'AllCloud',
    allpress: 'AllPress',
    allradio: 'AllRadio & Synchro',
    tours: 'Tour Manager',
    labels: 'Labels & Équipe',
    finances: 'Finances & Merch',
    awards: 'Palmarès',
  };

  return (
    <motion.div
      key={activeApp}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-5"
    >
      {/* Back Header */}
      <div className="liquid-glass rounded-2xl px-4 py-3 flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => {
            soundEngine.playGlassTap();
            setAppFeedback(null);
            onSelectApp('home');
          }}
          className="min-h-[42px] flex items-center gap-2 text-sm font-bold text-slate-800 dark:text-slate-100"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Apps</span>
        </button>
        <span className="text-sm font-extrabold text-slate-900 dark:text-white">
          {subAppTitleMap[activeApp]}
        </span>
        <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
          {isOfflineMode ? 'IA Offline' : 'Live'}
        </span>
      </div>

      {appFeedback && (
        <div className="liquid-glass-subtle rounded-2xl px-4 py-3 text-sm font-medium text-sky-800 dark:text-sky-200 flex items-center justify-between">
          <span>{appFeedback}</span>
          <button type="button" onClick={() => setAppFeedback(null)} className="text-xs font-bold underline">
            OK
          </button>
        </div>
      )}

      {/* 1. ALLTIFY (Authentic Spotify for Artists UI) */}
      {activeApp === 'alltify' && (
        <div className="space-y-4">
          <div className="liquid-glass rounded-3xl overflow-hidden">
            <div className="bg-gradient-to-br from-emerald-600/85 via-teal-800/85 to-slate-950 p-5 sm:p-6 text-white space-y-3">
              <div className="flex items-center gap-3.5">
                <img
                  src={artist.avatarUrl}
                  alt={artist.stageName}
                  referrerPolicy="no-referrer"
                  className="h-16 w-16 rounded-full object-cover ring-2 ring-white/40"
                />
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-sky-300">
                    <BadgeCheck className="h-4 w-4" />
                    <span>Artiste vérifié · Alltify</span>
                  </div>
                  <h2 className="text-2xl font-extrabold truncate">{artist.stageName}</h2>
                  <p className="text-xs font-mono text-white/80">
                    {formatCompactNumber(artist.monthlyListeners)} auditeurs mensuels
                  </p>
                </div>
              </div>
            </div>

            <div className="p-5 space-y-5">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 border-b border-slate-900/10 dark:border-white/10 pb-4 font-mono tabular-nums">
                <div>
                  <div className="text-xs font-sans text-slate-500 dark:text-slate-400">
                    Auditeurs / mois
                  </div>
                  <div className="text-lg font-bold text-slate-900 dark:text-white">
                    {formatCompactNumber(artist.monthlyListeners)}
                  </div>
                </div>
                <div>
                  <div className="text-xs font-sans text-slate-500 dark:text-slate-400">
                    Streams totaux
                  </div>
                  <div className="text-lg font-bold text-emerald-600 dark:text-emerald-300">
                    {formatCompactNumber(artist.totalStreams)}
                  </div>
                </div>
                <div>
                  <div className="text-xs font-sans text-slate-500 dark:text-slate-400">
                    Sorties actives
                  </div>
                  <div className="text-lg font-bold text-slate-900 dark:text-white">
                    {releasedSongs.length}
                  </div>
                </div>
                <div>
                  <div className="text-xs font-sans text-slate-500 dark:text-slate-400">
                    Revenus Alltify
                  </div>
                  <div className="text-lg font-bold text-emerald-600 dark:text-emerald-300">
                    {formatCurrency(songs.reduce((sum, s) => sum + s.revenueEarned, 0))}
                  </div>
                </div>
              </div>

              <div className="space-y-2.5">
                <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">
                  Populaires
                </h3>
                {releasedSongs.length === 0 ? (
                  <p className="text-sm text-slate-500 dark:text-slate-400">
                    Publie ton premier morceau dans Music pour lancer ton profil Alltify.
                  </p>
                ) : (
                  [...releasedSongs]
                    .sort((a, b) => b.totalStreams - a.totalStreams)
                    .map((s, idx) => (
                      <div
                        key={s.id}
                        className="liquid-glass-subtle rounded-2xl p-3.5 flex items-center justify-between gap-3 font-mono tabular-nums"
                      >
                        <div className="flex items-center gap-3 min-w-0 font-sans">
                          <span className="text-xs font-mono text-slate-400 w-5">
                            {idx + 1}
                          </span>
                          <button
                            type="button"
                            onClick={() => {
                              setPlayingTrackId(s.id);
                              soundEngine.playTrackPreview(idx);
                            }}
                            aria-label={`Écouter ${s.title}`}
                            className={`h-9 w-9 rounded-full flex items-center justify-center shrink-0 transition active:scale-90 ${
                              playingTrackId === s.id
                                ? 'bg-emerald-500 text-slate-950'
                                : 'bg-slate-900/15 dark:bg-white/15 text-slate-900 dark:text-white'
                            }`}
                          >
                            <Play className="h-4 w-4 fill-current ml-0.5" />
                          </button>
                          <div className="min-w-0">
                            <div className="text-sm font-bold text-slate-900 dark:text-white truncate">
                              {s.title}
                            </div>
                            <div className="text-xs text-slate-500 dark:text-slate-400">
                              {getGenreLabel(s.genre)} · +{formatCompactNumber(s.dailyStreams)}/j
                            </div>
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <div className="text-sm font-bold text-slate-900 dark:text-white">
                            {formatCompactNumber(s.totalStreams)}
                          </div>
                          <div className="text-[11px] text-emerald-600 dark:text-emerald-300">
                            {formatCurrency(s.revenueEarned)}
                          </div>
                        </div>
                      </div>
                    ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. ALLGRAM */}
      {activeApp === 'allgram' && <AllGramView {...sharedCallbacks} />}

      {/* 3. ALLTOK */}
      {activeApp === 'alltok' && <AllTokView {...sharedCallbacks} />}

      {/* 4. ALLX */}
      {activeApp === 'allx' && <AllXView {...sharedCallbacks} />}

      {/* 5. ALLTUB */}
      {activeApp === 'alltub' && (
        <AllTubView {...sharedCallbacks} onPublishLocalVlog={onPublishVlog} />
      )}

      {/* 6. ALLCLOUD */}
      {activeApp === 'allcloud' && <AllCloudView {...sharedCallbacks} />}

      {/* 7. ALLPRESS */}
      {activeApp === 'allpress' && <AllPressView gameState={gameState} />}

      {/* 8. ALLRADIO & SYNCHRO */}
      {activeApp === 'allradio' && (
        <div className="space-y-4">
          <div className="liquid-glass rounded-3xl p-5 flex items-center gap-3.5">
            <AllRadioIcon className="h-12 w-12 shrink-0" />
            <div>
              <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
                AllRadio & Synchro Médias
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Envoie tes singles en rotation FM ou en placement TV pour toucher des droits d’auteur et de nouveaux auditeurs.
              </p>
            </div>
          </div>

          {releasedSongs.length === 0 ? (
            <div className="liquid-glass rounded-3xl p-6 text-center text-sm text-slate-500 dark:text-slate-400">
              Publie d’abord un single dans l’onglet Music pour le proposer aux radios.
            </div>
          ) : (
            <div className="space-y-4">
              <div className="liquid-glass rounded-3xl p-4 space-y-2">
                <label className="block text-xs font-extrabold text-slate-700 dark:text-slate-200">
                  Titre à envoyer en programmation
                </label>
                <select
                  value={radioSongId || releasedSongs[0].id}
                  onChange={(e) => setRadioSongId(e.target.value)}
                  className="w-full min-h-[44px] rounded-2xl liquid-glass-subtle px-3 text-sm font-bold text-slate-900 dark:text-white bg-transparent"
                >
                  {releasedSongs.map((s) => (
                    <option key={s.id} value={s.id} className="bg-slate-900">
                      {s.title} ({formatCompactNumber(s.totalStreams)} streams)
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {RADIO_STATIONS.map((st) => {
                  const unlocked = artist.monthlyListeners >= st.minListeners;
                  const canAfford = artist.cash >= st.fee;
                  const activeSongId = radioSongId || releasedSongs[0].id;
                  return (
                    <div key={st.id} className="liquid-glass rounded-3xl p-4 space-y-3">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
                            <Radio className="h-4 w-4 text-sky-500" />
                            <span>{st.name}</span>
                          </div>
                          <div className="text-xs text-slate-500 dark:text-slate-400">
                            {st.format}
                          </div>
                        </div>
                        <span className="text-xs font-mono font-bold text-emerald-500">
                          +{formatCurrency(st.royaltyBonus)}
                        </span>
                      </div>
                      <div className="text-xs font-mono text-slate-600 dark:text-slate-300 flex items-center justify-between">
                        <span>+{formatCompactNumber(st.listenerBoost)} auditeurs</span>
                        <span>Coût : {formatCurrency(st.fee)}</span>
                      </div>
                      <button
                        type="button"
                        disabled={!unlocked || !canAfford}
                        onClick={() => {
                          const res = onSubmitToRadio(
                            activeSongId,
                            st.name,
                            st.fee,
                            st.listenerBoost,
                            st.royaltyBonus
                          );
                          if (res.error) setAppFeedback(res.error);
                          else {
                            soundEngine.playSuccessChord();
                            setAppFeedback(res.message ?? `${st.name} a validé la diffusion !`);
                          }
                        }}
                        className="w-full min-h-[42px] rounded-2xl bg-sky-600 text-white text-xs font-extrabold disabled:opacity-40 flex items-center justify-center gap-1.5"
                      >
                        <Sparkles className="h-3.5 w-3.5" />
                        <span>
                          {!unlocked
                            ? `${formatCompactNumber(st.minListeners)} auditeurs requis`
                            : 'Envoyer en rotation'}
                        </span>
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* 9. TOUR MANAGER */}
      {activeApp === 'tours' && (
        <TourManagerView
          gameState={gameState}
          onFeedback={setAppFeedback}
          {...tourCallbacks}
        />
      )}

      {/* 10. LABELS & STAFF */}
      {activeApp === 'labels' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <section className="lg:col-span-6 liquid-glass rounded-3xl p-5 space-y-3">
            <div className="flex items-center gap-2">
              <Building2 className="h-4 w-4 text-violet-500" />
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                Contrats de Labels
              </h3>
            </div>
            {LABEL_OFFERS.map((offer) => {
              const isCurrent = artist.labelId === offer.id;
              const eligible = artist.monthlyListeners >= offer.minMonthlyListeners;
              return (
                <div
                  key={offer.id}
                  className={`rounded-2xl p-4 ${
                    isCurrent
                      ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950'
                      : 'liquid-glass-subtle'
                  }`}
                >
                  <div className="flex items-center justify-between text-sm font-bold">
                    <span>{offer.name}</span>
                    <span className="font-mono text-xs">{Math.round(offer.royaltyRate * 100)}% droits</span>
                  </div>
                  <p className="mt-1 text-xs opacity-80">{offer.description}</p>
                  <div className="mt-3 flex items-center justify-between text-xs">
                    <span className="font-mono">
                      {offer.signingAdvance > 0
                        ? `Avance ${formatCurrency(offer.signingAdvance)} · ×${offer.streamBonus}`
                        : 'Autoproduction'}
                    </span>
                    {isCurrent ? (
                      <span className="font-bold">Actif</span>
                    ) : (
                      <button
                        type="button"
                        disabled={!eligible}
                        onClick={() => {
                          soundEngine.playSuccessChord();
                          onSignLabel(offer.id);
                        }}
                        className="min-h-[38px] rounded-xl bg-violet-600 text-white px-3.5 font-bold disabled:opacity-35"
                      >
                        {eligible ? 'Signer' : `${formatCompactNumber(offer.minMonthlyListeners)} aud.`}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </section>

          <section className="lg:col-span-6 liquid-glass rounded-3xl p-5 space-y-3">
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-violet-500" />
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                Équipe professionnelle
              </h3>
            </div>
            {STAFF_CATALOG.map((staff) => {
              const hired = artist.hiredStaffIds.includes(staff.id);
              const eligible =
                artist.monthlyListeners >= staff.minMonthlyListeners &&
                artist.cash >= staff.hireCost;
              return (
                <div
                  key={staff.id}
                  className="liquid-glass-subtle rounded-2xl p-4 flex items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <div className="text-sm font-bold text-slate-900 dark:text-white">
                      {staff.role} · {staff.name}
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                      {staff.bonusDescription}
                    </p>
                    <p className="text-[11px] font-mono text-slate-500 mt-1">
                      {formatCurrency(staff.weeklySalary)}/sem · Recrutement {formatCurrency(staff.hireCost)}
                    </p>
                  </div>
                  {hired ? (
                    <span className="h-9 w-9 rounded-xl bg-emerald-500/15 text-emerald-500 flex items-center justify-center shrink-0">
                      <Check className="h-4 w-4" />
                    </span>
                  ) : (
                    <button
                      type="button"
                      disabled={!eligible}
                      onClick={() => {
                        soundEngine.playSuccessChord();
                        onHireStaff(staff.id);
                      }}
                      className="min-h-[40px] rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 px-3 text-xs font-bold disabled:opacity-35 shrink-0"
                    >
                      Recruter
                    </button>
                  )}
                </div>
              );
            })}
          </section>
        </div>
      )}

      {/* 11. FINANCES & MERCH */}
      {activeApp === 'finances' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <section className="lg:col-span-7 liquid-glass rounded-3xl p-5 space-y-4">
            <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
              Tableau financier
            </h3>
            <div className="grid grid-cols-3 gap-3 liquid-glass-subtle rounded-2xl p-4 font-mono tabular-nums">
              <div>
                <div className="text-[11px] font-sans text-slate-500">Solde</div>
                <div className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                  {formatCurrency(artist.cash)}
                </div>
              </div>
              <div>
                <div className="text-[11px] font-sans text-slate-500">Revenus</div>
                <div className="text-base sm:text-lg font-bold text-emerald-600 dark:text-emerald-300">
                  +{formatCurrency(artist.totalRevenue)}
                </div>
              </div>
              <div>
                <div className="text-[11px] font-sans text-slate-500">Dépenses</div>
                <div className="text-base sm:text-lg font-bold text-rose-600 dark:text-rose-300">
                  -{formatCurrency(artist.totalExpenses)}
                </div>
              </div>
            </div>

            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              {finances.map((f) => (
                <div
                  key={f.id}
                  className="liquid-glass-subtle rounded-2xl px-4 py-2.5 flex items-center justify-between gap-2 text-xs font-mono tabular-nums"
                >
                  <div className="min-w-0 font-sans">
                    <div className="font-bold text-slate-900 dark:text-white truncate">{f.label}</div>
                    <div className="text-slate-500">Semaine {f.week}</div>
                  </div>
                  <span
                    className={`font-bold shrink-0 ${
                      f.amount >= 0 ? 'text-emerald-600 dark:text-emerald-300' : 'text-rose-600 dark:text-rose-300'
                    }`}
                  >
                    {f.amount >= 0 ? '+' : ''}
                    {formatCurrency(f.amount)}
                  </span>
                </div>
              ))}
            </div>
          </section>

          <section className="lg:col-span-5 liquid-glass rounded-3xl p-5 space-y-3">
            <div className="flex items-center gap-2">
              <ShoppingBag className="h-4 w-4 text-violet-500" />
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                Boutique & Merch
              </h3>
            </div>
            {merch.map((item) => {
              const canUnlock =
                !item.unlocked && artist.fans >= item.minFans && artist.cash >= item.unlockCost;
              return (
                <div
                  key={item.id}
                  className="liquid-glass-subtle rounded-2xl p-3.5 flex items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <div className="text-sm font-bold text-slate-900 dark:text-white truncate">
                      {item.name}
                    </div>
                    <div className="text-xs text-slate-500 font-mono">
                      {item.unlocked
                        ? `${formatCompactNumber(item.unitsSold)} vendus · +${item.unitMargin} €/u`
                        : artist.fans < item.minFans
                          ? `${formatCompactNumber(item.minFans)} fans requis`
                          : formatCurrency(item.unlockCost)}
                    </div>
                  </div>
                  {item.unlocked ? (
                    <span className="h-9 w-9 rounded-xl bg-emerald-500/15 text-emerald-500 flex items-center justify-center shrink-0">
                      <Check className="h-4 w-4" />
                    </span>
                  ) : (
                    <button
                      type="button"
                      disabled={!canUnlock}
                      onClick={() => {
                        soundEngine.playSuccessChord();
                        onUnlockMerch(item.id);
                      }}
                      className="min-h-[38px] rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 px-3 text-xs font-bold disabled:opacity-35 shrink-0"
                    >
                      Lancer
                    </button>
                  )}
                </div>
              );
            })}
          </section>
        </div>
      )}

      {/* 12. AWARDS */}
      {activeApp === 'awards' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <section className="lg:col-span-6 liquid-glass rounded-3xl p-5 space-y-3">
            <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
              Certifications
            </h3>
            {songs.filter((s) => s.certification !== 'none').length === 0 ? (
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Les certifications démarrent à 25 000 écoutes (Bronze, Argent, Or, Platine, Diamant).
              </p>
            ) : (
              songs
                .filter((s) => s.certification !== 'none')
                .map((s) => (
                  <div
                    key={s.id}
                    className="liquid-glass-subtle rounded-2xl p-3.5 flex items-center justify-between"
                  >
                    <div>
                      <div className="text-sm font-bold text-slate-900 dark:text-white">{s.title}</div>
                      <div className="text-xs font-mono text-slate-500">
                        {formatCompactNumber(s.totalStreams)} écoutes
                      </div>
                    </div>
                    <span className="text-xs font-extrabold text-amber-600 dark:text-amber-300">
                      {getCertificationLabel(s.certification)}
                    </span>
                  </div>
                ))
            )}
          </section>

          <section className="lg:col-span-6 liquid-glass rounded-3xl p-5 space-y-3">
            <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
              Trophées · All Star Awards
            </h3>
            {awards.length === 0 ? (
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Les cérémonies annuelles récompensent les plus grands succès toutes les 52 semaines.
              </p>
            ) : (
              awards.map((a) => (
                <div key={a.id} className="liquid-glass-subtle rounded-2xl p-4">
                  <div className="text-xs font-bold text-amber-500">{a.ceremony} · An {a.year}</div>
                  <div className="text-base font-extrabold text-slate-900 dark:text-white">{a.title}</div>
                  <div className="text-xs text-slate-500">Pour « {a.workTitle} »</div>
                </div>
              ))
            )}
          </section>
        </div>
      )}
    </motion.div>
  );
};
