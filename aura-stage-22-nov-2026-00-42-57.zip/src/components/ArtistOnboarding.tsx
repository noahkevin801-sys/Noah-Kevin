import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Dices, ArrowRight, Check } from 'lucide-react';
import {
  ARTIST_AVATARS,
  GENRES,
  ORIGINS,
  RANDOM_STAGE_NAMES,
} from '../data/gameData';
import { GenreId, OriginId } from '../types/game';
import { soundEngine } from '../utils/audio';

interface ArtistOnboardingProps {
  onStartCareer: (params: {
    stageName: string;
    genre: GenreId;
    origin: OriginId;
    avatarUrl: string;
  }) => void;
}

export const ArtistOnboarding: React.FC<ArtistOnboardingProps> = ({
  onStartCareer,
}) => {
  const [stageName, setStageName] = useState('Néo Valen');
  const [genre, setGenre] = useState<GenreId>('pop');
  const [origin, setOrigin] = useState<OriginId>('bedroom');
  const [avatarUrl, setAvatarUrl] = useState(ARTIST_AVATARS[0].url);

  const handleRandomName = () => {
    soundEngine.playGlassTap();
    const candidates = RANDOM_STAGE_NAMES.filter((n) => n !== stageName);
    const next = candidates[Math.floor(Math.random() * candidates.length)];
    setStageName(next);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    soundEngine.playSuccessChord();
    onStartCareer({
      stageName: stageName.trim() || 'Néo Valen',
      genre,
      origin,
      avatarUrl,
    });
  };

  return (
    <div className="min-h-screen px-4 py-6 sm:px-6 lg:py-10 flex items-center justify-center">
      <motion.div
        initial={{ opacity: 0, y: 18, scale: 0.985 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-5xl liquid-glass rounded-3xl p-5 sm:p-8 lg:p-10"
      >
        <div className="mb-7 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between border-b border-slate-900/10 dark:border-white/10 pb-5">
          <div>
            <p className="text-xs font-semibold tracking-wider text-sky-700 dark:text-sky-300">
              ALL STARZ · Simulation & Stratégie Musicale
            </p>
            <h1 className="mt-1 text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white text-balance">
              Construis ta carrière. Deviens une star.
            </h1>
          </div>
          <p className="text-sm text-slate-600 dark:text-slate-300 max-w-xs">
            Débute en tant qu’artiste inconnu et bâtis ton empire musical décision après décision.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left column: Portrait, Name & Genres */}
          <div className="lg:col-span-6 space-y-6">
            <div>
              <label className="block text-sm font-semibold text-slate-800 dark:text-slate-100 mb-3">
                Portrait d’artiste
              </label>
              <div className="grid grid-cols-3 gap-3">
                {ARTIST_AVATARS.map((item) => {
                  const selected = avatarUrl === item.url;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        soundEngine.playGlassTap();
                        setAvatarUrl(item.url);
                      }}
                      className={`group relative aspect-square overflow-hidden rounded-2xl transition-transform duration-200 active:scale-95 focus-visible:outline-2 focus-visible:outline-sky-600 ${
                        selected
                          ? 'ring-2 ring-sky-600 dark:ring-sky-400 ring-offset-2 ring-offset-white/60 dark:ring-offset-slate-900'
                          : 'opacity-80 hover:opacity-100'
                      }`}
                    >
                      <img
                        src={item.url}
                        alt={item.label}
                        referrerPolicy="no-referrer"
                        className="h-full w-full object-cover"
                      />
                      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent p-2 text-left">
                        <span className="block text-[11px] font-medium text-white truncate">
                          {item.label}
                        </span>
                      </div>
                      {selected && (
                        <span className="absolute top-2 right-2 flex h-6 w-6 items-center justify-center rounded-full bg-sky-600 text-white shadow">
                          <Check className="h-3.5 w-3.5" />
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label
                htmlFor="stage-name-input"
                className="block text-sm font-semibold text-slate-800 dark:text-slate-100 mb-2"
              >
                Nom de scène
              </label>
              <div className="flex gap-2">
                <input
                  id="stage-name-input"
                  type="text"
                  maxLength={28}
                  value={stageName}
                  onChange={(e) => setStageName(e.target.value)}
                  placeholder="Ton nom d’artiste"
                  className="flex-1 min-h-[46px] rounded-2xl liquid-glass-subtle px-4 text-base font-medium text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-600"
                />
                <button
                  type="button"
                  onClick={handleRandomName}
                  title="Nom aléatoire"
                  aria-label="Générer un nom aléatoire"
                  className="min-h-[46px] min-w-[46px] rounded-2xl liquid-glass-subtle flex items-center justify-center text-slate-700 dark:text-slate-200 hover:bg-white/80 dark:hover:bg-slate-800/80 active:scale-95 transition"
                >
                  <Dices className="h-5 w-5" />
                </button>
              </div>
            </div>

            <div>
              <span className="block text-sm font-semibold text-slate-800 dark:text-slate-100 mb-2.5">
                Genre musical principal
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-2 gap-2">
                {GENRES.map((g) => {
                  const active = genre === g.id;
                  return (
                    <button
                      key={g.id}
                      type="button"
                      onClick={() => {
                        soundEngine.playGlassTap();
                        setGenre(g.id);
                      }}
                      className={`min-h-[44px] text-left rounded-2xl px-3.5 py-2 transition-all duration-150 active:scale-[0.98] ${
                        active
                          ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950 shadow-md'
                          : 'liquid-glass-subtle text-slate-800 dark:text-slate-100 hover:bg-white/75 dark:hover:bg-slate-800/75'
                      }`}
                    >
                      <div className="text-sm font-semibold truncate">{g.name}</div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right column: Origins + CTA */}
          <div className="lg:col-span-6 flex flex-col justify-between gap-6">
            <div>
              <span className="block text-sm font-semibold text-slate-800 dark:text-slate-100 mb-3">
                Origine & Profil de départ
              </span>
              <div className="space-y-3">
                {ORIGINS.map((item) => {
                  const active = origin === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        soundEngine.playGlassTap();
                        setOrigin(item.id);
                      }}
                      className={`w-full text-left rounded-2xl p-4 sm:p-5 transition-all duration-150 active:scale-[0.99] ${
                        active
                          ? 'bg-sky-600 text-white shadow-lg shadow-sky-600/20'
                          : 'liquid-glass-subtle text-slate-900 dark:text-slate-100 hover:bg-white/75 dark:hover:bg-slate-800/75'
                      }`}
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="text-base font-bold font-display">
                          {item.name}
                        </span>
                        <span
                          className={`text-xs font-mono tabular-nums ${
                            active
                              ? 'text-sky-100'
                              : 'text-sky-700 dark:text-sky-300'
                          }`}
                        >
                          {item.perkLabel}
                        </span>
                      </div>
                      <p
                        className={`mt-1.5 text-sm leading-relaxed ${
                          active
                            ? 'text-sky-50'
                            : 'text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        {item.description}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="liquid-interactive w-full min-h-[54px] rounded-2xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 font-bold text-base px-6 py-3.5 flex items-center justify-center gap-2.5 shadow-xl shadow-slate-900/15 active:scale-[0.98] transition-transform"
              >
                <span>Commencer l’aventure ALL STARZ</span>
                <ArrowRight className="h-5 w-5" />
              </button>
            </div>
          </div>
        </form>
      </motion.div>
    </div>
  );
};
