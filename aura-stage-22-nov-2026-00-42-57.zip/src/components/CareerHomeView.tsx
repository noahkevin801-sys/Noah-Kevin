import React from 'react';
import { motion } from 'motion/react';
import {
  Bell,
  BatteryCharging,
  CheckCircle2,
  Disc3,
  FastForward,
  Calendar,
  Mic2,
  PenTool,
  Sliders,
  Sparkles,
  TrendingUp,
  ArrowUpRight,
} from 'lucide-react';
import { AppSubId, ArtistSkills, GameState, TabId } from '../types/game';
import {
  formatCompactNumber,
  formatCurrency,
  formatGameDate,
  getCareerRank,
  getCertificationLabel,
  getGenreLabel,
} from '../utils/format';
import { computeMissions } from '../engine/simulation';
import { soundEngine } from '../utils/audio';

interface CareerHomeViewProps {
  gameState: GameState;
  unreadNotifications: number;
  onOpenNotifications: () => void;
  onTrainSkill: (skill: keyof ArtistSkills | 'rest') => void;
  onAdvanceDay: () => void;
  onAdvanceWeek: () => void;
  onClaimMission: (missionId: string) => void;
  onNavigate: (tab: TabId, app?: AppSubId) => void;
}

const SKILL_CARDS: Array<{
  id: keyof ArtistSkills;
  label: string;
  subtitle: string;
  Icon: React.FC<{ className?: string }>;
}> = [
  { id: 'vocals', label: 'Technique Vocale', subtitle: 'Justesse & timbre', Icon: Mic2 },
  { id: 'writing', label: 'Écriture', subtitle: 'Plume & refrains', Icon: PenTool },
  { id: 'production', label: 'Production', subtitle: 'Mixage & textures', Icon: Sliders },
  { id: 'stage', label: 'Présence Scénique', subtitle: 'Charisme en live', Icon: Sparkles },
];

const LiquidRadialGauge: React.FC<{
  label: string;
  value: number;
  max?: number;
  accentColor: string;
  onClick?: () => void;
}> = ({ label, value, max = 100, accentColor, onClick }) => {
  const pct = Math.max(0, Math.min(100, Math.round((value / max) * 100)));
  const radius = 37;
  const circumference = 2 * Math.PI * radius;
  const dashOffset = circumference - (pct / 100) * circumference;

  const Wrapper = onClick ? 'button' : 'div';

  return (
    <Wrapper
      {...(onClick ? { type: 'button' as const, onClick } : {})}
      className={`relative flex flex-col items-center justify-center rounded-full p-1 transition-transform ${
        onClick ? 'active:scale-95 cursor-pointer' : ''
      }`}
    >
      <div className="relative h-24 w-24 sm:h-28 sm:w-28 flex items-center justify-center">
        {/* Liquid Radial Fill Background */}
        <div
          className="absolute inset-2 rounded-full overflow-hidden bg-violet-950/50 dark:bg-violet-950/60 border border-white/15 shadow-inner"
          aria-hidden="true"
        >
          <div
            className="absolute inset-x-0 bottom-0 transition-all duration-500 ease-out opacity-85"
            style={{
              height: `${Math.max(12, pct)}%`,
              background: accentColor,
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/25 via-transparent to-white/20" />
        </div>

        {/* Precision Ring */}
        <svg className="relative z-10 h-full w-full -rotate-90" viewBox="0 0 92 92">
          <circle
            cx="46"
            cy="46"
            r={radius}
            fill="none"
            stroke="rgba(255,255,255,0.16)"
            strokeWidth="5"
          />
          <motion.circle
            cx="46"
            cy="46"
            r={radius}
            fill="none"
            stroke="#c084fc"
            strokeWidth="5"
            strokeLinecap="round"
            strokeDasharray={circumference}
            initial={false}
            animate={{ strokeDashoffset: dashOffset }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
          />
        </svg>

        {/* Center Text */}
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center text-center px-2">
          <span className="text-[11px] sm:text-xs font-extrabold tracking-tight text-white drop-shadow">
            {label}
          </span>
          <span className="mt-0.5 text-xs sm:text-sm font-mono font-bold tabular-nums text-white/95 drop-shadow">
            {pct}%
          </span>
        </div>
      </div>
    </Wrapper>
  );
};

export const CareerHomeView: React.FC<CareerHomeViewProps> = ({
  gameState,
  unreadNotifications,
  onOpenNotifications,
  onTrainSkill,
  onAdvanceDay,
  onAdvanceWeek,
  onClaimMission,
  onNavigate,
}) => {
  const { artist, streamNews, lastWeeklySummary, eventHistory, songs } = gameState;
  const rankInfo = getCareerRank(artist.monthlyListeners);
  const latestRelease = songs.find((s) => s.released) ?? null;
  const missions = computeMissions(gameState);

  return (
    <div className="space-y-5">
      {/* Row 1 (Canvas__16): Date capsule + Bell button */}
      <div className="flex items-center justify-between gap-3">
        <div className="liquid-glass rounded-full px-4 py-2 text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
          {formatGameDate(artist.dayOffset)}
        </div>

        <button
          type="button"
          onClick={() => {
            soundEngine.playGlassTap();
            onOpenNotifications();
          }}
          aria-label="Notifications"
          className="relative min-h-[44px] min-w-[44px] rounded-full liquid-glass flex items-center justify-center text-amber-500 dark:text-amber-400 active:scale-95 transition"
        >
          <Bell className="h-5 w-5 fill-current" />
          {unreadNotifications > 0 && (
            <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-rose-500 text-white text-[10px] font-mono font-bold flex items-center justify-center shadow">
              {unreadNotifications}
            </span>
          )}
        </button>
      </div>

      {/* Row 2 (Canvas__16): Artist Pill + Day / Week Time Controls */}
      <div className="flex flex-wrap sm:flex-nowrap items-stretch gap-2.5">
        <button
          type="button"
          onClick={() => {
            soundEngine.playGlassTap();
            onNavigate('parametres');
          }}
          className="flex-1 min-w-[200px] liquid-glass rounded-full p-2 pr-5 flex items-center gap-3.5 text-left hover:brightness-105 active:scale-[0.99] transition"
        >
          <img
            src={artist.avatarUrl}
            alt={artist.stageName}
            referrerPolicy="no-referrer"
            className="h-14 w-14 sm:h-16 sm:w-16 rounded-full object-cover shrink-0 border-2 border-white/60 dark:border-white/25 shadow"
          />
          <div className="min-w-0 flex-1">
            <div className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white truncate">
              {artist.stageName}
            </div>
            <div className="text-xs text-slate-600 dark:text-slate-300 truncate">
              {rankInfo.title} · {getGenreLabel(artist.genre)}
            </div>
            <div className="mt-0.5 text-[11px] font-mono tabular-nums text-sky-700 dark:text-sky-300">
              {formatCompactNumber(artist.monthlyListeners)} aud. · {formatCompactNumber(artist.fans)} fans
            </div>
          </div>
        </button>

        <div className="flex items-stretch gap-2 w-full sm:w-auto shrink-0">
          <button
            type="button"
            onClick={() => {
              soundEngine.playGlassTap();
              onAdvanceDay();
            }}
            className="liquid-interactive flex-1 sm:flex-none min-w-[78px] min-h-[60px] liquid-glass rounded-3xl px-4 py-2 flex flex-col items-center justify-center gap-0.5 text-slate-900 dark:text-white font-extrabold text-sm sm:text-base active:scale-95 transition"
          >
            <Calendar className="h-4 w-4 text-violet-600 dark:text-violet-300" />
            <span>Jour</span>
          </button>

          <button
            type="button"
            onClick={() => {
              soundEngine.playSuccessChord();
              onAdvanceWeek();
            }}
            className="liquid-interactive flex-1 sm:flex-none min-w-[88px] min-h-[60px] rounded-3xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 px-4 py-2 flex flex-col items-center justify-center gap-0.5 font-extrabold text-sm sm:text-base shadow-lg active:scale-95 transition"
          >
            <FastForward className="h-4 w-4" />
            <span>Semaine</span>
          </button>
        </div>
      </div>

      {/* Row 3 (Canvas__16): Asymmetric 2-Column Core Dashboard */}
      <div className="grid grid-cols-12 gap-3.5 sm:gap-5 items-stretch">
        {/* Left Column: 4 Radial Gauges in 2 Liquid Glass Capsules + Rest Button */}
        <div className="col-span-5 sm:col-span-4 flex flex-col gap-3.5">
          <div className="liquid-glass rounded-[36px] py-3 px-2 flex flex-col items-center justify-center gap-3">
            <LiquidRadialGauge
              label="Énergie"
              value={artist.energy}
              max={artist.maxEnergy}
              accentColor="linear-gradient(180deg, #a855f7 0%, #6d28d9 100%)"
              onClick={() => {
                if (artist.energy < artist.maxEnergy) {
                  soundEngine.playGlassTap();
                  onTrainSkill('rest');
                }
              }}
            />
            <LiquidRadialGauge
              label="Popularité"
              value={artist.hype}
              accentColor="linear-gradient(180deg, #9333ea 0%, #4f46e5 100%)"
            />
          </div>

          <div className="liquid-glass rounded-[36px] py-3 px-2 flex flex-col items-center justify-center gap-3">
            <LiquidRadialGauge
              label="Réputation"
              value={artist.reputation}
              accentColor="linear-gradient(180deg, #8b5cf6 0%, #3b82f6 100%)"
            />
            <LiquidRadialGauge
              label="Fame"
              value={artist.fame}
              accentColor="linear-gradient(180deg, #c084fc 0%, #7c3aed 100%)"
            />
          </div>

          <button
            type="button"
            onClick={() => {
              soundEngine.playGlassTap();
              onTrainSkill('rest');
            }}
            disabled={artist.energy >= artist.maxEnergy}
            className="liquid-interactive min-h-[44px] rounded-2xl liquid-glass-subtle px-3 py-2 flex items-center justify-center gap-1.5 text-xs font-bold text-slate-900 dark:text-white disabled:opacity-45 active:scale-95 transition"
          >
            <BatteryCharging className="h-4 w-4 text-emerald-500 shrink-0" />
            <span>Repos (+38)</span>
          </button>
        </div>

        {/* Right Column: Solde Card + Living "News of streams" Feed */}
        <div className="col-span-7 sm:col-span-8 flex flex-col gap-3.5">
          {/* Solde (Cash) Card */}
          <button
            type="button"
            onClick={() => {
              soundEngine.playGlassTap();
              onNavigate('apps', 'finances');
            }}
            className="liquid-interactive liquid-glass rounded-[30px] p-4 sm:p-5 text-left flex items-center justify-between gap-2 active:scale-[0.98] transition"
          >
            <div className="min-w-0">
              <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Solde disponible
              </div>
              <div className="mt-1 text-2xl sm:text-4xl font-extrabold font-mono tabular-nums text-slate-900 dark:text-white truncate">
                {formatCurrency(artist.cash)}
              </div>
            </div>
            <span className="h-9 w-9 rounded-full liquid-glass-subtle flex items-center justify-center text-slate-700 dark:text-slate-200 shrink-0">
              <ArrowUpRight className="h-4 w-4" />
            </span>
          </button>

          {/* News of streams (Live & Interactive Feed) */}
          <section className="flex-1 liquid-glass rounded-[32px] p-4 sm:p-5 flex flex-col">
            <div className="flex items-center justify-between gap-2 mb-3">
              <h2 className="text-base sm:text-xl font-extrabold text-slate-900 dark:text-white">
                News of streams
              </h2>
              <button
                type="button"
                onClick={() => {
                  soundEngine.playGlassTap();
                  onNavigate('apps', 'alltify');
                }}
                className="text-xs font-bold text-violet-600 dark:text-violet-300 hover:underline shrink-0"
              >
                Alltify →
              </button>
            </div>

            {/* Live Mini Telemetry Strip */}
            <div className="grid grid-cols-2 gap-2 mb-3">
              <div className="liquid-glass-subtle rounded-2xl p-2.5">
                <div className="text-[10px] font-semibold text-slate-500 dark:text-slate-400">
                  Streams totaux
                </div>
                <div className="text-sm sm:text-base font-extrabold font-mono tabular-nums text-slate-900 dark:text-white">
                  {formatCompactNumber(artist.totalStreams)}
                </div>
              </div>
              <div className="liquid-glass-subtle rounded-2xl p-2.5">
                <div className="text-[10px] font-semibold text-slate-500 dark:text-slate-400">
                  Dernier titre
                </div>
                <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate">
                  {latestRelease ? latestRelease.title : 'Aucun titre'}
                </div>
              </div>
            </div>

            {/* Dynamic Stream News List */}
            <div className="flex-1 space-y-2.5 max-h-[305px] overflow-y-auto pr-0.5">
              {streamNews.map((item) => (
                <div
                  key={item.id}
                  className="liquid-glass-subtle rounded-2xl p-3 space-y-1"
                >
                  <div className="flex items-center justify-between gap-2 text-[10px] font-mono tabular-nums text-slate-500 dark:text-slate-400">
                    <span>{item.dateLabel}</span>
                    {item.deltaText && (
                      <span className="font-bold text-emerald-600 dark:text-emerald-300">
                        {item.deltaText}
                      </span>
                    )}
                  </div>
                  <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white leading-snug">
                    {item.title}
                  </div>
                  <p className="text-[11px] sm:text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {item.detail}
                  </p>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>

      {/* Latest Weekly Summary Banner (When available) */}
      {lastWeeklySummary && (
        <motion.section
          key={lastWeeklySummary.week}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="liquid-glass rounded-3xl p-4 sm:p-5"
        >
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
              <TrendingUp className="h-4 w-4 text-sky-600 dark:text-sky-400" />
              <span>Bilan · Semaine {lastWeeklySummary.week - 1}</span>
            </div>
            <span
              className={`text-sm font-mono font-bold tabular-nums ${
                lastWeeklySummary.netCashDelta >= 0
                  ? 'text-emerald-600 dark:text-emerald-300'
                  : 'text-rose-600 dark:text-rose-300'
              }`}
            >
              {lastWeeklySummary.netCashDelta >= 0 ? '+' : ''}
              {formatCurrency(lastWeeklySummary.netCashDelta)}
            </span>
          </div>
          <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600 dark:text-slate-300 font-mono tabular-nums">
            <span>+{formatCompactNumber(lastWeeklySummary.streamsGained)} écoutes</span>
            <span aria-hidden="true">·</span>
            <span>+{formatCompactNumber(lastWeeklySummary.fansGained)} fans</span>
            <span aria-hidden="true">·</span>
            <span>Frais -{formatCurrency(lastWeeklySummary.upkeepCost)}</span>
          </div>
          {lastWeeklySummary.chartHighlight && (
            <p className="mt-1.5 text-xs font-semibold text-sky-700 dark:text-sky-300">
              {lastWeeklySummary.chartHighlight}
            </p>
          )}
          {lastWeeklySummary.newCertifications.map((c, idx) => (
            <p
              key={idx}
              className="mt-1 text-xs font-bold text-amber-600 dark:text-amber-300"
            >
              Certification : « {c.title} » — {getCertificationLabel(c.level)}
            </p>
          ))}
        </motion.section>
      )}

      {/* Missions & Quick Studio CTA */}
      <section className="liquid-glass rounded-3xl p-5 space-y-3.5">
        <div className="flex items-center justify-between gap-2">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
              Objectifs de carrière
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
              {missions.filter((m) => m.claimed).length} / {missions.length} complétés
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              soundEngine.playGlassTap();
              onNavigate('music');
            }}
            className="min-h-[40px] rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 px-3.5 py-2 text-xs font-bold flex items-center gap-1.5 active:scale-95 transition"
          >
            <Disc3 className="h-3.5 w-3.5" />
            <span>Studio Music</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
          {missions.map((m) => (
            <div
              key={m.id}
              className="liquid-glass-subtle rounded-2xl p-3.5 flex items-center justify-between gap-3"
            >
              <div className="min-w-0 flex-1">
                <div className="text-sm font-bold text-slate-900 dark:text-white truncate">
                  {m.title}
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 truncate">
                  {m.description}
                </p>
                <div className="mt-1 text-[11px] font-mono tabular-nums text-sky-700 dark:text-sky-300">
                  +{formatCurrency(m.rewardCash)} · +{m.rewardHype} Pop.
                </div>
              </div>
              {m.claimed ? (
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-300">
                  <CheckCircle2 className="h-4 w-4" />
                </span>
              ) : m.completed ? (
                <button
                  type="button"
                  onClick={() => {
                    soundEngine.playSuccessChord();
                    onClaimMission(m.id);
                  }}
                  className="min-h-[40px] shrink-0 rounded-xl bg-violet-600 text-white text-xs font-bold px-3.5 py-2 active:scale-95 transition"
                >
                  Réclamer
                </button>
              ) : (
                <span className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400 shrink-0">
                  {formatCompactNumber(m.currentValue)}/{formatCompactNumber(m.targetValue)}
                </span>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Skills + Events Journal */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <section className="lg:col-span-6 liquid-glass rounded-3xl p-5">
          <div className="flex items-baseline justify-between gap-2 mb-3.5">
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
              Entraînement artistique
            </h2>
            <span className="text-xs font-mono text-slate-500 dark:text-slate-400 tabular-nums">
              15 Én. · 80 €
            </span>
          </div>

          <div className="space-y-2.5">
            {SKILL_CARDS.map(({ id, label, subtitle, Icon }) => {
              const score = artist.skills[id];
              const canTrain = artist.energy >= 15 && artist.cash >= 80 && score < 99;
              return (
                <div
                  key={id}
                  className="liquid-glass-subtle rounded-2xl p-3 flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-slate-900/5 dark:bg-white/10 text-slate-700 dark:text-slate-200">
                      <Icon className="h-4 w-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                          {label}
                        </span>
                        <span className="text-xs font-mono font-bold tabular-nums text-slate-700 dark:text-slate-200">
                          {score}/99
                        </span>
                      </div>
                      <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-slate-900/10 dark:bg-white/10">
                        <div
                          className="h-full rounded-full bg-violet-600 dark:bg-violet-400 transition-all duration-300"
                          style={{ width: `${score}%` }}
                        />
                      </div>
                      <p className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400 truncate">
                        {subtitle}
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    disabled={!canTrain}
                    onClick={() => {
                      soundEngine.playGlassTap();
                      onTrainSkill(id);
                    }}
                    className="min-h-[42px] shrink-0 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 text-xs font-bold px-3 py-2 disabled:opacity-35 active:scale-95 transition"
                  >
                    +Progrès
                  </button>
                </div>
              );
            })}
          </div>
        </section>

        <section className="lg:col-span-6 liquid-glass rounded-3xl p-5">
          <div className="flex items-baseline justify-between gap-2 mb-3.5">
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
              Journal des événements
            </h2>
            <span className="text-xs font-mono text-slate-500 dark:text-slate-400 tabular-nums">
              {eventHistory.length} marquants
            </span>
          </div>

          {eventHistory.length === 0 ? (
            <div className="liquid-glass-subtle rounded-2xl p-6 text-center">
              <p className="text-sm font-medium text-slate-700 dark:text-slate-200">
                Aucun événement enregistré pour l’instant
              </p>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                Avance les semaines, publie des morceaux ou lance une tournée pour déclencher des opportunités et imprévus.
              </p>
            </div>
          ) : (
            <div className="space-y-2.5 max-h-[320px] overflow-y-auto pr-1">
              {eventHistory.map((item) => (
                <div key={item.id} className="liquid-glass-subtle rounded-2xl p-3.5">
                  <div className="flex items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
                    <span>Semaine {item.week} · {item.chosenLabel}</span>
                    <span
                      className={`font-bold ${
                        item.sentimentResult === 'positive'
                          ? 'text-emerald-600 dark:text-emerald-300'
                          : item.sentimentResult === 'negative'
                            ? 'text-rose-600 dark:text-rose-300'
                            : 'text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      {item.sentimentResult === 'positive'
                        ? 'Favorable'
                        : item.sentimentResult === 'negative'
                          ? 'Défavorable'
                          : 'Neutre'}
                    </span>
                  </div>
                  <h3 className="mt-1 text-sm font-bold text-slate-900 dark:text-white">
                    {item.title}
                  </h3>
                  <p className="mt-0.5 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {item.outcomeText}
                  </p>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
};
