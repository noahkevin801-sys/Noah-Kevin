import React, { useMemo, useState } from 'react';
import { motion } from 'motion/react';
import {
  ArrowDown,
  ArrowUp,
  BadgeCheck,
  Crown,
  Disc3,
  Globe,
  Headphones,
  Minus,
  Music,
  Sparkles,
  Users,
  Wifi,
  WifiOff,
} from 'lucide-react';
import { ChartEntry, GameState } from '../types/game';
import { OnlinePlayerProfile } from '../types/network';
import { formatCompactNumber, getGenreLabel } from '../utils/format';
import { soundEngine } from '../utils/audio';

interface ChartsViewProps {
  gameState: GameState;
  playerId: string;
  players: OnlinePlayerProfile[];
  wsConnected: boolean;
  isOfflineMode: boolean;
}

type ChartsScreenMode = 'songs' | 'world';
type ChartTier = 50 | 100 | 200;
type WorldSortKey = 'monthlyListeners' | 'fans' | 'totalStreams' | 'fame';

export const ChartsView: React.FC<ChartsViewProps> = ({
  gameState,
  playerId,
  players,
  wsConnected,
  isOfflineMode,
}) => {
  const [screenMode, setScreenMode] = useState<ChartsScreenMode>('songs');
  const [tier, setTier] = useState<ChartTier>(50);
  const [onlyMine, setOnlyMine] = useState(false);

  // World Leaderboard state
  const [worldSort, setWorldSort] = useState<WorldSortKey>('monthlyListeners');
  const [onlyOnlinePlayers, setOnlyOnlinePlayers] = useState(false);

  const slicedCharts = gameState.charts.slice(0, tier);
  const filteredCharts = onlyMine
    ? slicedCharts.filter((c) => c.isPlayer)
    : slicedCharts;

  const topOne: ChartEntry | null = !onlyMine && slicedCharts.length > 0 ? slicedCharts[0] : null;
  const restRows = topOne ? filteredCharts.slice(1) : filteredCharts;
  const playerBestRank = gameState.charts.find((c) => c.isPlayer)?.rank ?? null;

  // Merge live local player stats into WebSocket player list so self rank is always real-time
  const rankedWorldPlayers = useMemo(() => {
    const { artist, songs } = gameState;
    const bestSong = [...songs.filter((s) => s.released)].sort(
      (a, b) => b.totalStreams - a.totalStreams
    )[0];
    const selfHandle = `@${artist.stageName.toLowerCase().replace(/[^a-z0-9]/g, '') || 'artiste'}`;

    const selfEntry: OnlinePlayerProfile = {
      playerId,
      stageName: artist.stageName,
      handle: selfHandle,
      genre: artist.genre,
      avatarUrl: artist.avatarUrl,
      fans: artist.fans,
      monthlyListeners: artist.monthlyListeners,
      totalStreams: artist.totalStreams,
      fame: artist.fame,
      hype: artist.hype,
      verified: artist.fans >= 10000,
      isOnline: !isOfflineMode && wsConnected,
      lastSeenAt: Date.now(),
      topSongTitle: bestSong?.title,
    };

    const byId = new Map<string, OnlinePlayerProfile>();
    for (const p of players) {
      byId.set(p.playerId, p);
    }
    byId.set(playerId, selfEntry);

    const list = Array.from(byId.values()).filter((p) =>
      onlyOnlinePlayers ? p.isOnline || p.playerId === playerId : true
    );

    return list.sort((a, b) => {
      const valA = Number(a[worldSort] ?? 0);
      const valB = Number(b[worldSort] ?? 0);
      if (valB !== valA) return valB - valA;
      return b.fans - a.fans;
    });
  }, [gameState, playerId, players, wsConnected, isOfflineMode, onlyOnlinePlayers, worldSort]);

  const selfWorldRankIndex = rankedWorldPlayers.findIndex((p) => p.playerId === playerId);
  const selfWorldRank = selfWorldRankIndex >= 0 ? selfWorldRankIndex + 1 : null;
  const onlinePlayersCount = rankedWorldPlayers.filter((p) => p.isOnline).length;
  const worldTopOne = rankedWorldPlayers[0] ?? null;
  const worldRest = rankedWorldPlayers.slice(1);

  const metricLabelMap: Record<WorldSortKey, string> = {
    monthlyListeners: 'auditeurs/mois',
    fans: 'fans',
    totalStreams: 'streams',
    fame: 'Fame /100',
  };

  const getMetricValue = (p: OnlinePlayerProfile): string => {
    const raw = Number(p[worldSort] ?? 0);
    if (worldSort === 'fame') return `${raw}/100`;
    return formatCompactNumber(raw);
  };

  const renderDelta = (entry: ChartEntry) => {
    const diff = entry.previousRank !== null ? entry.previousRank - entry.rank : null;
    if (diff === null) {
      return (
        <span className="text-[11px] font-bold text-sky-600 dark:text-sky-300">
          NEW
        </span>
      );
    }
    if (diff > 0) {
      return (
        <span className="flex items-center gap-0.5 text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
          <ArrowUp className="h-3 w-3" />
          {diff}
        </span>
      );
    }
    if (diff < 0) {
      return (
        <span className="flex items-center gap-0.5 text-[11px] font-bold text-rose-600 dark:text-rose-400">
          <ArrowDown className="h-3 w-3" />
          {Math.abs(diff)}
        </span>
      );
    }
    return <Minus className="h-3 w-3 text-slate-400" />;
  };

  return (
    <div className="space-y-5">
      {/* Header + Top-Level Mode Switcher (Top Titres | Classements Mondiaux) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
              Charts
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
              {screenMode === 'world'
                ? selfWorldRank
                  ? `Ta place mondiale : N°${selfWorldRank} sur ${rankedWorldPlayers.length} joueur(s)`
                  : `${rankedWorldPlayers.length} joueur(s) classé(s)`
                : playerBestRank
                  ? `Ta meilleure position actuelle : N°${playerBestRank}`
                  : 'Publie un titre à succès pour entrer dans le Top 200 Global'}
            </p>
          </div>

          {screenMode === 'songs' ? (
            <button
              type="button"
              onClick={() => {
                soundEngine.playGlassTap();
                setOnlyMine((v) => !v);
              }}
              className={`min-h-[40px] rounded-full px-3.5 py-1.5 text-xs font-bold transition ${
                onlyMine
                  ? 'bg-violet-600 text-white shadow'
                  : 'liquid-glass-subtle text-slate-700 dark:text-slate-200'
              }`}
            >
              {onlyMine ? 'Tous les titres' : 'Mes titres'}
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                soundEngine.playGlassTap();
                setOnlyOnlinePlayers((v) => !v);
              }}
              className={`min-h-[40px] rounded-full px-3.5 py-1.5 text-xs font-bold transition flex items-center gap-1.5 ${
                onlyOnlinePlayers
                  ? 'bg-emerald-600 text-white shadow'
                  : 'liquid-glass-subtle text-slate-700 dark:text-slate-200'
              }`}
            >
              <Users className="h-3.5 w-3.5" />
              <span>{onlyOnlinePlayers ? 'En ligne' : 'Tous'}</span>
            </button>
          )}
        </div>

        {/* Main Charts Sub-Screen Switcher */}
        <div className="grid grid-cols-2 gap-2 liquid-glass rounded-full p-1.5">
          <button
            type="button"
            onClick={() => {
              soundEngine.playGlassTap();
              setScreenMode('songs');
            }}
            className={`min-h-[42px] rounded-full text-xs sm:text-sm font-extrabold flex items-center justify-center gap-1.5 transition ${
              screenMode === 'songs'
                ? 'bg-slate-950 text-white dark:bg-white dark:text-slate-950 shadow'
                : 'text-slate-700 dark:text-slate-200'
            }`}
          >
            <Music className="h-4 w-4" />
            <span>Top Titres</span>
          </button>

          <button
            type="button"
            onClick={() => {
              soundEngine.playGlassTap();
              setScreenMode('world');
            }}
            className={`min-h-[42px] rounded-full text-xs sm:text-sm font-extrabold flex items-center justify-center gap-1.5 transition ${
              screenMode === 'world'
                ? 'bg-slate-950 text-white dark:bg-white dark:text-slate-950 shadow'
                : 'text-slate-700 dark:text-slate-200'
            }`}
          >
            <Globe className="h-4 w-4" />
            <span>Classements Mondiaux</span>
            {!isOfflineMode && wsConnected && (
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
            )}
          </button>
        </div>
      </div>

      {/* ====================================================================
       * SCREEN 1: CLASSEMENTS MONDIAUX (LIVE WEBSOCKET PLAYERS)
       * ==================================================================== */}
      {screenMode === 'world' && (
        <div className="space-y-4">
          {/* WebSocket Live Status Banner */}
          <div className="liquid-glass rounded-3xl px-4 py-3 flex items-center justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-2.5">
              {!isOfflineMode && wsConnected ? (
                <Wifi className="h-4 w-4 text-emerald-400 shrink-0" />
              ) : (
                <WifiOff className="h-4 w-4 text-amber-400 shrink-0" />
              )}
              <div>
                <div className="text-xs font-extrabold text-slate-900 dark:text-white">
                  {!isOfflineMode && wsConnected
                    ? 'Serveur WebSocket Temps Réel · Connecté'
                    : 'Mode Hors-ligne (données en cache local)'}
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">
                  {onlinePlayersCount} joueur(s) en ligne en ce moment · Mise à jour automatique
                </div>
              </div>
            </div>
            <span className="rounded-full bg-emerald-500/15 text-emerald-500 px-2.5 py-1 text-[10px] font-mono font-extrabold">
              LIVE WS
            </span>
          </div>

          {/* Sort Metric Selector Pills */}
          <div className="grid grid-cols-4 gap-1.5">
            {(
              [
                { id: 'monthlyListeners', label: 'Auditeurs' },
                { id: 'fans', label: 'Fans' },
                { id: 'totalStreams', label: 'Streams' },
                { id: 'fame', label: 'Fame' },
              ] as const
            ).map((opt) => {
              const active = worldSort === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => {
                    soundEngine.playGlassTap();
                    setWorldSort(opt.id);
                  }}
                  className={`min-h-[40px] rounded-2xl px-2 text-xs font-extrabold transition ${
                    active
                      ? 'bg-white text-slate-950 shadow-md'
                      : 'liquid-glass-subtle text-slate-700 dark:text-slate-200'
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>

          {/* World Top N°1 Spotlight Card */}
          {worldTopOne && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="relative"
            >
              <div
                className={`rounded-3xl p-4 sm:p-5 flex items-center justify-between gap-4 shadow-xl ${
                  worldTopOne.playerId === playerId
                    ? 'bg-gradient-to-br from-white via-sky-50 to-violet-100 text-slate-950 ring-2 ring-violet-500'
                    : 'bg-white/95 dark:bg-white text-slate-950'
                }`}
              >
                <div className="min-w-0 flex-1 space-y-1.5">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
                    <Crown className="h-3.5 w-3.5 text-amber-500" />
                    <span>Leader Mondial</span>
                    {worldTopOne.playerId === playerId && (
                      <span className="inline-flex items-center gap-1 text-violet-700 font-extrabold">
                        <Sparkles className="h-3.5 w-3.5" /> Toi
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5">
                    <h2 className="text-lg sm:text-2xl font-extrabold tracking-tight text-slate-950 truncate">
                      {worldTopOne.stageName}
                    </h2>
                    {worldTopOne.verified && (
                      <BadgeCheck className="h-4 w-4 text-sky-500 shrink-0" />
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-x-2.5 gap-y-0.5 text-xs font-semibold text-slate-600">
                    <span>{worldTopOne.handle}</span>
                    <span aria-hidden="true">·</span>
                    <span>{getGenreLabel(worldTopOne.genre)}</span>
                    {worldTopOne.topSongTitle && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="truncate">Hit : « {worldTopOne.topSongTitle} »</span>
                      </>
                    )}
                  </div>

                  <div className="pt-1 flex items-center gap-3 flex-wrap">
                    <span className="rounded-full bg-slate-950 text-white px-3 py-1 text-xs font-mono font-extrabold">
                      {getMetricValue(worldTopOne)} {metricLabelMap[worldSort]}
                    </span>
                    <span className="text-xs font-mono text-slate-600 flex items-center gap-1">
                      <Headphones className="h-3.5 w-3.5" />
                      {formatCompactNumber(worldTopOne.fans)} fans
                    </span>
                  </div>
                </div>

                <div className="relative shrink-0">
                  <img
                    src={worldTopOne.avatarUrl}
                    alt={worldTopOne.stageName}
                    referrerPolicy="no-referrer"
                    className="h-20 w-20 sm:h-24 sm:w-24 rounded-2xl object-cover shadow-md"
                  />
                  <span
                    title={worldTopOne.isOnline ? 'En ligne' : 'Hors-ligne'}
                    className={`absolute -top-1.5 -right-1.5 h-4 w-4 rounded-full border-2 border-white ${
                      worldTopOne.isOnline ? 'bg-emerald-500' : 'bg-slate-400'
                    }`}
                  />
                </div>
              </div>

              <div className="inline-flex items-center gap-2 bg-white text-slate-950 rounded-b-2xl px-4 py-1.5 ml-3 shadow-md font-extrabold text-sm sm:text-base">
                <span>N°1 Mondial</span>
                <span className="text-[11px] font-semibold text-emerald-600">
                  {worldTopOne.isOnline ? 'En ligne' : 'Hors-ligne'}
                </span>
              </div>
            </motion.div>
          )}

          {/* World Ranked List (N°2+) */}
          {worldRest.length === 0 ? (
            <div className="liquid-glass rounded-3xl p-6 text-center space-y-1.5">
              <p className="text-sm font-bold text-slate-800 dark:text-slate-100">
                Tu es actuellement le seul artiste affiché dans ce classement.
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Dès que d’autres joueurs ouvrent ALL STARZ, leurs statistiques (auditeurs, fans, streams, fame) apparaîtront ici en direct via WebSocket.
              </p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {worldRest.map((p, idx) => {
                const rank = idx + 2;
                const isSelf = p.playerId === playerId;
                return (
                  <div
                    key={p.playerId}
                    className={`rounded-2xl p-3 flex items-center justify-between gap-3 transition ${
                      isSelf
                        ? 'bg-gradient-to-r from-violet-600/25 via-sky-500/20 to-white/95 dark:to-slate-900/90 ring-2 ring-violet-500 shadow-md'
                        : 'bg-white/95 dark:bg-white text-slate-950 shadow-sm'
                    }`}
                  >
                    <div className="relative shrink-0">
                      <img
                        src={p.avatarUrl}
                        alt={p.stageName}
                        referrerPolicy="no-referrer"
                        className="h-14 w-14 rounded-xl object-cover"
                      />
                      <span
                        title={p.isOnline ? 'En ligne' : 'Hors-ligne'}
                        className={`absolute -top-1 -right-1 h-3.5 w-3.5 rounded-full border-2 border-white ${
                          p.isOnline ? 'bg-emerald-500' : 'bg-slate-400'
                        }`}
                      />
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`text-sm sm:text-base font-extrabold truncate ${
                            isSelf ? 'text-slate-950 dark:text-white' : 'text-slate-950'
                          }`}
                        >
                          {p.stageName}
                        </span>
                        {p.verified && (
                          <BadgeCheck className="h-3.5 w-3.5 text-sky-500 shrink-0" />
                        )}
                        {isSelf && (
                          <span className="rounded-full bg-violet-600 text-white px-2 py-0.5 text-[10px] font-extrabold">
                            Toi
                          </span>
                        )}
                      </div>

                      <div
                        className={`text-xs font-semibold truncate ${
                          isSelf ? 'text-slate-700 dark:text-slate-200' : 'text-slate-600'
                        }`}
                      >
                        {p.handle} · {getGenreLabel(p.genre)}
                        {p.topSongTitle ? ` · « ${p.topSongTitle} »` : ''}
                      </div>

                      <div
                        className={`mt-0.5 text-[11px] font-mono tabular-nums ${
                          isSelf ? 'text-violet-700 dark:text-violet-300 font-bold' : 'text-slate-500'
                        }`}
                      >
                        {getMetricValue(p)} {metricLabelMap[worldSort]} ·{' '}
                        {formatCompactNumber(p.fans)} fans
                      </div>
                    </div>

                    <div className="text-right shrink-0 flex flex-col items-end gap-0.5 pr-1">
                      <span
                        className={`text-base sm:text-lg font-extrabold font-mono tabular-nums ${
                          isSelf ? 'text-violet-700 dark:text-violet-300' : 'text-slate-950'
                        }`}
                      >
                        N°:{rank}
                      </span>
                      <span
                        className={`text-[10px] font-bold ${
                          p.isOnline ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'
                        }`}
                      >
                        {p.isOnline ? 'En ligne' : 'Hors-ligne'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ====================================================================
       * SCREEN 2: TOP TITRES (EXISTING TOP 50 / 100 / 200 CHARTS)
       * ==================================================================== */}
      {screenMode === 'songs' && (
        <>
          {/* 3 Capsule Tabs (Canvas__12): Top 50 | Top 100 Global | Top 200 Global */}
          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 50 as const, label: 'Top 50' },
              { id: 100 as const, label: 'Top 100 Global' },
              { id: 200 as const, label: 'Top 200 Global' },
            ].map((tab) => {
              const active = tier === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => {
                    soundEngine.playGlassTap();
                    setTier(tab.id);
                  }}
                  className={`min-h-[48px] rounded-full px-3 py-2 text-xs sm:text-sm font-extrabold transition ${
                    active
                      ? 'bg-white text-slate-950 shadow-lg'
                      : 'liquid-glass text-slate-700 dark:text-slate-200 hover:brightness-110'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>

          {/* Top N°1 Spotlight Card (Canvas__12) */}
          {topOne && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="relative"
            >
              <div
                className={`rounded-3xl p-4 sm:p-5 flex items-center justify-between gap-4 shadow-xl ${
                  topOne.isPlayer
                    ? 'bg-gradient-to-br from-white via-sky-50 to-violet-100 text-slate-950 ring-2 ring-violet-500'
                    : 'bg-white/95 dark:bg-white text-slate-950'
                }`}
              >
                <div className="min-w-0 flex-1 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
                    <span>Titre :</span>
                    {topOne.isPlayer && (
                      <span className="inline-flex items-center gap-1 text-violet-700 font-extrabold">
                        <Sparkles className="h-3.5 w-3.5" /> Ton morceau
                      </span>
                    )}
                  </div>
                  <h2 className="text-lg sm:text-2xl font-extrabold tracking-tight text-slate-950 truncate">
                    {topOne.title}
                  </h2>
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs sm:text-sm font-semibold text-slate-600">
                    <span>{topOne.artistName}</span>
                    <span aria-hidden="true">·</span>
                    <span>{getGenreLabel(topOne.genre)}</span>
                  </div>
                  <div className="pt-1 flex items-center gap-3">
                    <div className="h-1.5 w-24 rounded-full bg-slate-950/90" />
                    <span className="text-xs font-mono font-bold tabular-nums text-slate-800">
                      {formatCompactNumber(topOne.weeklyStreams)} / sem.
                    </span>
                  </div>
                </div>

                {/* Cover Art Square */}
                <div
                  className={`h-24 w-24 sm:h-28 sm:w-28 rounded-2xl bg-gradient-to-br ${topOne.coverTone} shrink-0 flex items-center justify-center shadow-inner`}
                >
                  <Disc3 className="h-10 w-10 text-white/80" />
                </div>
              </div>

              {/* Attached Top N°1 Tag Tab (Canvas__12) */}
              <div className="inline-flex items-center gap-2 bg-white text-slate-950 rounded-b-2xl px-4 py-1.5 ml-3 shadow-md font-extrabold text-sm sm:text-base">
                <span>Top N°1</span>
                {renderDelta(topOne)}
              </div>
            </motion.div>
          )}

          {/* Ranked List N°2 .. N°50 / N°100 / N°200 */}
          {restRows.length === 0 ? (
            <div className="liquid-glass rounded-3xl p-8 text-center">
              <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">
                Aucun de tes morceaux n’est classé dans ce Top {tier} pour le moment.
              </p>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Enregistre des titres de haute qualité dans Music et lance une campagne AllGram ou Alltify.
              </p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {restRows.map((entry) => (
                <div
                  key={entry.id}
                  className={`rounded-2xl p-3 flex items-center justify-between gap-3 transition ${
                    entry.isPlayer
                      ? 'bg-gradient-to-r from-violet-600/25 via-sky-500/20 to-white/95 dark:to-slate-900/90 ring-2 ring-violet-500 shadow-md'
                      : 'bg-white/95 dark:bg-white text-slate-950 shadow-sm'
                  }`}
                >
                  {/* Left Cover */}
                  <div
                    className={`h-14 w-14 sm:h-16 sm:w-16 rounded-xl bg-gradient-to-br ${entry.coverTone} shrink-0 flex items-center justify-center shadow-inner`}
                  >
                    <Disc3 className="h-6 w-6 text-white/75" />
                  </div>

                  {/* Center Info */}
                  <div className="min-w-0 flex-1">
                    <div
                      className={`text-sm sm:text-base font-extrabold truncate ${
                        entry.isPlayer
                          ? 'text-slate-950 dark:text-white'
                          : 'text-slate-950'
                      }`}
                    >
                      {entry.title}
                    </div>
                    <div
                      className={`text-xs font-semibold truncate ${
                        entry.isPlayer
                          ? 'text-slate-700 dark:text-slate-200'
                          : 'text-slate-600'
                      }`}
                    >
                      {entry.artistName} · {getGenreLabel(entry.genre)}
                    </div>
                    <div
                      className={`mt-0.5 text-[11px] font-mono tabular-nums ${
                        entry.isPlayer
                          ? 'text-violet-700 dark:text-violet-300 font-bold'
                          : 'text-slate-500'
                      }`}
                    >
                      {formatCompactNumber(entry.weeklyStreams)} écoutes/sem.
                    </div>
                  </div>

                  {/* Right Rank N°:X */}
                  <div className="text-right shrink-0 flex flex-col items-end gap-0.5 pr-1">
                    <span
                      className={`text-base sm:text-lg font-extrabold font-mono tabular-nums ${
                        entry.isPlayer
                          ? 'text-violet-700 dark:text-violet-300'
                          : 'text-slate-950'
                      }`}
                    >
                      N°:{entry.rank}
                    </span>
                    {renderDelta(entry)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
};
