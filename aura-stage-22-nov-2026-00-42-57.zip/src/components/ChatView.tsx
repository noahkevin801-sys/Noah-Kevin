import React, { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ArrowLeft,
  BadgeCheck,
  Bot,
  Hash,
  MessageSquarePlus,
  Plus,
  Search,
  Send,
  Users,
  Wifi,
  WifiOff,
  X,
} from 'lucide-react';
import { CHAT_CONTACTS } from '../data/gameData';
import { GameState } from '../types/game';
import { OnlinePlayerProfile, PublicChatRoom, WorldSnapshot } from '../types/network';
import { buildDmRoomId } from '../services/realtimeClient';
import { formatCompactNumber, formatGameDate } from '../utils/format';
import { soundEngine } from '../utils/audio';

type ActiveConversation =
  | { kind: 'room'; room: PublicChatRoom }
  | { kind: 'dm'; other: OnlinePlayerProfile; roomId: string }
  | { kind: 'npc'; threadId: string };

interface ChatViewProps {
  playerId: string;
  gameState: GameState;
  world: WorldSnapshot;
  isOfflineMode: boolean;
  isSendingAi: boolean;
  onToggleOfflineMode: () => void;
  onStartOrOpenThread: (contactId: string) => void;
  onSendNpcMessage: (threadId: string, text: string) => void;
  onSendRoomOrDmMessage: (roomId: string, text: string) => void;
}

function formatClockTime(ts: number): string {
  try {
    return new Date(ts).toLocaleTimeString('fr-FR', {
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return 'Maintenant';
  }
}

export const ChatView: React.FC<ChatViewProps> = ({
  playerId,
  gameState,
  world,
  isOfflineMode,
  isSendingAi,
  onToggleOfflineMode,
  onStartOrOpenThread,
  onSendNpcMessage,
  onSendRoomOrDmMessage,
}) => {
  const { artist, chatThreads } = gameState;
  const [search, setSearch] = useState('');
  const [activeConv, setActiveConv] = useState<ActiveConversation | null>(null);
  const [showPicker, setShowPicker] = useState(false);
  const [pickerTab, setPickerTab] = useState<'rooms' | 'players' | 'ai'>('rooms');
  const [draft, setDraft] = useState('');

  const otherPlayers = useMemo(
    () => world.players.filter((p) => p.playerId !== playerId),
    [world.players, playerId]
  );
  const onlineOthersCount = otherPlayers.filter((p) => p.isOnline).length;

  // DM conversations that already have messages
  const activeDmPlayers = useMemo(() => {
    return otherPlayers.filter((other) => {
      const rid = buildDmRoomId(playerId, other.playerId);
      return world.chatMessages.some((m) => m.roomId === rid);
    });
  }, [otherPlayers, world.chatMessages, playerId]);

  const query = search.trim().toLowerCase();

  const filteredRooms = world.rooms.filter(
    (r) =>
      r.name.toLowerCase().includes(query) ||
      r.description.toLowerCase().includes(query)
  );

  const filteredDms = activeDmPlayers.filter(
    (p) =>
      p.stageName.toLowerCase().includes(query) ||
      p.handle.toLowerCase().includes(query)
  );

  const filteredNpcThreads = chatThreads.filter(
    (t) =>
      t.contactName.toLowerCase().includes(query) ||
      t.contactRole.toLowerCase().includes(query)
  );

  const handleOpenNpc = (contactId: string) => {
    soundEngine.playGlassTap();
    onStartOrOpenThread(contactId);
    setActiveConv({ kind: 'npc', threadId: `thread_${contactId}` });
    setShowPicker(false);
  };

  const handleOpenRoom = (room: PublicChatRoom) => {
    soundEngine.playGlassTap();
    setActiveConv({ kind: 'room', room });
    setShowPicker(false);
  };

  const handleOpenDm = (other: OnlinePlayerProfile) => {
    soundEngine.playGlassTap();
    const roomId = buildDmRoomId(playerId, other.playerId);
    setActiveConv({ kind: 'dm', other, roomId });
    setShowPicker(false);
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeConv || !draft.trim()) return;
    const text = draft.trim();
    setDraft('');
    soundEngine.playSuccessChord();

    if (activeConv.kind === 'npc') {
      onSendNpcMessage(activeConv.threadId, text);
    } else if (activeConv.kind === 'room') {
      onSendRoomOrDmMessage(activeConv.room.id, text);
    } else {
      onSendRoomOrDmMessage(activeConv.roomId, text);
    }
  };

  // ACTIVE CONVERSATION SCREEN
  if (activeConv) {
    if (activeConv.kind === 'npc') {
      const thread = chatThreads.find((t) => t.id === activeConv.threadId);
      if (thread) {
        return (
          <div className="space-y-4">
            <div className="liquid-glass rounded-3xl px-4 py-3 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => {
                  soundEngine.playGlassTap();
                  setActiveConv(null);
                }}
                className="min-h-[42px] flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white"
              >
                <ArrowLeft className="h-4 w-4" />
                <span>Chats</span>
              </button>

              <div className="text-center min-w-0">
                <div className="text-sm font-extrabold text-slate-900 dark:text-white truncate flex items-center justify-center gap-1">
                  <span>{thread.contactName}</span>
                  <Bot className="h-3.5 w-3.5 text-violet-400 shrink-0" />
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                  {thread.contactRole} · {isOfflineMode ? 'IA Hors-ligne' : 'IA Gemini Live'}
                </div>
              </div>

              <span className="w-12" />
            </div>

            <div className="liquid-glass rounded-3xl p-4 sm:p-5 flex flex-col min-h-[55vh] max-h-[65vh]">
              <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                {thread.messages.map((msg) => {
                  const isPlayer = msg.sender === 'player';
                  return (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${isPlayer ? 'items-end' : 'items-start'}`}
                    >
                      <div
                        className={`max-w-[82%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                          isPlayer
                            ? 'bg-violet-600 text-white rounded-br-sm'
                            : 'liquid-glass-subtle text-slate-900 dark:text-slate-100 rounded-bl-sm'
                        }`}
                      >
                        {msg.text}
                      </div>
                      <span className="mt-1 text-[10px] font-mono text-slate-500 dark:text-slate-400 px-1">
                        {msg.timeLabel}
                      </span>
                    </div>
                  );
                })}
                {isSendingAi && (
                  <div className="text-xs italic text-slate-400 px-2">
                    {thread.contactName} est en train d’écrire...
                  </div>
                )}
              </div>

              <form onSubmit={handleSend} className="mt-4 pt-3 border-t border-slate-900/10 dark:border-white/10 flex gap-2">
                <input
                  type="text"
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  placeholder={`Écrire à ${thread.contactName}...`}
                  className="flex-1 min-h-[46px] rounded-full liquid-glass-subtle px-4 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-500"
                />
                <button
                  type="submit"
                  disabled={!draft.trim()}
                  aria-label="Envoyer"
                  className="min-h-[46px] min-w-[46px] rounded-full bg-violet-600 text-white flex items-center justify-center disabled:opacity-40 active:scale-95 transition"
                >
                  <Send className="h-4 w-4" />
                </button>
              </form>
            </div>
          </div>
        );
      }
      return (
        <div className="liquid-glass rounded-3xl p-5 text-center space-y-3">
          <p className="text-sm text-slate-600 dark:text-slate-300">Conversation introuvable.</p>
          <button
            type="button"
            onClick={() => setActiveConv(null)}
            className="min-h-[40px] rounded-full bg-violet-600 text-white px-5 text-xs font-bold"
          >
            Retour
          </button>
        </div>
      );
    }

    const roomId =
      activeConv.kind === 'room' ? activeConv.room.id : activeConv.roomId;
    const roomTitle =
      activeConv.kind === 'room'
        ? activeConv.room.name
        : activeConv.other.stageName;
    const roomSubtitle =
      activeConv.kind === 'room'
        ? isOfflineMode
          ? 'Salon IA Hors-ligne'
          : `${Math.max(1, onlineOthersCount + 1)} joueurs sur le serveur`
        : `${activeConv.other.handle} · ${activeConv.other.isOnline ? 'En ligne' : 'Hors-ligne'}`;

    const messages = world.chatMessages.filter((m) => m.roomId === roomId);

    return (
      <div className="space-y-4">
        <div className="liquid-glass rounded-3xl px-4 py-3 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => {
              soundEngine.playGlassTap();
              setActiveConv(null);
            }}
            className="min-h-[42px] flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Chats</span>
          </button>

          <div className="text-center min-w-0">
            <div className="text-sm font-extrabold text-slate-900 dark:text-white truncate flex items-center justify-center gap-1.5">
              <span>{roomTitle}</span>
              {activeConv.kind === 'dm' && activeConv.other.verified && (
                <BadgeCheck className="h-3.5 w-3.5 text-sky-500 shrink-0" />
              )}
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
              {roomSubtitle}
            </div>
          </div>

          <button
            type="button"
            onClick={onToggleOfflineMode}
            className="text-[10px] font-bold rounded-full liquid-glass-subtle px-2.5 py-1 text-slate-700 dark:text-slate-200 shrink-0"
          >
            {isOfflineMode ? 'IA Offline' : 'Live'}
          </button>
        </div>

        <div className="liquid-glass rounded-3xl p-4 sm:p-5 flex flex-col min-h-[55vh] max-h-[65vh]">
          <div className="flex-1 overflow-y-auto space-y-3 pr-1">
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-10 text-xs text-slate-500 dark:text-slate-400">
                <p>Aucun message dans cette discussion pour l’instant.</p>
                <p className="mt-1">Envoie le premier message !</p>
              </div>
            ) : (
              messages.map((msg) => {
                const isSelf = msg.senderId === playerId;
                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${isSelf ? 'items-end' : 'items-start'}`}
                  >
                    {!isSelf && (
                      <div className="flex items-center gap-1.5 mb-1 px-1">
                        <img
                          src={msg.senderAvatar || '/src/assets/images/artist_portrait_pop_1795252244416.jpg'}
                          alt={msg.senderName}
                          className="h-4 w-4 rounded-full object-cover"
                        />
                        <span className="text-[11px] font-bold text-slate-700 dark:text-slate-200">
                          {msg.senderName}
                        </span>
                        <span className="text-[10px] text-slate-500">{msg.senderHandle}</span>
                        {msg.isAi && (
                          <span className="rounded bg-amber-500/20 text-amber-400 px-1.5 py-0.2 text-[9px] font-extrabold">
                            IA
                          </span>
                        )}
                      </div>
                    )}
                    <div
                      className={`max-w-[82%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                        isSelf
                          ? 'bg-violet-600 text-white rounded-br-sm'
                          : 'liquid-glass-subtle text-slate-900 dark:text-slate-100 rounded-bl-sm'
                      }`}
                    >
                      {msg.text}
                    </div>
                    <span className="mt-1 text-[10px] font-mono text-slate-500 dark:text-slate-400 px-1">
                      {formatClockTime(msg.createdAt)}
                    </span>
                  </div>
                );
              })
            )}
          </div>

          <form onSubmit={handleSend} className="mt-4 pt-3 border-t border-slate-900/10 dark:border-white/10 flex gap-2">
            <input
              type="text"
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              placeholder={
                isOfflineMode
                  ? 'Écrire un message (l’IA te répondra)...'
                  : 'Écrire aux vrais joueurs en direct...'
              }
              className="flex-1 min-h-[46px] rounded-full liquid-glass-subtle px-4 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-500"
            />
            <button
              type="submit"
              disabled={!draft.trim()}
              aria-label="Envoyer"
              className="min-h-[46px] min-w-[46px] rounded-full bg-violet-600 text-white flex items-center justify-center disabled:opacity-40 active:scale-95 transition"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>
      </div>
    );
  }

  const hasAnyVisible =
    filteredRooms.length > 0 || filteredDms.length > 0 || filteredNpcThreads.length > 0;

  return (
    <div className="relative min-h-[66vh] flex flex-col space-y-4">
      {/* Top Date Capsule + Server / Offline AI Status Pill (Canvas__20) */}
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <span className="inline-block liquid-glass rounded-full px-4 py-2 text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
          {formatGameDate(artist.dayOffset)}
        </span>

        <button
          type="button"
          onClick={() => {
            soundEngine.playGlassTap();
            onToggleOfflineMode();
          }}
          className="liquid-glass rounded-full px-3.5 py-2 text-xs font-extrabold flex items-center gap-1.5 text-slate-900 dark:text-white active:scale-95 transition"
        >
          {isOfflineMode ? (
            <>
              <WifiOff className="h-3.5 w-3.5 text-amber-400" />
              <span>IA Hors-ligne</span>
            </>
          ) : (
            <>
              <Wifi className="h-3.5 w-3.5 text-emerald-400" />
              <span>Serveur Live · {Math.max(1, onlineOthersCount + 1)} en ligne</span>
            </>
          )}
        </button>
      </div>

      {/* Search Bar (Canvas__20) */}
      <div className="relative">
        <Search className="h-5 w-5 text-slate-500 dark:text-slate-400 absolute left-5 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Recherche un salon, un joueur ou un contact"
          className="w-full min-h-[56px] rounded-full liquid-glass pl-12 pr-5 text-base font-semibold text-slate-900 dark:text-white placeholder:text-slate-500 dark:placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-500"
        />
      </div>

      {/* Conversations List */}
      {!hasAnyVisible ? (
        <div className="flex-1 flex flex-col items-center justify-center py-16 text-center space-y-5">
          <p className="text-lg sm:text-xl font-bold text-slate-500 dark:text-slate-400">
            Aucun résultat
          </p>
          <button
            type="button"
            onClick={() => {
              soundEngine.playGlassTap();
              setShowPicker(true);
            }}
            className="liquid-interactive min-h-[48px] rounded-full liquid-glass px-7 py-3 text-sm sm:text-base font-extrabold text-slate-900 dark:text-white active:scale-95 transition"
          >
            Commencer à discuter
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {/* 1. Salons Live Multi-joueurs */}
          {filteredRooms.length > 0 && (
            <div className="space-y-2">
              <div className="text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 px-2 flex items-center justify-between">
                <span>Salons Multi-joueurs</span>
                <span>{isOfflineMode ? 'Relais IA actif' : 'Temps réel'}</span>
              </div>
              {filteredRooms.map((room) => {
                const roomMsgs = world.chatMessages.filter((m) => m.roomId === room.id);
                const last = roomMsgs[roomMsgs.length - 1];
                return (
                  <button
                    key={room.id}
                    type="button"
                    onClick={() => handleOpenRoom(room)}
                    className="w-full liquid-glass rounded-3xl p-4 text-left flex items-center justify-between gap-3 hover:brightness-105 active:scale-[0.99] transition"
                  >
                    <div className="flex items-center gap-3.5 min-w-0">
                      <div className="h-12 w-12 rounded-full bg-gradient-to-br from-emerald-500 to-sky-600 text-white font-extrabold flex items-center justify-center shrink-0">
                        <Hash className="h-5 w-5" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white truncate">
                            {room.name}
                          </span>
                          <span className="rounded-full bg-emerald-500/15 text-emerald-500 px-2 py-0.5 text-[10px] font-extrabold">
                            {room.badge}
                          </span>
                        </div>
                        <p className="mt-0.5 text-xs text-slate-600 dark:text-slate-300 truncate">
                          {last ? `${last.senderName} : ${last.text}` : room.description}
                        </p>
                      </div>
                    </div>
                    <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400 shrink-0">
                      {last ? formatClockTime(last.createdAt) : 'Ouvert'}
                    </span>
                  </button>
                );
              })}
            </div>
          )}

          {/* 2. Messages privés avec de vrais joueurs */}
          {filteredDms.length > 0 && (
            <div className="space-y-2">
              <div className="text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 px-2">
                Vrais Joueurs · Messages Privés
              </div>
              {filteredDms.map((other) => {
                const rid = buildDmRoomId(playerId, other.playerId);
                const msgs = world.chatMessages.filter((m) => m.roomId === rid);
                const last = msgs[msgs.length - 1];
                return (
                  <button
                    key={other.playerId}
                    type="button"
                    onClick={() => handleOpenDm(other)}
                    className="w-full liquid-glass rounded-3xl p-4 text-left flex items-center justify-between gap-3 hover:brightness-105 active:scale-[0.99] transition"
                  >
                    <div className="flex items-center gap-3.5 min-w-0">
                      <img
                        src={other.avatarUrl}
                        alt={other.stageName}
                        className="h-12 w-12 rounded-full object-cover shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white truncate">
                            {other.stageName}
                          </span>
                          {other.isOnline && (
                            <span className="h-2 w-2 rounded-full bg-emerald-400 shrink-0" />
                          )}
                        </div>
                        <p className="mt-0.5 text-xs text-slate-600 dark:text-slate-300 truncate">
                          {last?.text ?? other.handle}
                        </p>
                      </div>
                    </div>
                    <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400 shrink-0">
                      {last ? formatClockTime(last.createdAt) : ''}
                    </span>
                  </button>
                );
              })}
            </div>
          )}

          {/* 3. Contacts Industrie IA */}
          {filteredNpcThreads.length > 0 && (
            <div className="space-y-2">
              <div className="text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 px-2">
                Contacts Industrie & IA
              </div>
              {filteredNpcThreads.map((thread) => {
                const lastMsg = thread.messages[thread.messages.length - 1];
                return (
                  <button
                    key={thread.id}
                    type="button"
                    onClick={() => handleOpenNpc(thread.contactId)}
                    className="w-full liquid-glass rounded-3xl p-4 text-left flex items-center justify-between gap-3 hover:brightness-105 active:scale-[0.99] transition"
                  >
                    <div className="flex items-center gap-3.5 min-w-0">
                      <div className="h-12 w-12 rounded-full bg-gradient-to-br from-violet-500 to-sky-500 text-white font-extrabold flex items-center justify-center shrink-0">
                        {thread.contactName.charAt(0)}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white truncate">
                            {thread.contactName}
                          </span>
                          <span className="text-xs text-slate-500 dark:text-slate-400 truncate">
                            · {thread.contactRole}
                          </span>
                        </div>
                        <p className="mt-0.5 text-xs text-slate-600 dark:text-slate-300 truncate">
                          {lastMsg?.text}
                        </p>
                      </div>
                    </div>
                    <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400 shrink-0">
                      {lastMsg?.timeLabel}
                    </span>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Floating '+' New Chat Button (Canvas__20) */}
      <button
        type="button"
        onClick={() => {
          soundEngine.playGlassTap();
          setShowPicker(true);
        }}
        aria-label="Nouvelle conversation"
        className="fixed bottom-24 right-5 lg:bottom-8 lg:right-8 z-30 h-14 w-14 rounded-full liquid-glass shadow-xl flex items-center justify-center text-slate-900 dark:text-white hover:scale-105 active:scale-95 transition"
      >
        <Plus className="h-7 w-7 stroke-[2.5]" />
      </button>

      {/* Multi-Source Picker Modal (Salons Live / Vrais Joueurs / Contacts IA) */}
      <AnimatePresence>
        {showPicker && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/55 backdrop-blur-md p-3 sm:p-6"
            role="dialog"
            aria-modal="true"
          >
            <motion.div
              initial={{ opacity: 0, y: 24, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.96 }}
              className="w-full max-w-md liquid-glass rounded-3xl p-5 sm:p-6 space-y-4"
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <MessageSquarePlus className="h-5 w-5 text-violet-500" />
                  <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">
                    Nouvelle discussion
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setShowPicker(false)}
                  aria-label="Fermer"
                  className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-900/10 dark:hover:bg-white/10"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="grid grid-cols-3 gap-1.5 liquid-glass-subtle rounded-2xl p-1">
                {[
                  { id: 'rooms' as const, label: 'Salons', Icon: Hash },
                  { id: 'players' as const, label: `Joueurs (${otherPlayers.length})`, Icon: Users },
                  { id: 'ai' as const, label: 'Contacts IA', Icon: Bot },
                ].map(({ id, label, Icon }) => (
                  <button
                    key={id}
                    type="button"
                    onClick={() => setPickerTab(id)}
                    className={`min-h-[38px] rounded-xl text-xs font-extrabold flex items-center justify-center gap-1 ${
                      pickerTab === id
                        ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950'
                        : 'text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    <Icon className="h-3.5 w-3.5" />
                    <span>{label}</span>
                  </button>
                ))}
              </div>

              <div className="space-y-2 max-h-[55vh] overflow-y-auto pr-1">
                {pickerTab === 'rooms' &&
                  world.rooms.map((r) => (
                    <button
                      key={r.id}
                      type="button"
                      onClick={() => handleOpenRoom(r)}
                      className="w-full liquid-glass-subtle rounded-2xl p-3.5 text-left flex items-center gap-3 hover:brightness-110 transition"
                    >
                      <div className="h-11 w-11 rounded-full bg-gradient-to-br from-emerald-500 to-sky-600 text-white font-extrabold flex items-center justify-center shrink-0">
                        <Hash className="h-5 w-5" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="text-sm font-bold text-slate-900 dark:text-white truncate">
                          {r.name}
                        </div>
                        <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                          {r.description}
                        </div>
                      </div>
                    </button>
                  ))}

                {pickerTab === 'players' &&
                  (otherPlayers.length === 0 ? (
                    <div className="text-center py-8 text-xs text-slate-500 dark:text-slate-400">
                      Aucun autre joueur détecté sur le serveur pour le moment. Partage le lien ou discute dans le Salon Général !
                    </div>
                  ) : (
                    otherPlayers.map((p) => (
                      <button
                        key={p.playerId}
                        type="button"
                        onClick={() => handleOpenDm(p)}
                        className="w-full liquid-glass-subtle rounded-2xl p-3.5 text-left flex items-center gap-3 hover:brightness-110 transition"
                      >
                        <img
                          src={p.avatarUrl}
                          alt={p.stageName}
                          className="h-11 w-11 rounded-full object-cover shrink-0"
                        />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <span className="text-sm font-bold text-slate-900 dark:text-white truncate">
                              {p.stageName}
                            </span>
                            {p.isOnline && (
                              <span className="h-2 w-2 rounded-full bg-emerald-400 shrink-0" />
                            )}
                          </div>
                          <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                            {p.handle} · {formatCompactNumber(p.fans)} fans
                          </div>
                        </div>
                      </button>
                    ))
                  ))}

                {pickerTab === 'ai' &&
                  CHAT_CONTACTS.map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => handleOpenNpc(c.id)}
                      className="w-full liquid-glass-subtle rounded-2xl p-3.5 text-left flex items-center gap-3 hover:brightness-110 active:scale-[0.99] transition"
                    >
                      <div className="h-11 w-11 rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-500 text-white font-extrabold flex items-center justify-center shrink-0">
                        {c.name.charAt(0)}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="text-sm font-bold text-slate-900 dark:text-white truncate">
                          {c.name}
                        </div>
                        <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                          {c.role} · {c.handle}
                        </div>
                      </div>
                    </button>
                  ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
