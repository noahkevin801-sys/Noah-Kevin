import React from 'react';

interface LiquidBackgroundProps {
  hype: number;
}

export const LiquidBackground: React.FC<LiquidBackgroundProps> = ({ hype }) => {
  const intensityOpacity = Math.min(0.85, 0.45 + hype / 220);

  return (
    <div
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 -z-10 overflow-hidden bg-[#f2f5fa] dark:bg-[#070a11] transition-colors duration-500"
    >
      {/* Primary refracting liquid caustic lobe */}
      <div
        className="animate-liquid-a absolute -top-[18%] -left-[12%] h-[68vh] w-[72vw] rounded-full blur-[90px] dark:blur-[110px]"
        style={{
          opacity: intensityOpacity,
          background:
            'radial-gradient(circle at 40% 40%, rgba(125, 185, 255, 0.55), rgba(186, 214, 255, 0.25) 55%, transparent 78%)',
        }}
      />

      {/* Secondary warm champagne glass refraction */}
      <div
        className="animate-liquid-b absolute top-[22%] -right-[14%] h-[62vh] w-[66vw] rounded-full blur-[100px] dark:blur-[120px]"
        style={{
          opacity: intensityOpacity * 0.9,
          background:
            'radial-gradient(circle at 55% 45%, rgba(246, 206, 155, 0.48), rgba(226, 232, 248, 0.22) 55%, transparent 80%)',
        }}
      />

      {/* Deep bottom mist refraction */}
      <div
        className="animate-liquid-a absolute -bottom-[20%] left-[18%] h-[55vh] w-[64vw] rounded-full blur-[95px]"
        style={{
          animationDelay: '-7s',
          opacity: 0.55,
          background:
            'radial-gradient(circle at 50% 50%, rgba(147, 197, 253, 0.35), rgba(203, 213, 225, 0.16) 60%, transparent 82%)',
        }}
      />

      {/* Dark mode subtle deep indigo & amber refractions */}
      <div
        className="hidden dark:block animate-liquid-b absolute top-[10%] left-[25%] h-[50vh] w-[55vw] rounded-full blur-[120px]"
        style={{
          opacity: 0.42,
          background:
            'radial-gradient(circle at 50% 50%, rgba(56, 118, 220, 0.36), rgba(217, 155, 82, 0.14) 55%, transparent 80%)',
        }}
      />
    </div>
  );
};
