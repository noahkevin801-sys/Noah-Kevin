import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Check,
  Disc3,
  Dices,
  Layers,
  Megaphone,
  Plus,
  Search,
  Sparkles,
  Video,
  X,
} from 'lucide-react';
import {
  CLIP_OPTIONS,
  COVER_ART_URL,
  FEATURING_ARTISTS,
  GENRES,
  PROJECT_FORMAT_RULES,
  PROMO_CAMPAIGNS,
  SONG_MOODS,
  SONG_THEMES,
  STUDIO_TIERS,
  VOCAL_STYLES,
} from '../data/gameData';
import { GameState, GenreId, ProjectFormat, Song } from '../types/game';
import {
  formatCompactNumber,
  formatCurrency,
  formatGameDate,
  getCertificationLabel,
  getGenreLabel,
  getLifecycleLabel,
  getProjectFormatLabel,
} from '../utils/format';
import { soundEngine } from '../utils/audio';

interface MusicCenterViewProps {
  gameState: GameState;
  onRecordSong: (params: {
    title: string;
    genre: GenreId;
    mood: string;
    theme: string;
    vocalStyle: string;
    studioId: string;
    featuringName: string | null;
  }) => { error?: string };
  onReleaseSong: (songId: string, promoIds: string[]) => { error?: string };
  onReleaseProject: (
    title: string,
    format: ProjectFormat,
    trackIds: string[],
    parentAlbumId?: string | null
  ) => { error?: string };
  onPromoteSong: (songId: string, promoId: string) => { error?: string };
  onCreateClip: (songId: string, clipId: string) => { error?: string };
}

type MusicSegment = 'single' | 'albums' | 'deluxe';
type CreateMode = 'studio' | 'publish_single' | 'publish_project' | 'publish_deluxe';

export const MusicCenterView: React.FC<MusicCenterViewProps> = ({
  gameState,
  onRecordSong,
  onReleaseSong,
  onReleaseProject,
  onPromoteSong,
  onCreateClip,
}) => {
  const { artist, songs, projects } = gameState;
  const [segment, setSegment] = useState<MusicSegment>('single');
  const [searchQuery, setSearchQuery] = useState('');
  const [feedback, setFeedback] = useState<string | null>(null);

  // Create Drawer/Modal State
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [createMode, setCreateMode] = useState<CreateMode>('studio');

  // Studio recording state
  const [songGenre, setSongGenre] = useState<GenreId>(artist.genre);
  const activeGenreDef = GENRES.find((g) => g.id === songGenre) ?? GENRES[0];
  const [title, setTitle] = useState(activeGenreDef.songTitles[0]);
  const [mood, setMood] = useState(SONG_MOODS[0]);
  const [theme, setTheme] = useState(SONG_THEMES[0]);
  const [vocalStyle, setVocalStyle] = useState(VOCAL_STYLES[0]);
  const [studioId, setStudioId] = useState(STUDIO_TIERS[0].id);
  const [featuringName, setFeaturingName] = useState<string | null>(null);

  // Release Single state
  const [selectedPromos, setSelectedPromos] = useState<string[]>([]);

  // Release Project / Deluxe state
  const [projectTitle, setProjectTitle] = useState('Prisme Édition');
  const [projectFormat, setProjectFormat] = useState<ProjectFormat>('album');
  const [selectedProjectTracks, setSelectedProjectTracks] = useState<string[]>([]);
  const [parentAlbumId, setParentAlbumId] = useState<string>('');

  // Song Analytics Modal
  const [inspectedSongId, setInspectedSongId] = useState<string | null>(null);
  const inspectedSong: Song | null =
    songs.find((s) => s.id === inspectedSongId) ?? null;

  const vaultSongs = songs.filter((s) => !s.released);
  const releasedSingles = songs.filter((s) => s.released && !s.projectId);
  const releasedAlbums = projects.filter(
    (p) => p.format === 'album' || p.format === 'ep' || p.format === 'mixtape'
  );
  const releasedDeluxes = projects.filter((p) => p.format === 'deluxe');

  const q = searchQuery.trim().toLowerCase();
  const filteredSingles = releasedSingles.filter(
    (s) =>
      s.title.toLowerCase().includes(q) ||
      getGenreLabel(s.genre).toLowerCase().includes(q)
  );
  const filteredAlbums = releasedAlbums.filter((p) =>
    p.title.toLowerCase().includes(q)
  );
  const filteredDeluxes = releasedDeluxes.filter((p) =>
    p.title.toLowerCase().includes(q)
  );

  const selectedStudio =
    STUDIO_TIERS.find((s) => s.id === studioId) ?? STUDIO_TIERS[0];
  const selectedFeat = featuringName
    ? FEATURING_ARTISTS.find((f) => f.name === featuringName) ?? null
    : null;
  const totalRecordCost = selectedStudio.cost + (selectedFeat?.cost ?? 0);

  const promoTotalCost = PROMO_CAMPAIGNS.filter((p) =>
    selectedPromos.includes(p.id)
  ).reduce((sum, p) => sum + p.cost, 0);

  const openCreatorForSegment = (seg: MusicSegment) => {
    soundEngine.playGlassTap();
    if (vaultSongs.length === 0) {
      setCreateMode('studio');
    } else if (seg === 'single') {
      setCreateMode('publish_single');
    } else if (seg === 'albums') {
      setProjectFormat('album');
      setCreateMode('publish_project');
    } else {
      setCreateMode('publish_deluxe');
      if (releasedAlbums.length > 0 && !parentAlbumId) {
        setParentAlbumId(releasedAlbums[0].id);
      }
    }
    setShowCreateModal(true);
  };

  const handleRandomTitle = () => {
    soundEngine.playGlassTap();
    const pool = activeGenreDef.songTitles;
    setTitle(pool[Math.floor(Math.random() * pool.length)]);
  };

  const handleRecord = (e: React.FormEvent) => {
    e.preventDefault();
    const res = onRecordSong({
      title,
      genre: songGenre,
      mood,
      theme,
      vocalStyle,
      studioId,
      featuringName,
    });
    if (res.error) {
      setFeedback(res.error);
      return;
    }
    soundEngine.playSuccessChord();
    const recordedName = title.trim() || activeGenreDef.songTitles[0];
    setFeedback(`« ${recordedName} » enregistré dans ton coffre studio.`);
    const nextIdx = (songs.length + 1) % activeGenreDef.songTitles.length;
    setTitle(activeGenreDef.songTitles[nextIdx]);
    setFeaturingName(null);
    setCreateMode('publish_single');
  };

  const handlePublishSingle = (songId: string) => {
    const res = onReleaseSong(songId, selectedPromos);
    if (res.error) {
      setFeedback(res.error);
      return;
    }
    soundEngine.playSuccessChord();
    setSelectedPromos([]);
    setShowCreateModal(false);
    setSegment('single');
    setFeedback('Single publié sur Alltify et classé sur Chartz.');
  };

  const activeFormatRule =
    PROJECT_FORMAT_RULES.find(
      (r) => r.format === (createMode === 'publish_deluxe' ? 'deluxe' : projectFormat)
    ) ?? PROJECT_FORMAT_RULES[3];

  const handlePublishProject = () => {
    const targetFormat: ProjectFormat =
      createMode === 'publish_deluxe' ? 'deluxe' : projectFormat;
    const res = onReleaseProject(
      projectTitle,
      targetFormat,
      selectedProjectTracks,
      targetFormat === 'deluxe' ? parentAlbumId || null : null
    );
    if (res.error) {
      setFeedback(res.error);
      return;
    }
    soundEngine.playSuccessChord();
    setSelectedProjectTracks([]);
    setShowCreateModal(false);
    setSegment(targetFormat === 'deluxe' ? 'deluxe' : 'albums');
    setFeedback(`${getProjectFormatLabel(targetFormat)} publié avec succès !`);
  };

  const togglePromo = (id: string) => {
    soundEngine.playGlassTap();
    setSelectedPromos((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  return (
    <div className="space-y-4">
      {/* Row 1 (Canvas__17/18/19): Date capsule + Vault status */}
      <div className="flex items-center justify-between gap-3">
        <span className="liquid-glass rounded-full px-4 py-2 text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
          {formatGameDate(artist.dayOffset)}
        </span>

        {vaultSongs.length > 0 && (
          <button
            type="button"
            onClick={() => {
              soundEngine.playGlassTap();
              setCreateMode('publish_single');
              setShowCreateModal(true);
            }}
            className="liquid-glass-subtle rounded-full px-3.5 py-1.5 text-xs font-bold text-violet-700 dark:text-violet-300"
          >
            {vaultSongs.length} inédit{vaultSongs.length > 1 ? 's' : ''} en coffre
          </button>
        )}
      </div>

      {/* Row 2 (Canvas__17/18/19): Search Input + '+' Create Button */}
      <div className="flex items-center gap-2.5">
        <div className="relative flex-1">
          <Search className="h-5 w-5 text-slate-500 dark:text-slate-400 absolute left-5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Recherche"
            className="w-full min-h-[56px] rounded-full liquid-glass pl-12 pr-5 text-base font-semibold text-slate-900 dark:text-white placeholder:text-slate-500 dark:placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-500"
          />
        </div>

        <button
          type="button"
          onClick={() => openCreatorForSegment(segment)}
          aria-label="Créer ou publier de la musique"
          className="liquid-interactive h-[56px] w-[56px] rounded-2xl liquid-glass flex items-center justify-center text-slate-900 dark:text-white shrink-0 active:scale-95 transition"
        >
          <Plus className="h-7 w-7 stroke-[2.5]" />
        </button>
      </div>

      {/* Row 3 (Canvas__17/18/19): Segmented Pill Switcher Single | Albums | Deluxe */}
      <div className="flex justify-center">
        <div className="liquid-glass rounded-full p-1.5 inline-grid grid-cols-3 gap-1 w-full max-w-md">
          {[
            { id: 'single' as const, label: 'Single' },
            { id: 'albums' as const, label: 'Albums' },
            { id: 'deluxe' as const, label: 'Deluxe' },
          ].map((tab) => {
            const active = segment === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  soundEngine.playGlassTap();
                  setSegment(tab.id);
                }}
                className={`relative min-h-[46px] rounded-full px-3 text-sm sm:text-base font-extrabold transition-colors ${
                  active
                    ? 'text-slate-950 dark:text-white'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                <span className="relative z-10">{tab.label}</span>
                {active && (
                  <motion.span
                    layoutId="music-segment-underline"
                    transition={{ type: 'spring', stiffness: 460, damping: 34 }}
                    className="absolute bottom-1.5 left-1/2 -translate-x-1/2 w-12 h-1.5 rounded-full bg-slate-950 dark:bg-white shadow"
                  />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {feedback && (
        <div className="liquid-glass-subtle rounded-2xl px-4 py-3 text-sm font-medium text-sky-800 dark:text-sky-200 flex items-center justify-between gap-3">
          <span>{feedback}</span>
          <button
            type="button"
            onClick={() => setFeedback(null)}
            className="text-xs font-bold underline shrink-0"
          >
            Fermer
          </button>
        </div>
      )}

      {/* Vault Quick Banner when user has unreleased tracks */}
      {vaultSongs.length > 0 && (
        <div className="liquid-glass rounded-3xl p-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="text-sm font-extrabold text-slate-900 dark:text-white">
              Coffre Studio · {vaultSongs.length} morceau{vaultSongs.length > 1 ? 'x' : ''} prêt{vaultSongs.length > 1 ? 's' : ''}
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300">
              Publie un morceau en Single ou assemble un Album / Deluxe.
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              soundEngine.playGlassTap();
              setCreateMode(segment === 'single' ? 'publish_single' : segment === 'albums' ? 'publish_project' : 'publish_deluxe');
              setShowCreateModal(true);
            }}
            className="min-h-[42px] rounded-full bg-violet-600 text-white px-4 py-2 text-xs font-extrabold active:scale-95 transition"
          >
            Publier maintenant
          </button>
        </div>
      )}

      {/* SEGMENT 1: SINGLE */}
      {segment === 'single' && (
        <>
          {filteredSingles.length === 0 ? (
            <div className="min-h-[42vh] flex flex-col items-center justify-center text-center space-y-4 py-12">
              <p className="text-lg sm:text-xl font-bold text-slate-500 dark:text-slate-400">
                Aucun single
              </p>
              <button
                type="button"
                onClick={() => openCreatorForSegment('single')}
                className="liquid-interactive min-h-[46px] rounded-full liquid-glass px-6 py-2.5 text-sm font-extrabold text-slate-900 dark:text-white active:scale-95 transition"
              >
                {vaultSongs.length > 0 ? 'Publier un single' : 'Enregistrer un titre'}
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredSingles.map((song) => (
                <button
                  key={song.id}
                  type="button"
                  onClick={() => {
                    soundEngine.playGlassTap();
                    setInspectedSongId(song.id);
                  }}
                  className="w-full liquid-glass rounded-3xl p-4 flex items-center justify-between gap-4 text-left hover:brightness-105 active:scale-[0.99] transition"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <img
                      src={COVER_ART_URL}
                      alt={song.title}
                      referrerPolicy="no-referrer"
                      className="h-14 w-14 rounded-2xl object-cover shrink-0 shadow"
                    />
                    <div className="min-w-0">
                      <div className="text-base font-extrabold text-slate-900 dark:text-white truncate">
                        {song.title}
                        {song.featuringArtist ? ` (feat. ${song.featuringArtist})` : ''}
                      </div>
                      <div className="mt-0.5 text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums truncate">
                        {getGenreLabel(song.genre)} · {getLifecycleLabel(song.lifecyclePhase)} · Q.{song.quality}
                        {song.hasClip ? ' · Clip AllTub' : ''}
                        {song.currentChartPos ? ` · Top #${song.currentChartPos}` : ''}
                      </div>
                      {song.certification !== 'none' && (
                        <div className="mt-0.5 text-[11px] font-bold text-amber-600 dark:text-amber-300">
                          {getCertificationLabel(song.certification)}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="text-right shrink-0 font-mono tabular-nums">
                    <div className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">
                      {formatCompactNumber(song.totalStreams)}
                    </div>
                    <div className="text-[11px] text-emerald-600 dark:text-emerald-300">
                      +{formatCompactNumber(song.dailyStreams)}/j
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </>
      )}

      {/* SEGMENT 2: ALBUMS (EP, Mixtapes, Albums) */}
      {segment === 'albums' && (
        <>
          {filteredAlbums.length === 0 ? (
            <div className="min-h-[42vh] flex flex-col items-center justify-center text-center space-y-4 py-12">
              <p className="text-lg sm:text-xl font-bold text-slate-500 dark:text-slate-400">
                Aucun Album
              </p>
              <button
                type="button"
                onClick={() => openCreatorForSegment('albums')}
                className="liquid-interactive min-h-[46px] rounded-full liquid-glass px-6 py-2.5 text-sm font-extrabold text-slate-900 dark:text-white active:scale-95 transition"
              >
                Créer un Album / EP
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {filteredAlbums.map((proj) => {
                const projTracks = songs.filter((s) => proj.trackIds.includes(s.id));
                return (
                  <div
                    key={proj.id}
                    className="liquid-glass rounded-3xl p-4 space-y-3"
                  >
                    <div className="flex items-center gap-3.5">
                      <img
                        src={COVER_ART_URL}
                        alt={proj.title}
                        referrerPolicy="no-referrer"
                        className="h-16 w-16 rounded-2xl object-cover shrink-0 shadow"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="text-xs font-bold text-violet-600 dark:text-violet-300">
                          {getProjectFormatLabel(proj.format)} · Sem. {proj.releaseWeek}
                        </div>
                        <h3 className="text-base font-extrabold text-slate-900 dark:text-white truncate">
                          {proj.title}
                        </h3>
                        <p className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
                          {proj.trackIds.length} titres · {formatCompactNumber(proj.totalStreams)} écoutes
                        </p>
                      </div>
                    </div>

                    <div className="space-y-1.5 border-t border-slate-900/10 dark:border-white/10 pt-2.5">
                      {projTracks.slice(0, 4).map((t, i) => (
                        <button
                          key={t.id}
                          type="button"
                          onClick={() => {
                            soundEngine.playGlassTap();
                            setInspectedSongId(t.id);
                          }}
                          className="w-full flex items-center justify-between text-xs py-1 px-2 rounded-xl hover:bg-slate-900/5 dark:hover:bg-white/5"
                        >
                          <span className="font-semibold text-slate-800 dark:text-slate-100 truncate">
                            {i + 1}. {t.title}
                          </span>
                          <span className="font-mono tabular-nums text-slate-500 dark:text-slate-400 shrink-0">
                            {formatCompactNumber(t.totalStreams)}
                          </span>
                        </button>
                      ))}
                      {projTracks.length > 4 && (
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 px-2">
                          +{projTracks.length - 4} autres morceaux
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {/* SEGMENT 3: DELUXE */}
      {segment === 'deluxe' && (
        <>
          {filteredDeluxes.length === 0 ? (
            <div className="min-h-[42vh] flex flex-col items-center justify-center text-center space-y-4 py-12">
              <p className="text-lg sm:text-xl font-bold text-slate-500 dark:text-slate-400">
                Aucun Deluxe
              </p>
              <button
                type="button"
                onClick={() => openCreatorForSegment('deluxe')}
                className="liquid-interactive min-h-[46px] rounded-full liquid-glass px-6 py-2.5 text-sm font-extrabold text-slate-900 dark:text-white active:scale-95 transition"
              >
                Créer une Édition Deluxe
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {filteredDeluxes.map((proj) => (
                <div
                  key={proj.id}
                  className="liquid-glass rounded-3xl p-4 flex items-center gap-4"
                >
                  <img
                    src={COVER_ART_URL}
                    alt={proj.title}
                    referrerPolicy="no-referrer"
                    className="h-16 w-16 rounded-2xl object-cover shrink-0 shadow ring-2 ring-amber-400/50"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-bold text-amber-600 dark:text-amber-300 flex items-center gap-1">
                      <Sparkles className="h-3.5 w-3.5" />
                      <span>Édition Deluxe · Sem. {proj.releaseWeek}</span>
                    </div>
                    <h3 className="text-base font-extrabold text-slate-900 dark:text-white truncate">
                      {proj.title}
                    </h3>
                    <p className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400 mt-0.5">
                      {proj.trackIds.length} titres bonus · {formatCompactNumber(proj.totalStreams)} écoutes
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {/* CREATION & RELEASE MODAL ('+' BUTTON) */}
      <AnimatePresence>
        {showCreateModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/60 backdrop-blur-md p-2.5 sm:p-6"
            role="dialog"
            aria-modal="true"
          >
            <motion.div
              initial={{ opacity: 0, y: 36, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 24, scale: 0.96 }}
              className="w-full max-w-xl liquid-glass rounded-3xl p-5 sm:p-6 max-h-[90vh] overflow-y-auto space-y-5"
            >
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white">
                  Studio & Sorties
                </h2>
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  aria-label="Fermer"
                  className="min-h-[42px] min-w-[42px] rounded-full flex items-center justify-center text-slate-500 hover:bg-slate-900/10 dark:hover:bg-white/10"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Action Selector Tabs */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                {[
                  { id: 'studio' as const, label: 'Enregistrer' },
                  { id: 'publish_single' as const, label: `Single (${vaultSongs.length})` },
                  { id: 'publish_project' as const, label: 'EP / Album' },
                  { id: 'publish_deluxe' as const, label: 'Deluxe' },
                ].map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => {
                      soundEngine.playGlassTap();
                      setCreateMode(m.id);
                    }}
                    className={`min-h-[40px] rounded-xl px-2 text-xs font-bold transition ${
                      createMode === m.id
                        ? 'bg-violet-600 text-white shadow'
                        : 'liquid-glass-subtle text-slate-700 dark:text-slate-200'
                    }`}
                  >
                    {m.label}
                  </button>
                ))}
              </div>

              {/* Mode 1: Record Song in Studio */}
              {createMode === 'studio' && (
                <form onSubmit={handleRecord} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1.5">
                      Titre du morceau
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        maxLength={36}
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        className="flex-1 min-h-[46px] rounded-2xl liquid-glass-subtle px-4 text-sm font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-violet-500"
                      />
                      <button
                        type="button"
                        onClick={handleRandomTitle}
                        aria-label="Suggérer un titre"
                        className="min-h-[46px] min-w-[46px] rounded-2xl liquid-glass-subtle flex items-center justify-center text-slate-700 dark:text-slate-200"
                      >
                        <Dices className="h-5 w-5" />
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                        Genre
                      </label>
                      <select
                        value={songGenre}
                        onChange={(e) => setSongGenre(e.target.value as GenreId)}
                        className="w-full min-h-[42px] rounded-xl liquid-glass-subtle px-3 text-xs font-semibold text-slate-900 dark:text-white bg-transparent"
                      >
                        {GENRES.map((g) => (
                          <option key={g.id} value={g.id} className="bg-slate-900 text-white">
                            {g.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                        Ambiance
                      </label>
                      <select
                        value={mood}
                        onChange={(e) => setMood(e.target.value)}
                        className="w-full min-h-[42px] rounded-xl liquid-glass-subtle px-3 text-xs font-semibold text-slate-900 dark:text-white bg-transparent"
                      >
                        {SONG_MOODS.map((m) => (
                          <option key={m} value={m} className="bg-slate-900 text-white">
                            {m}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                        Thème
                      </label>
                      <select
                        value={theme}
                        onChange={(e) => setTheme(e.target.value)}
                        className="w-full min-h-[42px] rounded-xl liquid-glass-subtle px-3 text-xs font-semibold text-slate-900 dark:text-white bg-transparent"
                      >
                        {SONG_THEMES.map((t) => (
                          <option key={t} value={t} className="bg-slate-900 text-white">
                            {t}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                        Voix
                      </label>
                      <select
                        value={vocalStyle}
                        onChange={(e) => setVocalStyle(e.target.value)}
                        className="w-full min-h-[42px] rounded-xl liquid-glass-subtle px-3 text-xs font-semibold text-slate-900 dark:text-white bg-transparent"
                      >
                        {VOCAL_STYLES.map((v) => (
                          <option key={v} value={v} className="bg-slate-900 text-white">
                            {v}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <span className="block text-xs font-bold text-slate-700 dark:text-slate-200 mb-2">
                      Studio d’enregistrement
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {STUDIO_TIERS.map((tier) => {
                        const locked = artist.fans < tier.minFans;
                        const active = studioId === tier.id;
                        return (
                          <button
                            key={tier.id}
                            type="button"
                            disabled={locked}
                            onClick={() => setStudioId(tier.id)}
                            className={`rounded-2xl p-3 text-left transition ${
                              active
                                ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950'
                                : locked
                                  ? 'opacity-40 liquid-glass-subtle'
                                  : 'liquid-glass-subtle text-slate-900 dark:text-white'
                            }`}
                          >
                            <div className="flex items-center justify-between text-xs font-bold">
                              <span>{tier.name}</span>
                              <span className="font-mono">
                                {tier.cost === 0 ? 'Gratuit' : formatCurrency(tier.cost)}
                              </span>
                            </div>
                            <div className="mt-0.5 text-[11px] opacity-80">
                              {locked
                                ? `${formatCompactNumber(tier.minFans)} fans requis`
                                : `+${tier.qualityBonus} Qualité · ${tier.energyCost} Én.`}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <span className="block text-xs font-bold text-slate-700 dark:text-slate-200 mb-2">
                      Featuring (optionnel)
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      <button
                        type="button"
                        onClick={() => setFeaturingName(null)}
                        className={`min-h-[36px] rounded-xl px-3 text-xs font-bold ${
                          featuringName === null
                            ? 'bg-violet-600 text-white'
                            : 'liquid-glass-subtle text-slate-700 dark:text-slate-200'
                        }`}
                      >
                        Solo (0 €)
                      </button>
                      {FEATURING_ARTISTS.map((feat) => {
                        const locked = artist.fans < feat.minFans;
                        const active = featuringName === feat.name;
                        return (
                          <button
                            key={feat.name}
                            type="button"
                            disabled={locked}
                            onClick={() => setFeaturingName(feat.name)}
                            className={`min-h-[36px] rounded-xl px-3 text-xs font-bold ${
                              active
                                ? 'bg-violet-600 text-white'
                                : locked
                                  ? 'opacity-40 liquid-glass-subtle'
                                  : 'liquid-glass-subtle text-slate-700 dark:text-slate-200'
                            }`}
                          >
                            {feat.name} ({formatCurrency(feat.cost)})
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={
                      artist.cash < totalRecordCost ||
                      artist.energy < selectedStudio.energyCost
                    }
                    className="liquid-interactive w-full min-h-[48px] rounded-2xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 disabled:opacity-40"
                  >
                    <Disc3 className="h-4 w-4" />
                    <span>
                      Enregistrer ({formatCurrency(totalRecordCost)} · {selectedStudio.energyCost} Én.)
                    </span>
                  </button>
                </form>
              )}

              {/* Mode 2: Publish Single */}
              {createMode === 'publish_single' && (
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                        <Megaphone className="h-4 w-4 text-violet-500" />
                        Campagne promo de lancement
                      </span>
                      <span className="text-xs font-mono font-bold text-slate-900 dark:text-white">
                        {formatCurrency(promoTotalCost)}
                      </span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {PROMO_CAMPAIGNS.map((p) => {
                        const selected = selectedPromos.includes(p.id);
                        return (
                          <button
                            key={p.id}
                            type="button"
                            onClick={() => togglePromo(p.id)}
                            className={`rounded-2xl p-3 text-left transition ${
                              selected
                                ? 'bg-violet-600 text-white'
                                : 'liquid-glass-subtle text-slate-800 dark:text-slate-100'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-2 text-xs font-bold">
                              <span className="truncate">{p.name}</span>
                              <span className="font-mono shrink-0">{formatCurrency(p.cost)}</span>
                            </div>
                            <div className="mt-0.5 text-[11px] opacity-80">
                              ×{p.streamMultiplier} écoutes · +{p.hypeGain} Pop.
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {vaultSongs.length === 0 ? (
                    <div className="liquid-glass-subtle rounded-2xl p-5 text-center space-y-2">
                      <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">
                        Aucun morceau dans ton coffre studio
                      </p>
                      <button
                        type="button"
                        onClick={() => setCreateMode('studio')}
                        className="min-h-[40px] rounded-xl bg-violet-600 text-white px-4 text-xs font-bold"
                      >
                        Enregistrer d’abord un titre
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                      {vaultSongs.map((s) => (
                        <div
                          key={s.id}
                          className="liquid-glass-subtle rounded-2xl p-3 flex items-center justify-between gap-3"
                        >
                          <div className="min-w-0">
                            <div className="text-sm font-bold text-slate-900 dark:text-white truncate">
                              {s.title}
                            </div>
                            <div className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                              {getGenreLabel(s.genre)} · Qualité {s.quality}/100
                            </div>
                          </div>
                          <button
                            type="button"
                            disabled={artist.cash < promoTotalCost}
                            onClick={() => handlePublishSingle(s.id)}
                            className="min-h-[40px] rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 px-3.5 text-xs font-extrabold disabled:opacity-40 shrink-0"
                          >
                            Publier
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Mode 3 & 4: Publish EP / Mixtape / Album or Deluxe */}
              {(createMode === 'publish_project' || createMode === 'publish_deluxe') && (
                <div className="space-y-4">
                  {createMode === 'publish_project' ? (
                    <div className="grid grid-cols-3 gap-1.5">
                      {(['ep', 'mixtape', 'album'] as const).map((fmt) => (
                        <button
                          key={fmt}
                          type="button"
                          onClick={() => setProjectFormat(fmt)}
                          className={`min-h-[40px] rounded-xl text-xs font-bold ${
                            projectFormat === fmt
                              ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950'
                              : 'liquid-glass-subtle text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          {getProjectFormatLabel(fmt)}
                        </button>
                      ))}
                    </div>
                  ) : (
                    <div>
                      <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1.5">
                        Album parent à étendre en Deluxe
                      </label>
                      {releasedAlbums.length === 0 ? (
                        <p className="text-xs text-rose-500 font-semibold">
                          Publie d’abord un Album ou EP avant de sortir une Édition Deluxe.
                        </p>
                      ) : (
                        <select
                          value={parentAlbumId || releasedAlbums[0]?.id}
                          onChange={(e) => setParentAlbumId(e.target.value)}
                          className="w-full min-h-[44px] rounded-2xl liquid-glass-subtle px-3 text-sm font-semibold text-slate-900 dark:text-white bg-transparent"
                        >
                          {releasedAlbums.map((alb) => (
                            <option key={alb.id} value={alb.id} className="bg-slate-900 text-white">
                              {alb.title} ({getProjectFormatLabel(alb.format)})
                            </option>
                          ))}
                        </select>
                      )}
                    </div>
                  )}

                  <p className="text-xs text-slate-600 dark:text-slate-300">
                    <Layers className="inline h-3.5 w-3.5 mr-1 text-violet-500" />
                    {activeFormatRule.description}
                  </p>

                  {createMode === 'publish_project' && (
                    <input
                      type="text"
                      maxLength={32}
                      value={projectTitle}
                      onChange={(e) => setProjectTitle(e.target.value)}
                      placeholder="Titre du projet"
                      className="w-full min-h-[44px] rounded-2xl liquid-glass-subtle px-4 text-sm font-semibold text-slate-900 dark:text-white"
                    />
                  )}

                  {vaultSongs.length === 0 ? (
                    <div className="liquid-glass-subtle rounded-2xl p-4 text-center space-y-2">
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Enregistre des morceaux inédits pour assembler ce projet.
                      </p>
                      <button
                        type="button"
                        onClick={() => setCreateMode('studio')}
                        className="min-h-[38px] rounded-xl bg-violet-600 text-white px-4 text-xs font-bold"
                      >
                        Aller en Studio
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                      {vaultSongs.map((s) => {
                        const checked = selectedProjectTracks.includes(s.id);
                        return (
                          <button
                            key={s.id}
                            type="button"
                            onClick={() =>
                              setSelectedProjectTracks((prev) =>
                                prev.includes(s.id)
                                  ? prev.filter((id) => id !== s.id)
                                  : [...prev, s.id]
                              )
                            }
                            className={`w-full rounded-2xl p-3 flex items-center justify-between text-left text-xs font-bold transition ${
                              checked
                                ? 'bg-violet-600 text-white'
                                : 'liquid-glass-subtle text-slate-800 dark:text-slate-100'
                            }`}
                          >
                            <span className="truncate">{s.title}</span>
                            <span className="flex items-center gap-2 shrink-0 font-mono">
                              Q.{s.quality}
                              {checked && <Check className="h-4 w-4" />}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  )}

                  <button
                    type="button"
                    disabled={
                      selectedProjectTracks.length < activeFormatRule.minTracks ||
                      selectedProjectTracks.length > activeFormatRule.maxTracks ||
                      (createMode === 'publish_deluxe' && releasedAlbums.length === 0)
                    }
                    onClick={handlePublishProject}
                    className="liquid-interactive w-full min-h-[48px] rounded-2xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 font-extrabold text-sm disabled:opacity-40"
                  >
                    Publier ({selectedProjectTracks.length}/{activeFormatRule.minTracks}-{activeFormatRule.maxTracks} titres)
                  </button>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* INDIVIDUAL SONG ANALYTICS + CLIPS + RE-PROMOTION MODAL */}
      <AnimatePresence>
        {inspectedSong && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/60 backdrop-blur-md p-3 sm:p-6"
            role="dialog"
            aria-modal="true"
          >
            <motion.div
              initial={{ opacity: 0, y: 36, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 30, scale: 0.96 }}
              className="w-full max-w-xl liquid-glass rounded-3xl p-5 sm:p-7 max-h-[90vh] overflow-y-auto space-y-5"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-3.5 min-w-0">
                  <img
                    src={COVER_ART_URL}
                    alt={inspectedSong.title}
                    referrerPolicy="no-referrer"
                    className="h-14 w-14 rounded-2xl object-cover shrink-0 shadow"
                  />
                  <div className="min-w-0">
                    <div className="text-xs text-violet-600 dark:text-violet-300 font-bold">
                      {getGenreLabel(inspectedSong.genre)} · {inspectedSong.mood} ·{' '}
                      {getLifecycleLabel(inspectedSong.lifecyclePhase)}
                    </div>
                    <h3 className="text-xl font-extrabold text-slate-900 dark:text-white truncate">
                      {inspectedSong.title}
                    </h3>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setInspectedSongId(null)}
                  aria-label="Fermer"
                  className="min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-900/10 dark:hover:bg-white/10"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 liquid-glass-subtle rounded-2xl p-4 font-mono tabular-nums">
                <div>
                  <div className="text-[11px] font-sans text-slate-500 dark:text-slate-400">
                    Streams totaux
                  </div>
                  <div className="text-base font-bold text-slate-900 dark:text-white">
                    {formatCompactNumber(inspectedSong.totalStreams)}
                  </div>
                </div>
                <div>
                  <div className="text-[11px] font-sans text-slate-500 dark:text-slate-400">
                    Meilleure sem.
                  </div>
                  <div className="text-base font-bold text-slate-900 dark:text-white">
                    {formatCompactNumber(inspectedSong.bestWeekStreams)}
                  </div>
                </div>
                <div>
                  <div className="text-[11px] font-sans text-slate-500 dark:text-slate-400">
                    Revenus
                  </div>
                  <div className="text-base font-bold text-emerald-600 dark:text-emerald-300">
                    {formatCurrency(inspectedSong.revenueEarned)}
                  </div>
                </div>
                <div>
                  <div className="text-[11px] font-sans text-slate-500 dark:text-slate-400">
                    Certification
                  </div>
                  <div className="text-sm font-sans font-bold text-amber-600 dark:text-amber-300">
                    {getCertificationLabel(inspectedSong.certification)}
                  </div>
                </div>
              </div>

              {inspectedSong.streamHistory.length > 0 && (
                <div className="liquid-glass-subtle rounded-2xl p-4">
                  <div className="text-xs font-semibold text-slate-600 dark:text-slate-300 mb-3">
                    Courbe hebdomadaire des écoutes
                  </div>
                  <div className="flex items-end gap-1.5 h-20">
                    {inspectedSong.streamHistory.map((val, idx) => {
                      const maxVal = Math.max(...inspectedSong.streamHistory, 1);
                      const pct = Math.max(10, Math.round((val / maxVal) * 100));
                      return (
                        <div
                          key={idx}
                          className="flex-1 rounded-t-md bg-violet-600/80 dark:bg-violet-400/80"
                          style={{ height: `${pct}%` }}
                        />
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="space-y-2.5">
                <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
                  <Video className="h-4 w-4 text-rose-500" />
                  <span>
                    {inspectedSong.hasClip
                      ? `Clip AllTub publié : ${inspectedSong.clipStyle}`
                      : 'Tourner un clip officiel pour AllTub'}
                  </span>
                </div>
                {!inspectedSong.hasClip && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {CLIP_OPTIONS.map((clip) => (
                      <button
                        key={clip.id}
                        type="button"
                        disabled={
                          artist.cash < clip.cost || artist.energy < clip.energyCost
                        }
                        onClick={() => {
                          const res = onCreateClip(inspectedSong.id, clip.id);
                          if (res.error) setFeedback(res.error);
                          else soundEngine.playSuccessChord();
                        }}
                        className="liquid-glass-subtle rounded-2xl p-3 text-left disabled:opacity-40 transition"
                      >
                        <div className="flex items-center justify-between gap-2 text-xs font-bold text-slate-900 dark:text-white">
                          <span>{clip.name}</span>
                          <span className="font-mono tabular-nums">
                            {formatCurrency(clip.cost)}
                          </span>
                        </div>
                        <div className="mt-1 text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                          {clip.energyCost} Én. · ×{clip.streamMultiplier} streams
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-2.5">
                <div className="flex items-center justify-between text-sm font-bold text-slate-900 dark:text-white">
                  <span>Relancer une promotion</span>
                  <span className="text-xs font-normal text-slate-500 dark:text-slate-400">
                    {inspectedSong.promoCount} campagne(s) menée(s)
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {PROMO_CAMPAIGNS.map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      disabled={artist.cash < p.cost}
                      onClick={() => {
                        const res = onPromoteSong(inspectedSong.id, p.id);
                        if (res.error) setFeedback(res.error);
                        else soundEngine.playSuccessChord();
                      }}
                      className="liquid-glass-subtle rounded-2xl p-3 text-left flex items-center justify-between gap-2 disabled:opacity-40"
                    >
                      <span className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                        {p.name}
                      </span>
                      <span className="text-xs font-mono tabular-nums text-violet-600 dark:text-violet-300 shrink-0">
                        {formatCurrency(p.cost)}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
