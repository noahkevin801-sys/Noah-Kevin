import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, CheckCheck, Trash2, Bell } from 'lucide-react';
import { AppSubId, NotificationItem, TabId } from '../types/game';
import { soundEngine } from '../utils/audio';

interface NotificationsDrawerProps {
  open: boolean;
  notifications: NotificationItem[];
  onClose: () => void;
  onSelectNotification: (notif: NotificationItem) => void;
  onMarkAllRead: () => void;
  onClearRead: () => void;
}

export const NotificationsDrawer: React.FC<NotificationsDrawerProps> = ({
  open,
  notifications,
  onClose,
  onSelectNotification,
  onMarkAllRead,
  onClearRead,
}) => {
  const [filter, setFilter] = useState<'all' | NotificationItem['category']>('all');

  const filtered =
    filter === 'all'
      ? notifications
      : notifications.filter((n) => n.category === filter);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex justify-end bg-slate-950/50 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-label="Centre de notifications"
        >
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', stiffness: 360, damping: 34 }}
            className="w-full max-w-md h-full liquid-glass rounded-l-3xl p-5 sm:p-6 flex flex-col"
          >
            <div className="flex items-center justify-between gap-3 pb-4 border-b border-slate-900/10 dark:border-white/10">
              <div className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-sky-600 dark:text-sky-400" />
                <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                  Notifications
                </h2>
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label="Fermer"
                className="min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-900/5 dark:hover:bg-white/10"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Category filter tabs */}
            <div className="mt-3 flex items-center gap-1.5 overflow-x-auto pb-1">
              {[
                { id: 'all' as const, label: 'Toutes' },
                { id: 'music' as const, label: 'Musique' },
                { id: 'live' as const, label: 'Live' },
                { id: 'event' as const, label: 'Événements' },
                { id: 'finance' as const, label: 'Finances' },
              ].map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => {
                    soundEngine.playGlassTap();
                    setFilter(cat.id);
                  }}
                  className={`min-h-[36px] rounded-xl px-3 text-xs font-semibold whitespace-nowrap shrink-0 transition ${
                    filter === cat.id
                      ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950'
                      : 'liquid-glass-subtle text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            {/* Actions */}
            <div className="mt-3 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => {
                  soundEngine.playGlassTap();
                  onMarkAllRead();
                }}
                className="min-h-[38px] text-xs font-semibold text-sky-700 dark:text-sky-300 flex items-center gap-1.5"
              >
                <CheckCheck className="h-4 w-4" />
                <span>Tout marquer comme lu</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  soundEngine.playGlassTap();
                  onClearRead();
                }}
                className="min-h-[38px] text-xs font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1.5"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>Effacer lues</span>
              </button>
            </div>

            {/* List */}
            <div className="mt-3 flex-1 overflow-y-auto space-y-2.5 pr-1">
              {filtered.length === 0 ? (
                <div className="liquid-glass-subtle rounded-2xl p-6 text-center text-sm text-slate-500 dark:text-slate-400">
                  Aucune notification dans cette catégorie.
                </div>
              ) : (
                filtered.map((n) => (
                  <button
                    key={n.id}
                    type="button"
                    onClick={() => {
                      soundEngine.playGlassTap();
                      onSelectNotification(n);
                    }}
                    className={`w-full text-left rounded-2xl p-3.5 transition active:scale-[0.98] ${
                      n.read
                        ? 'liquid-glass-subtle opacity-75'
                        : 'liquid-glass-subtle ring-1 ring-sky-500/40'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 text-[11px] text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                      <span>Semaine {n.week}</span>
                      {!n.read && (
                        <span className="font-sans font-semibold text-sky-700 dark:text-sky-300">
                          Nouveau
                        </span>
                      )}
                    </div>
                    <div className="mt-1 text-sm font-bold text-slate-900 dark:text-white">
                      {n.title}
                    </div>
                    <p className="mt-0.5 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                      {n.message}
                    </p>
                  </button>
                ))
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export type NotificationNavigationHandler = (tab: TabId, app?: AppSubId) => void;
