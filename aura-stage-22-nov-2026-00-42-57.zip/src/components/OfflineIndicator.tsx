import React from 'react';
import { WifiOff } from 'lucide-react';

interface OfflineIndicatorProps {
  isOnline: boolean;
}

export const OfflineIndicator: React.FC<OfflineIndicatorProps> = ({
  isOnline,
}) => {
  if (isOnline) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed top-2 left-1/2 -translate-x-1/2 z-50 pointer-events-none px-3 w-full max-w-md flex justify-center"
    >
      <div className="liquid-glass rounded-full px-3.5 py-1.5 flex items-center gap-2 text-xs font-semibold text-amber-700 dark:text-amber-300 border border-amber-500/30 shadow-lg">
        <WifiOff className="h-3.5 w-3.5 shrink-0" />
        <span>Mode hors-ligne · IA & sauvegarde locale actives</span>
      </div>
    </div>
  );
};
