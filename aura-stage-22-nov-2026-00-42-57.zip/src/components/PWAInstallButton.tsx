import React, { useState } from 'react';
import { Download, Share, Smartphone, X, CheckCircle2 } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { soundEngine } from '../utils/audio';

interface PWAInstallButtonProps {
  variant?: 'card' | 'compact';
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  variant = 'card',
}) => {
  const {
    canPromptNatively,
    isInstalled,
    isIOS,
    isNativeAndroid,
    triggerInstall,
  } = usePWAInstall();
  const [showGuideModal, setShowGuideModal] = useState(false);

  if (isInstalled || isNativeAndroid) {
    if (variant === 'compact') return null;
    return (
      <div className="liquid-glass-subtle rounded-2xl px-4 py-3 flex items-center gap-3 text-xs text-emerald-600 dark:text-emerald-300 font-semibold">
        <CheckCircle2 className="h-4 w-4 shrink-0" />
        <span>
          Application installée en mode autonome mobile
          {isNativeAndroid ? ' (Android APK)' : ' (PWA)'}.
        </span>
      </div>
    );
  }

  const handleClick = async () => {
    soundEngine.playGlassTap();
    if (canPromptNatively) {
      const result = await triggerInstall();
      if (result === 'unavailable') {
        setShowGuideModal(true);
      }
      return;
    }
    setShowGuideModal(true);
  };

  return (
    <>
      {variant === 'compact' ? (
        <button
          type="button"
          onClick={handleClick}
          className="liquid-interactive inline-flex items-center gap-1.5 rounded-full bg-sky-600/90 hover:bg-sky-500 text-white px-3 py-1.5 text-xs font-bold shadow-sm transition"
        >
          <Download className="h-3.5 w-3.5" />
          <span>Installer</span>
        </button>
      ) : (
        <button
          type="button"
          onClick={handleClick}
          className="w-full min-h-[52px] rounded-2xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white px-4 py-3 flex items-center justify-between text-sm font-semibold shadow-lg shadow-sky-900/20 transition"
        >
          <div className="flex items-center gap-3 text-left">
            <span className="h-9 w-9 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
              <Smartphone className="h-4 w-4" />
            </span>
            <div>
              <div className="font-bold leading-tight">
                Installer ALL STARZ sur mobile
              </div>
              <div className="text-[11px] text-sky-100/85 font-normal">
                {canPromptNatively
                  ? 'Installation directe plein écran (Android)'
                  : 'Guide Android / Chrome & iOS Safari'}
              </div>
            </div>
          </div>
          <Download className="h-4 w-4 shrink-0 opacity-90" />
        </button>
      )}

      {showGuideModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md"
          role="dialog"
          aria-modal="true"
          aria-label="Installer ALL STARZ sur téléphone"
        >
          <div className="w-full max-w-md liquid-glass rounded-3xl p-6 space-y-4 text-slate-900 dark:text-white">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="h-10 w-10 rounded-2xl bg-sky-500/20 text-sky-400 flex items-center justify-center">
                  <Smartphone className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold">
                    Installer ALL STARZ
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Expérience plein écran avec sauvegarde hors-ligne
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowGuideModal(false)}
                aria-label="Fermer"
                className="h-8 w-8 rounded-full liquid-glass-subtle flex items-center justify-center"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {isIOS ? (
              <ol className="space-y-2.5 text-sm text-slate-700 dark:text-slate-200">
                <li className="flex items-start gap-2.5">
                  <span className="h-5 w-5 rounded-full bg-sky-500/20 text-sky-400 text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                    1
                  </span>
                  <span>
                    Appuie sur le bouton <strong className="inline-flex items-center gap-1">Partager <Share className="h-3.5 w-3.5 inline" /></strong> dans Safari.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <span className="h-5 w-5 rounded-full bg-sky-500/20 text-sky-400 text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                    2
                  </span>
                  <span>
                    Sélectionne <strong>« Sur l’écran d’accueil »</strong> puis valide.
                  </span>
                </li>
              </ol>
            ) : (
              <ol className="space-y-2.5 text-sm text-slate-700 dark:text-slate-200">
                <li className="flex items-start gap-2.5">
                  <span className="h-5 w-5 rounded-full bg-sky-500/20 text-sky-400 text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                    1
                  </span>
                  <span>
                    Ouvre le menu <strong>⋮</strong> de Google Chrome sur Android.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <span className="h-5 w-5 rounded-full bg-sky-500/20 text-sky-400 text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                    2
                  </span>
                  <span>
                    Appuie sur <strong>« Ajouter à l’écran d’accueil »</strong> ou <strong>« Installer l’application »</strong> (génère un WebAPK natif sur Android).
                  </span>
                </li>
              </ol>
            )}

            <button
              type="button"
              onClick={() => setShowGuideModal(false)}
              className="w-full min-h-[44px] rounded-2xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 text-sm font-bold"
            >
              Compris
            </button>
          </div>
        </div>
      )}
    </>
  );
};
