import React, { useEffect, useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Award, Crown, Disc3, Gem, Medal, Sparkles, Trophy, X } from 'lucide-react';
import { CertificationLevel, GameState } from '../types/game';
import { computeCertification } from '../engine/simulation';
import {
  formatCompactNumber,
  getCertificationLabel,
  getProjectFormatLabel,
} from '../utils/format';
import { soundEngine } from '../utils/audio';

export interface CertificationMilestone {
  key: string; // `${kind}:${id}:${level}`
  id: string;
  kind: 'song' | 'album';
  title: string;
  subtitle: string;
  streams: number;
  level: Exclude<CertificationLevel, 'none'>;
}

const SEEN_CERTS_KEY = 'all_starz_seen_certs_v1';

const TIER_ORDER: Array<{
  level: Exclude<CertificationLevel, 'none'>;
  label: string;
  threshold: number;
  gradient: string;
  ring: string;
  text: string;
  glow: string;
  Icon: React.FC<{ className?: string }>;
}> = [
  {
    level: 'bronze',
    label: 'Bronze',
    threshold: 25_000,
    gradient: 'from-amber-700 via-orange-500 to-amber-900',
    ring: 'ring-amber-500/50',
    text: 'text-amber-300',
    glow: 'shadow-amber-600/30',
    Icon: Medal,
  },
  {
    level: 'silver',
    label: 'Argent',
    threshold: 50_000,
    gradient: 'from-slate-200 via-slate-400 to-slate-600',
    ring: 'ring-slate-300/60',
    text: 'text-slate-200',
    glow: 'shadow-slate-300/30',
    Icon: Award,
  },
  {
    level: 'gold',
    label: 'Or',
    threshold: 100_000,
    gradient: 'from-yellow-300 via-amber-400 to-yellow-600',
    ring: 'ring-yellow-400/70',
    text: 'text-yellow-300',
    glow: 'shadow-yellow-400/35',
    Icon: Trophy,
  },
  {
    level: 'platinum',
    label: 'Platine',
    threshold: 500_000,
    gradient: 'from-cyan-200 via-slate-100 to-indigo-300',
    ring: 'ring-cyan-300/70',
    text: 'text-cyan-200',
    glow: 'shadow-cyan-300/35',
    Icon: Crown,
  },
  {
    level: 'diamond',
    label: 'Diamant',
    threshold: 2_000_000,
    gradient: 'from-sky-300 via-fuchsia-200 to-cyan-300',
    ring: 'ring-sky-300/80',
    text: 'text-sky-200',
    glow: 'shadow-sky-400/45',
    Icon: Gem,
  },
];

function normalizeTier(level: CertificationLevel): Exclude<CertificationLevel, 'none'> | null {
  if (level === 'none') return null;
  if (level === 'multi_platinum') return 'platinum';
  return level;
}

export function extractCertifiedMilestones(gameState: GameState): CertificationMilestone[] {
  const milestones: CertificationMilestone[] = [];

  for (const song of gameState.songs) {
    if (!song.released) continue;
    const cert = computeCertification(song.totalStreams);
    if (cert !== 'none') {
      milestones.push({
        key: `song:${song.id}:${cert}`,
        id: song.id,
        kind: 'song',
        title: song.title,
        subtitle: 'Single / Titre',
        streams: song.totalStreams,
        level: cert,
      });
    }
  }

  for (const proj of gameState.projects) {
    const projStreams = proj.trackIds.reduce((sum, tid) => {
      const track = gameState.songs.find((s) => s.id === tid);
      return sum + (track?.totalStreams ?? 0);
    }, 0);
    const effectiveStreams = Math.max(proj.totalStreams, projStreams);
    const cert = computeCertification(effectiveStreams);
    if (cert !== 'none') {
      milestones.push({
        key: `album:${proj.id}:${cert}`,
        id: proj.id,
        kind: 'album',
        title: proj.title,
        subtitle: getProjectFormatLabel(proj.format),
        streams: effectiveStreams,
        level: cert,
      });
    }
  }

  return milestones.sort((a, b) => b.streams - a.streams);
}

export function loadSeenCertificationKeys(): string[] {
  try {
    const raw = localStorage.getItem(SEEN_CERTS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // ignore
  }
  return [];
}

export function markCertificationKeysSeen(keys: string[]) {
  try {
    const existing = new Set(loadSeenCertificationKeys());
    for (const k of keys) existing.add(k);
    localStorage.setItem(SEEN_CERTS_KEY, JSON.stringify(Array.from(existing).slice(-120)));
  } catch {
    // ignore
  }
}

export function resetSeenCertificationKeys() {
  try {
    localStorage.removeItem(SEEN_CERTS_KEY);
  } catch {
    // ignore
  }
}

function getTierMeta(level: Exclude<CertificationLevel, 'none'>) {
  const normalized = normalizeTier(level) ?? 'bronze';
  return TIER_ORDER.find((t) => t.level === normalized) ?? TIER_ORDER[0];
}

/* ============================================================================
 * 1. PALMARÈS PROFILE SECTION (Bronze, Argent, Or, Platine, Diamant)
 * ============================================================================ */
export const PalmaresBadges: React.FC<{
  gameState: GameState;
  recentUnlockKeys?: string[];
}> = ({ gameState, recentUnlockKeys = [] }) => {
  const milestones = useMemo(() => extractCertifiedMilestones(gameState), [gameState]);
  const [localFreshKeys, setLocalFreshKeys] = useState<string[]>([]);
  const [replayMilestone, setReplayMilestone] = useState<CertificationMilestone | null>(null);

  const newlyUnlockedKeys = useMemo(
    () => Array.from(new Set([...localFreshKeys, ...recentUnlockKeys])),
    [localFreshKeys, recentUnlockKeys]
  );

  // Detect freshly unlocked certification keys if mounted standalone
  useEffect(() => {
    const seen = new Set(loadSeenCertificationKeys());
    const fresh = milestones.filter((m) => !seen.has(m.key)).map((m) => m.key);
    if (fresh.length > 0) {
      setLocalFreshKeys((prev) => Array.from(new Set([...prev, ...fresh])));
      markCertificationKeysSeen(fresh);
    }
  }, [milestones]);

  // Highest stream count across songs & albums to calculate progress toward next threshold
  const maxWorkStreams = useMemo(() => {
    const songMax = gameState.songs
      .filter((s) => s.released)
      .reduce((max, s) => Math.max(max, s.totalStreams), 0);
    const projMax = gameState.projects.reduce((max, p) => {
      const sum = p.trackIds.reduce((acc, tid) => {
        const t = gameState.songs.find((s) => s.id === tid);
        return acc + (t?.totalStreams ?? 0);
      }, 0);
      return Math.max(max, p.totalStreams, sum);
    }, 0);
    return Math.max(songMax, projMax);
  }, [gameState.songs, gameState.projects]);

  const nextTier = TIER_ORDER.find((t) => maxWorkStreams < t.threshold) ?? null;
  const nextPct = nextTier
    ? Math.min(99, Math.round((maxWorkStreams / nextTier.threshold) * 100))
    : 100;

  return (
    <section className="liquid-glass rounded-3xl p-5 sm:p-6 space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <div className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-amber-400" />
            <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
              Palmarès
            </h2>
            {milestones.length > 0 && (
              <span className="rounded-full bg-amber-500/15 text-amber-600 dark:text-amber-300 px-2.5 py-0.5 text-xs font-mono font-extrabold">
                {milestones.length} certif.
              </span>
            )}
          </div>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-0.5">
            Badges de certifications débloqués par les streams de tes chansons et albums.
          </p>
        </div>

        {nextTier && (
          <div className="liquid-glass-subtle rounded-2xl px-3.5 py-2 text-right min-w-[165px]">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Prochain seuil : {nextTier.label}
            </div>
            <div className="text-xs font-mono font-extrabold text-slate-900 dark:text-white">
              {formatCompactNumber(maxWorkStreams)} / {formatCompactNumber(nextTier.threshold)}
            </div>
            <div className="mt-1 h-1.5 w-full rounded-full bg-slate-900/10 dark:bg-white/10 overflow-hidden">
              <div
                className={`h-full rounded-full bg-gradient-to-r ${nextTier.gradient} transition-all duration-500`}
                style={{ width: `${Math.max(4, nextPct)}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* 5 Dynamic Certification Tier Badges (Bronze, Argent, Or, Platine, Diamant) */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
        {TIER_ORDER.map((tier, idx) => {
          const matching = milestones.filter(
            (m) => normalizeTier(m.level) === tier.level
          );
          const unlocked = matching.length > 0;
          const hasFresh = matching.some((m) => newlyUnlockedKeys.includes(m.key));
          const Icon = tier.Icon;

          return (
            <motion.button
              key={tier.level}
              type="button"
              disabled={!unlocked}
              onClick={() => {
                if (matching[0]) {
                  soundEngine.playSuccessChord();
                  setReplayMilestone(matching[0]);
                }
              }}
              initial={hasFresh ? { scale: 0.6, opacity: 0, rotate: -10 } : { opacity: 0, y: 8 }}
              animate={{ scale: 1, opacity: 1, rotate: 0, y: 0 }}
              transition={{
                type: 'spring',
                stiffness: 340,
                damping: 22,
                delay: idx * 0.05,
              }}
              className={`relative overflow-hidden rounded-2xl p-3 text-center flex flex-col items-center justify-center gap-1.5 transition ${
                unlocked
                  ? `liquid-glass-subtle ring-2 ${tier.ring} shadow-lg ${tier.glow} active:scale-95 cursor-pointer`
                  : 'liquid-glass-subtle opacity-45 cursor-default'
              }`}
            >
              {/* Shimmer sweep for newly unlocked tier */}
              {hasFresh && (
                <motion.span
                  aria-hidden="true"
                  initial={{ x: '-120%' }}
                  animate={{ x: '160%' }}
                  transition={{ duration: 1.2, repeat: 2, ease: 'easeInOut' }}
                  className="pointer-events-none absolute inset-y-0 w-10 bg-gradient-to-r from-transparent via-white/45 to-transparent skew-x-[-20deg]"
                />
              )}

              <div
                className={`h-11 w-11 rounded-full bg-gradient-to-br ${tier.gradient} flex items-center justify-center shadow-inner ${
                  unlocked ? 'text-slate-950' : 'text-slate-950/60 grayscale'
                }`}
              >
                <Icon className="h-5 w-5" />
              </div>

              <div className="text-xs font-extrabold text-slate-900 dark:text-white">
                {tier.label}
              </div>
              <div className="text-[10px] font-mono text-slate-500 dark:text-slate-400">
                {unlocked
                  ? `${matching.length} titre${matching.length > 1 ? 's' : ''}`
                  : `${formatCompactNumber(tier.threshold)} éc.`}
              </div>

              {hasFresh && (
                <span className="absolute top-1.5 right-1.5 rounded-full bg-emerald-500 text-slate-950 px-1.5 py-0.5 text-[9px] font-extrabold">
                  NEW
                </span>
              )}
            </motion.button>
          );
        })}
      </div>

      {/* Detailed Plaques List for Certified Songs & Albums */}
      {milestones.length === 0 ? (
        <div className="liquid-glass-subtle rounded-2xl p-4 text-center text-xs text-slate-600 dark:text-slate-300">
          Atteins <strong>25 000 streams</strong> sur un morceau ou un album pour débloquer ton premier disque de Bronze et révéler ton badge !
        </div>
      ) : (
        <div className="space-y-2.5">
          <div className="text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Disques & Plaques certifiées (cliquer pour animer)
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {milestones.map((m, idx) => {
              const meta = getTierMeta(m.level);
              const isFresh = newlyUnlockedKeys.includes(m.key);
              const Icon = meta.Icon;
              return (
                <motion.button
                  key={m.key}
                  type="button"
                  onClick={() => {
                    soundEngine.playSuccessChord();
                    setReplayMilestone(m);
                  }}
                  initial={
                    isFresh
                      ? { opacity: 0, scale: 0.78, y: 12 }
                      : { opacity: 0, y: 6 }
                  }
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  transition={{
                    type: 'spring',
                    stiffness: 320,
                    damping: 22,
                    delay: idx * 0.04,
                  }}
                  className={`relative overflow-hidden liquid-glass-subtle rounded-2xl p-3.5 flex items-center gap-3 text-left ring-1 ${meta.ring} hover:brightness-105 active:scale-[0.98] transition`}
                >
                  <div
                    className={`h-11 w-11 rounded-xl bg-gradient-to-br ${meta.gradient} text-slate-950 flex items-center justify-center shrink-0 shadow`}
                  >
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className="text-sm font-extrabold text-slate-900 dark:text-white truncate">
                        {m.title}
                      </span>
                      {isFresh && (
                        <Sparkles className="h-3.5 w-3.5 text-amber-400 shrink-0 animate-pulse" />
                      )}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                      {m.subtitle} · {getCertificationLabel(m.level)}
                    </div>
                  </div>
                  <div className="text-right shrink-0 font-mono">
                    <div className="text-xs font-extrabold text-slate-900 dark:text-white">
                      {formatCompactNumber(m.streams)}
                    </div>
                    <div className="text-[10px] text-slate-500">streams</div>
                  </div>
                </motion.button>
              );
            })}
          </div>
        </div>
      )}

      {/* Interactive Replay / Reveal Modal */}
      <CertificationRevealOverlay
        milestone={replayMilestone}
        onClose={() => setReplayMilestone(null)}
      />
    </section>
  );
};

/* ============================================================================
 * 2. ANIMATED REVEAL OVERLAY (Triggered on new threshold or plaque click)
 * ============================================================================ */
export const CertificationRevealOverlay: React.FC<{
  milestone: CertificationMilestone | null;
  onClose: () => void;
}> = ({ milestone, onClose }) => {
  if (!milestone) return null;
  const meta = getTierMeta(milestone.level);
  const Icon = meta.Icon;

  return (
    <AnimatePresence>
      <motion.div
        key={milestone.key}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-md p-4"
        role="dialog"
        aria-modal="true"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.65, rotate: -6, y: 24 }}
          animate={{ opacity: 1, scale: 1, rotate: 0, y: 0 }}
          exit={{ opacity: 0, scale: 0.85, y: 16 }}
          transition={{ type: 'spring', stiffness: 280, damping: 20 }}
          onClick={(e) => e.stopPropagation()}
          className={`relative w-full max-w-sm overflow-hidden rounded-[32px] liquid-glass p-6 text-center space-y-4 ring-2 ${meta.ring} shadow-2xl`}
        >
          {/* Shimmer sweep */}
          <motion.div
            aria-hidden="true"
            initial={{ x: '-140%' }}
            animate={{ x: '200%' }}
            transition={{ duration: 1.35, ease: 'easeInOut' }}
            className="pointer-events-none absolute inset-y-0 w-24 bg-gradient-to-r from-transparent via-white/35 to-transparent skew-x-[-20deg]"
          />

          <button
            type="button"
            onClick={onClose}
            aria-label="Fermer"
            className="absolute top-4 right-4 h-9 w-9 rounded-full liquid-glass-subtle flex items-center justify-center text-slate-600 dark:text-slate-300"
          >
            <X className="h-4 w-4" />
          </button>

          <div className="text-[11px] font-extrabold uppercase tracking-widest text-amber-500 flex items-center justify-center gap-1.5">
            <Sparkles className="h-3.5 w-3.5" />
            <span>Nouvelle Certification Débloquée</span>
          </div>

          {/* Animated Metallic Disc & Trophy Burst */}
          <motion.div
            initial={{ scale: 0.4, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: 'spring', stiffness: 220, damping: 16, delay: 0.08 }}
            className="relative mx-auto h-28 w-28 flex items-center justify-center"
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 9, repeat: Infinity, ease: 'linear' }}
              className={`absolute inset-0 rounded-full bg-gradient-to-br ${meta.gradient} opacity-30 blur-md`}
            />
            <div
              className={`relative h-24 w-24 rounded-full bg-gradient-to-br ${meta.gradient} text-slate-950 flex items-center justify-center shadow-xl border-4 border-white/60`}
            >
              <Icon className="h-10 w-10" />
              <Disc3 className="absolute -bottom-1 -right-1 h-7 w-7 text-slate-950/80 bg-white/80 rounded-full p-1" />
            </div>
          </motion.div>

          <div className="space-y-1">
            <div className="text-2xl font-extrabold text-slate-900 dark:text-white">
              Disque {getCertificationLabel(milestone.level)}
            </div>
            <div className="text-base font-bold text-violet-600 dark:text-violet-300">
              « {milestone.title} »
            </div>
            <div className="text-xs font-mono text-slate-500 dark:text-slate-400">
              {milestone.subtitle} · {formatCompactNumber(milestone.streams)} streams cumulés
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className={`w-full min-h-[46px] rounded-2xl bg-gradient-to-r ${meta.gradient} text-slate-950 font-extrabold text-sm shadow-lg active:scale-95 transition`}
          >
            Célébrer
          </button>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};
