import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  AlertTriangle,
  Newspaper,
  Users,
  Briefcase,
  Activity,
  ChevronRight,
} from 'lucide-react';
import { EventCategory, EventChoice, GameState, RandomEvent } from '../types/game';
import { canAffordEventChoice } from '../engine/events';
import { soundEngine } from '../utils/audio';

interface RandomEventModalProps {
  event: RandomEvent | null;
  gameState: GameState;
  onSelectChoice: (choice: EventChoice) => void;
}

function getCategoryMeta(category: EventCategory) {
  switch (category) {
    case 'collaboration':
      return { label: 'Opportunité Studio', Icon: Users };
    case 'tour':
      return { label: 'Tournée & Logistique', Icon: AlertTriangle };
    case 'press':
      return { label: 'Presse & Critique', Icon: Newspaper };
    case 'industry':
      return { label: 'Industrie & Contrats', Icon: Briefcase };
    case 'health':
      return { label: 'Santé & Voix', Icon: Activity };
    case 'viral':
    default:
      return { label: 'Réseaux & Viralité', Icon: Sparkles };
  }
}

export const RandomEventModal: React.FC<RandomEventModalProps> = ({
  event,
  gameState,
  onSelectChoice,
}) => {
  if (!event) return null;

  const { label: categoryLabel, Icon } = getCategoryMeta(event.category);
  const sentimentLabel =
    event.sentiment === 'positive'
      ? 'Opportunité'
      : event.sentiment === 'negative'
        ? 'Incident'
        : 'Décision stratégique';

  return (
    <AnimatePresence>
      <motion.div
        key={event.id}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/45 backdrop-blur-md p-3 sm:p-6"
        role="dialog"
        aria-modal="true"
        aria-labelledby="random-event-title"
      >
        <motion.div
          initial={{ opacity: 0, y: 40, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 30, scale: 0.96 }}
          transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          className="w-full max-w-lg liquid-glass rounded-3xl p-5 sm:p-7 max-h-[88vh] overflow-y-auto"
        >
          <div className="flex items-center justify-between gap-3 text-xs font-medium text-slate-600 dark:text-slate-300">
            <div className="flex items-center gap-2">
              <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-sky-500/15 text-sky-700 dark:text-sky-300">
                <Icon className="h-4 w-4" />
              </span>
              <span>{categoryLabel}</span>
              <span aria-hidden="true">·</span>
              <span>Semaine {event.week}</span>
            </div>
            <span
              className={`font-semibold ${
                event.sentiment === 'positive'
                  ? 'text-emerald-700 dark:text-emerald-300'
                  : event.sentiment === 'negative'
                    ? 'text-rose-700 dark:text-rose-300'
                    : 'text-amber-700 dark:text-amber-300'
              }`}
            >
              {sentimentLabel}
            </span>
          </div>

          <h2
            id="random-event-title"
            className="mt-4 text-xl sm:text-2xl font-bold tracking-tight text-slate-900 dark:text-white text-balance"
          >
            {event.title}
          </h2>

          <p className="mt-2.5 text-sm sm:text-base leading-relaxed text-slate-700 dark:text-slate-200">
            {event.description}
          </p>

          <div className="mt-6 space-y-2.5">
            {event.choices.map((choice) => {
              const affordable = canAffordEventChoice(gameState, choice);
              return (
                <button
                  key={choice.id}
                  type="button"
                  disabled={!affordable}
                  onClick={() => {
                    soundEngine.playGlassTap();
                    onSelectChoice(choice);
                  }}
                  className={`liquid-interactive w-full min-h-[56px] rounded-2xl p-4 text-left transition-all duration-150 flex items-center justify-between gap-3 ${
                    affordable
                      ? 'liquid-glass-subtle hover:bg-white/85 dark:hover:bg-slate-800/85 active:scale-[0.98] cursor-pointer'
                      : 'opacity-45 cursor-not-allowed bg-slate-200/50 dark:bg-slate-900/40'
                  }`}
                >
                  <div className="min-w-0 flex-1">
                    <div className="text-sm sm:text-base font-semibold text-slate-900 dark:text-white">
                      {choice.label}
                    </div>
                    <div className="mt-0.5 text-xs text-slate-600 dark:text-slate-300 font-mono tabular-nums">
                      {affordable
                        ? choice.summary
                        : `${choice.summary} (Ressources insuffisantes)`}
                    </div>
                  </div>
                  <ChevronRight className="h-5 w-5 shrink-0 text-slate-400 dark:text-slate-500" />
                </button>
              );
            })}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};
