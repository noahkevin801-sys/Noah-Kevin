import React, { useState } from 'react';
import {
  Sun,
  Moon,
  Volume2,
  VolumeX,
  Download,
  Upload,
  RotateCcw,
  Check,
  Wifi,
  WifiOff,
} from 'lucide-react';
import { ARTIST_AVATARS, GENRES } from '../data/gameData';
import { GameState, GenreId } from '../types/game';
import { soundEngine } from '../utils/audio';
import { PalmaresBadges } from './PalmaresBadges';
import { PWAInstallButton } from './PWAInstallButton';

interface SettingsViewProps {
  gameState: GameState;
  recentCertKeys?: string[];
  isDark: boolean;
  isMuted: boolean;
  forceOfflineAi: boolean;
  wsConnected: boolean;
  onlineCount: number;
  onToggleTheme: () => void;
  onToggleMute: () => void;
  onToggleOfflineAi: () => void;
  onUpdateProfile: (updates: {
    stageName?: string;
    bio?: string;
    avatarUrl?: string;
    genre?: GenreId;
  }) => void;
  onImportSave: (jsonStr: string) => boolean;
  onRequestReset: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  gameState,
  recentCertKeys = [],
  isDark,
  isMuted,
  forceOfflineAi,
  wsConnected,
  onlineCount,
  onToggleTheme,
  onToggleMute,
  onToggleOfflineAi,
  onUpdateProfile,
  onImportSave,
  onRequestReset,
}) => {
  const { artist } = gameState;
  const [stageName, setStageName] = useState(artist.stageName);
  const [bio, setBio] = useState(artist.bio);
  const [genre, setGenre] = useState<GenreId>(artist.genre);
  const [avatarUrl, setAvatarUrl] = useState(artist.avatarUrl);
  const [savedFeedback, setSavedFeedback] = useState<string | null>(null);
  const [importText, setImportText] = useState('');

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    soundEngine.playSuccessChord();
    onUpdateProfile({ stageName, bio, avatarUrl, genre });
    setSavedFeedback('Profil mis à jour et sauvegardé.');
  };

  const handleExportSave = () => {
    const data = JSON.stringify(gameState);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `allstarz_${artist.stageName.toLowerCase().replace(/\s+/g, '_')}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setSavedFeedback('Sauvegarde exportée.');
  };

  const handleImport = () => {
    if (!importText.trim()) return;
    const ok = onImportSave(importText.trim());
    setSavedFeedback(ok ? 'Sauvegarde restaurée.' : 'Format de sauvegarde invalide.');
    if (ok) setImportText('');
  };

  return (
    <div className="space-y-6">
      {/* Palmarès & Certifications Dynamiques */}
      <PalmaresBadges gameState={gameState} recentUnlockKeys={recentCertKeys} />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Artist Profile Customization */}
      <form
        onSubmit={handleSaveProfile}
        className="lg:col-span-7 liquid-glass rounded-3xl p-5 sm:p-6 space-y-5"
      >
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">
            Profil & Personnalisation
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-300 mt-0.5">
            Fais évoluer ton identité publique à tout moment de ta carrière.
          </p>
        </div>

        <div className="grid grid-cols-3 gap-3 max-w-sm">
          {ARTIST_AVATARS.map((av) => {
            const active = avatarUrl === av.url;
            return (
              <button
                key={av.id}
                type="button"
                onClick={() => setAvatarUrl(av.url)}
                className={`relative aspect-square rounded-2xl overflow-hidden ${
                  active ? 'ring-2 ring-sky-500' : 'opacity-75 hover:opacity-100'
                }`}
              >
                <img
                  src={av.url}
                  alt={av.label}
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-cover"
                />
                {active && (
                  <span className="absolute top-1.5 right-1.5 h-5 w-5 rounded-full bg-sky-600 text-white flex items-center justify-center">
                    <Check className="h-3 w-3" />
                  </span>
                )}
              </button>
            );
          })}
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
            Nom de scène
          </label>
          <input
            type="text"
            maxLength={28}
            value={stageName}
            onChange={(e) => setStageName(e.target.value)}
            className="w-full min-h-[44px] rounded-2xl liquid-glass-subtle px-4 text-sm font-medium text-slate-900 dark:text-white"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
            Biographie officielle
          </label>
          <textarea
            rows={2}
            maxLength={140}
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            className="w-full rounded-2xl liquid-glass-subtle p-3.5 text-sm text-slate-900 dark:text-white resize-none"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
            Genre principal
          </label>
          <select
            value={genre}
            onChange={(e) => setGenre(e.target.value as GenreId)}
            className="w-full min-h-[44px] rounded-2xl liquid-glass-subtle px-3 text-sm font-medium text-slate-900 dark:text-white bg-transparent"
          >
            {GENRES.map((g) => (
              <option key={g.id} value={g.id} className="bg-slate-900 text-white">
                {g.name}
              </option>
            ))}
          </select>
        </div>

        {savedFeedback && (
          <p className="text-xs font-semibold text-sky-700 dark:text-sky-300">
            {savedFeedback}
          </p>
        )}

        <button
          type="submit"
          className="liquid-interactive min-h-[48px] rounded-2xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 text-sm font-semibold px-6 py-3"
        >
          Enregistrer les modifications
        </button>
      </form>

      {/* App Preferences & Save Management */}
      <div className="lg:col-span-5 space-y-6">
        <section className="liquid-glass rounded-3xl p-5 sm:p-6 space-y-3">
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">
            Préférences
          </h3>

          <button
            type="button"
            onClick={() => {
              soundEngine.playGlassTap();
              onToggleTheme();
            }}
            className="w-full min-h-[50px] liquid-glass-subtle rounded-2xl px-4 py-3 flex items-center justify-between text-sm font-semibold text-slate-900 dark:text-white"
          >
            <span>Apparence visuelle</span>
            <span className="flex items-center gap-2 text-xs text-sky-700 dark:text-sky-300">
              {isDark ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
              {isDark ? 'Sombre Graphite' : 'Verre Clair'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              onToggleMute();
            }}
            className="w-full min-h-[50px] liquid-glass-subtle rounded-2xl px-4 py-3 flex items-center justify-between text-sm font-semibold text-slate-900 dark:text-white"
          >
            <span>Effets sonores</span>
            <span className="flex items-center gap-2 text-xs text-sky-700 dark:text-sky-300">
              {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
              {isMuted ? 'Désactivé' : 'Activé'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              soundEngine.playGlassTap();
              onToggleOfflineAi();
            }}
            className="w-full min-h-[50px] liquid-glass-subtle rounded-2xl px-4 py-3 flex items-center justify-between text-sm font-semibold text-slate-900 dark:text-white"
          >
            <div className="text-left">
              <div>Réseau & IA</div>
              <div className="text-[11px] font-normal text-slate-500 dark:text-slate-400">
                {forceOfflineAi
                  ? 'Mode IA autonome hors-ligne activé'
                  : wsConnected
                    ? `Connecté au serveur (${Math.max(1, onlineCount)} en ligne)`
                    : 'Reconnexion au serveur en cours...'}
              </div>
            </div>
            <span className="flex items-center gap-1.5 text-xs font-bold shrink-0">
              {forceOfflineAi || !wsConnected ? (
                <>
                  <WifiOff className="h-4 w-4 text-amber-400" />
                  <span className="text-amber-500 dark:text-amber-300">Hors-ligne IA</span>
                </>
              ) : (
                <>
                  <Wifi className="h-4 w-4 text-emerald-400" />
                  <span className="text-emerald-600 dark:text-emerald-300">Live</span>
                </>
              )}
            </span>
          </button>

          <div className="pt-1">
            <PWAInstallButton />
          </div>
        </section>

        <section className="liquid-glass rounded-3xl p-5 sm:p-6 space-y-3">
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">
            Sauvegardes & Données
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Sauvegarde locale automatique active. Tu peux aussi exporter ta carrière ou recommencer.
          </p>

          <button
            type="button"
            onClick={handleExportSave}
            className="w-full min-h-[46px] liquid-glass-subtle rounded-2xl px-4 py-2.5 flex items-center justify-center gap-2 text-sm font-semibold text-slate-900 dark:text-white"
          >
            <Download className="h-4 w-4" />
            <span>Exporter la sauvegarde (.json)</span>
          </button>

          <div className="space-y-2 pt-1">
            <textarea
              rows={2}
              value={importText}
              onChange={(e) => setImportText(e.target.value)}
              placeholder="Coller une sauvegarde JSON ici pour restaurer..."
              className="w-full rounded-2xl liquid-glass-subtle p-3 text-xs font-mono text-slate-900 dark:text-white resize-none"
            />
            <button
              type="button"
              disabled={!importText.trim()}
              onClick={handleImport}
              className="w-full min-h-[42px] rounded-xl bg-sky-600 text-white text-xs font-semibold flex items-center justify-center gap-1.5 disabled:opacity-40"
            >
              <Upload className="h-3.5 w-3.5" />
              <span>Restaurer la sauvegarde</span>
            </button>
          </div>

          <div className="pt-2 border-t border-slate-900/10 dark:border-white/10">
            <button
              type="button"
              onClick={onRequestReset}
              className="w-full min-h-[46px] rounded-2xl bg-rose-600/15 text-rose-700 dark:text-rose-300 text-sm font-semibold flex items-center justify-center gap-2 hover:bg-rose-600/25 transition"
            >
              <RotateCcw className="h-4 w-4" />
              <span>Réinitialiser la carrière</span>
            </button>
          </div>

          <div className="pt-1 text-center text-[11px] text-slate-500 dark:text-slate-400">
            ALL STARZ · Serveur Live & Mode IA Hors-ligne
          </div>
        </section>
      </div>
      </div>
    </div>
  );
};
