import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  BadgeCheck,
  BarChart2,
  Bookmark,
  Disc3,
  Heart,
  MapPin,
  MessageCircle,
  Music,
  Newspaper,
  Play,
  Plus,
  Repeat2,
  Send,
  Share2,
  Sparkles,
  TrendingUp,
  Video,
  X,
} from 'lucide-react';
import { GameState } from '../types/game';
import {
  OnlinePlayerProfile,
  SharedSocialPost,
  SocialPlatform,
} from '../types/network';
import { COVER_TONES, RIVAL_ARTISTS } from '../data/gameData';
import { formatCompactNumber, getGenreLabel } from '../utils/format';
import { soundEngine } from '../utils/audio';

export interface SocialActionCallbacks {
  playerId: string;
  gameState: GameState;
  posts: SharedSocialPost[];
  onlinePlayers: OnlinePlayerProfile[];
  isOfflineMode: boolean;
  onCreatePost: (params: {
    platform: SocialPlatform;
    content: string;
    title?: string;
    location?: string;
    tag?: string;
    mediaTone?: string;
    attachedSongTitle?: string;
    videoDuration?: string;
  }) => void;
  onToggleLike: (postId: string) => void;
  onToggleRepost: (postId: string) => void;
  onAddComment: (postId: string, text: string) => void;
  onAskAiReact: (postId: string) => void;
}

function formatTimeAgo(ts: number): string {
  const sec = Math.max(1, Math.floor((Date.now() - ts) / 1000));
  if (sec < 60) return "à l'instant";
  const min = Math.floor(sec / 60);
  if (min < 60) return `il y a ${min} min`;
  const h = Math.floor(min / 60);
  if (h < 24) return `il y a ${h} h`;
  return `il y a ${Math.floor(h / 24)} j`;
}

/* ============================================================================
 * 1. ALLGRAM (Instagram Authentic UI)
 * ============================================================================ */
export const AllGramView: React.FC<SocialActionCallbacks> = ({
  playerId,
  gameState,
  posts,
  onlinePlayers,
  onCreatePost,
  onToggleLike,
  onAddComment,
  onAskAiReact,
}) => {
  const { artist, songs } = gameState;
  const releasedSongs = songs.filter((s) => s.released);
  const feed = posts.filter((p) => p.platform === 'allgram');

  const [showComposer, setShowComposer] = useState(false);
  const [caption, setCaption] = useState('');
  const [location, setLocation] = useState('Paris · Studio');
  const [toneIdx, setToneIdx] = useState(0);
  const [attachedSong, setAttachedSong] = useState('');
  const [savedIds, setSavedIds] = useState<string[]>([]);
  const [openCommentsId, setOpenCommentsId] = useState<string | null>(null);
  const [commentText, setCommentText] = useState('');
  const [storyViewer, setStoryViewer] = useState<{
    name: string;
    handle: string;
    avatar: string;
    text: string;
  } | null>(null);

  const stories = [
    {
      id: 'story_me',
      name: 'Votre story',
      handle: `@${artist.stageName.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
      avatar: artist.avatarUrl,
      text: `${artist.stageName} · ${formatCompactNumber(artist.fans)} abonnés sur AllGram`,
      isSelf: true,
    },
    ...onlinePlayers
      .filter((p) => p.playerId !== playerId)
      .slice(0, 5)
      .map((p) => ({
        id: p.playerId,
        name: p.stageName,
        handle: p.handle,
        avatar: p.avatarUrl,
        text: p.topSongTitle
          ? `En écoute : « ${p.topSongTitle} » (${formatCompactNumber(p.fans)} fans)`
          : `${getGenreLabel(p.genre)} · En ligne sur AllGram`,
        isSelf: false,
      })),
    ...RIVAL_ARTISTS.slice(0, 4).map((r) => ({
      id: `story_${r.name}`,
      name: r.name,
      handle: r.handle,
      avatar: '/src/assets/images/artist_portrait_urban_1795252245054.jpg',
      text: `Session studio pour « ${r.titles[0]} » — Bientôt disponible !`,
      isSelf: false,
    })),
  ];

  const handlePublish = (e: React.FormEvent) => {
    e.preventDefault();
    if (!caption.trim()) return;
    soundEngine.playSuccessChord();
    onCreatePost({
      platform: 'allgram',
      content: caption.trim(),
      location: location.trim() || undefined,
      mediaTone: COVER_TONES[toneIdx % COVER_TONES.length],
      attachedSongTitle: attachedSong || undefined,
      tag: 'AllGram',
    });
    setCaption('');
    setShowComposer(false);
  };

  return (
    <div className="space-y-4">
      {/* Instagram-style Top Bar */}
      <div className="liquid-glass rounded-3xl px-4 py-3 flex items-center justify-between">
        <span className="text-xl font-extrabold tracking-tight bg-gradient-to-r from-amber-400 via-pink-500 to-violet-500 bg-clip-text text-transparent">
          AllGram
        </span>
        <button
          type="button"
          onClick={() => {
            soundEngine.playGlassTap();
            setShowComposer((v) => !v);
          }}
          className="min-h-[40px] rounded-full bg-gradient-to-r from-pink-500 to-violet-600 text-white px-4 text-xs font-extrabold flex items-center gap-1.5 shadow active:scale-95 transition"
        >
          <Plus className="h-4 w-4" />
          <span>Nouveau post</span>
        </button>
      </div>

      {/* Stories Carousel */}
      <div className="liquid-glass rounded-3xl p-3.5 flex items-center gap-3.5 overflow-x-auto">
        {stories.map((st) => (
          <button
            key={st.id}
            type="button"
            onClick={() => {
              soundEngine.playGlassTap();
              if (st.isSelf) {
                setShowComposer(true);
              } else {
                setStoryViewer(st);
              }
            }}
            className="flex flex-col items-center gap-1.5 shrink-0 w-16"
          >
            <div
              className={`p-[2.5px] rounded-full ${
                st.isSelf
                  ? 'bg-slate-400/50'
                  : 'bg-gradient-to-tr from-amber-400 via-pink-500 to-violet-600'
              }`}
            >
              <img
                src={st.avatar}
                alt={st.name}
                referrerPolicy="no-referrer"
                className="h-14 w-14 rounded-full object-cover border-2 border-slate-950"
              />
            </div>
            <span className="text-[11px] font-semibold text-slate-800 dark:text-slate-200 truncate w-full text-center">
              {st.name}
            </span>
          </button>
        ))}
      </div>

      {/* Inline Composer */}
      {showComposer && (
        <form onSubmit={handlePublish} className="liquid-glass rounded-3xl p-4 space-y-3">
          <div className="text-sm font-extrabold text-slate-900 dark:text-white">
            Partager une publication visible par tous les joueurs
          </div>
          <textarea
            rows={2}
            maxLength={240}
            value={caption}
            onChange={(e) => setCaption(e.target.value)}
            placeholder="Légende de ta photo, coulisses de studio, #AllStarz..."
            className="w-full rounded-2xl liquid-glass-subtle p-3 text-sm text-slate-900 dark:text-white resize-none"
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="Lieu (ex: Studio Bastille)"
              className="min-h-[40px] rounded-xl liquid-glass-subtle px-3 text-xs text-slate-900 dark:text-white"
            />
            <select
              value={attachedSong}
              onChange={(e) => setAttachedSong(e.target.value)}
              className="min-h-[40px] rounded-xl liquid-glass-subtle px-3 text-xs text-slate-900 dark:text-white bg-transparent"
            >
              <option value="" className="bg-slate-900">Aucun morceau lié</option>
              {releasedSongs.map((s) => (
                <option key={s.id} value={s.title} className="bg-slate-900">
                  🎵 {s.title}
                </option>
              ))}
            </select>
          </div>
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5">
              {COVER_TONES.map((tone, i) => (
                <button
                  key={tone}
                  type="button"
                  onClick={() => setToneIdx(i)}
                  className={`h-7 w-7 rounded-full bg-gradient-to-br ${tone} ${
                    toneIdx === i ? 'ring-2 ring-white scale-110' : 'opacity-65'
                  }`}
                  aria-label={`Ambiance visuelle ${i + 1}`}
                />
              ))}
            </div>
            <button
              type="submit"
              disabled={!caption.trim()}
              className="min-h-[40px] rounded-full bg-pink-600 text-white px-5 text-xs font-extrabold disabled:opacity-40"
            >
              Publier
            </button>
          </div>
        </form>
      )}

      {/* Instagram Feed Cards */}
      <div className="space-y-5">
        {feed.map((post) => {
          const isLiked = post.likedByIds.includes(playerId);
          const isSaved = savedIds.includes(post.id);
          const commentsOpen = openCommentsId === post.id;

          return (
            <article key={post.id} className="liquid-glass rounded-3xl overflow-hidden">
              {/* Post Header */}
              <div className="px-4 py-3 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5 min-w-0">
                  <img
                    src={post.authorAvatar}
                    alt={post.authorName}
                    referrerPolicy="no-referrer"
                    className="h-9 w-9 rounded-full object-cover shrink-0 ring-2 ring-pink-500/60"
                  />
                  <div className="min-w-0">
                    <div className="flex items-center gap-1">
                      <span className="text-sm font-extrabold text-slate-900 dark:text-white truncate">
                        {post.authorName}
                      </span>
                      {post.verified && (
                        <BadgeCheck className="h-4 w-4 text-sky-500 shrink-0" />
                      )}
                    </div>
                    {post.location && (
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-0.5 truncate">
                        <MapPin className="h-3 w-3 shrink-0" />
                        <span>{post.location}</span>
                      </div>
                    )}
                  </div>
                </div>
                <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400 shrink-0">
                  {formatTimeAgo(post.createdAt)}
                </span>
              </div>

              {/* 1:1 Visual Square Card (Double tap to like!) */}
              <div
                onDoubleClick={() => {
                  if (!isLiked) {
                    soundEngine.playGlassTap();
                    onToggleLike(post.id);
                  }
                }}
                className={`relative aspect-[4/3] sm:aspect-square max-h-[360px] w-full bg-gradient-to-br ${post.mediaTone} flex flex-col justify-between p-5 select-none cursor-pointer`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-white/80">
                    {post.isAi ? 'IA · Artiste' : post.isPlayer ? 'Joueur Réel' : 'Officiel'}
                  </span>
                  {post.attachedSongTitle && (
                    <span className="rounded-full bg-black/45 backdrop-blur-md px-3 py-1 text-[11px] font-bold text-white flex items-center gap-1.5">
                      <Music className="h-3 w-3 text-pink-400" />
                      {post.attachedSongTitle}
                    </span>
                  )}
                </div>

                <div className="my-auto text-center px-3">
                  <Disc3 className="h-14 w-14 text-white/25 mx-auto mb-3" />
                  <p className="text-lg sm:text-xl font-extrabold text-white drop-shadow leading-snug line-clamp-3">
                    « {post.content} »
                  </p>
                </div>

                <div className="text-[11px] font-mono text-white/75 text-right">
                  {post.authorHandle}
                </div>
              </div>

              {/* Action Row (Heart, Comment, Share, Bookmark) */}
              <div className="p-4 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <button
                      type="button"
                      onClick={() => {
                        soundEngine.playGlassTap();
                        onToggleLike(post.id);
                      }}
                      aria-label="J'aime"
                      className={`flex items-center gap-1.5 transition active:scale-110 ${
                        isLiked ? 'text-rose-500' : 'text-slate-800 dark:text-slate-100'
                      }`}
                    >
                      <Heart className={`h-6 w-6 ${isLiked ? 'fill-current' : ''}`} />
                    </button>
                    <button
                      type="button"
                      onClick={() => setOpenCommentsId(commentsOpen ? null : post.id)}
                      aria-label="Commenter"
                      className="text-slate-800 dark:text-slate-100"
                    >
                      <MessageCircle className="h-6 w-6" />
                    </button>
                    <button
                      type="button"
                      onClick={() => onAskAiReact(post.id)}
                      title="Générer une réaction IA"
                      className="text-slate-800 dark:text-slate-100 flex items-center gap-1 text-xs font-bold"
                    >
                      <Sparkles className="h-5 w-5 text-violet-400" />
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() =>
                      setSavedIds((prev) =>
                        prev.includes(post.id) ? prev.filter((x) => x !== post.id) : [...prev, post.id]
                      )
                    }
                    aria-label="Enregistrer"
                    className="text-slate-800 dark:text-slate-100"
                  >
                    <Bookmark className={`h-6 w-6 ${isSaved ? 'fill-current' : ''}`} />
                  </button>
                </div>

                <div className="text-sm font-extrabold font-mono tabular-nums text-slate-900 dark:text-white">
                  {formatCompactNumber(post.likes)} j’aime
                </div>

                <p className="text-sm text-slate-800 dark:text-slate-100">
                  <span className="font-extrabold mr-1.5">{post.authorHandle}</span>
                  {post.content}
                </p>

                {post.comments.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setOpenCommentsId(commentsOpen ? null : post.id)}
                    className="text-xs font-semibold text-slate-500 dark:text-slate-400"
                  >
                    {commentsOpen
                      ? 'Masquer les commentaires'
                      : `Voir les ${post.comments.length} commentaire(s)`}
                  </button>
                )}

                {(commentsOpen || post.comments.length > 0) && (
                  <div className="space-y-1.5 pt-1">
                    {(commentsOpen ? post.comments : post.comments.slice(-2)).map((c) => (
                      <div key={c.id} className="text-xs text-slate-700 dark:text-slate-300">
                        <span className="font-extrabold text-slate-900 dark:text-white mr-1.5">
                          {c.authorName}
                        </span>
                        {c.text}
                      </div>
                    ))}
                  </div>
                )}

                {commentsOpen && (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (!commentText.trim()) return;
                      soundEngine.playGlassTap();
                      onAddComment(post.id, commentText.trim());
                      setCommentText('');
                    }}
                    className="pt-2 flex gap-2"
                  >
                    <input
                      type="text"
                      value={commentText}
                      onChange={(e) => setCommentText(e.target.value)}
                      placeholder="Ajouter un commentaire..."
                      className="flex-1 min-h-[38px] rounded-full liquid-glass-subtle px-3.5 text-xs text-slate-900 dark:text-white"
                    />
                    <button
                      type="submit"
                      disabled={!commentText.trim()}
                      className="text-xs font-extrabold text-sky-600 dark:text-sky-400 px-2 disabled:opacity-40"
                    >
                      Publier
                    </button>
                  </form>
                )}
              </div>
            </article>
          );
        })}
      </div>

      {/* Story Viewer Modal */}
      <AnimatePresence>
        {storyViewer && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4"
            onClick={() => setStoryViewer(null)}
          >
            <div
              className="w-full max-w-sm aspect-[9/15] rounded-3xl bg-gradient-to-br from-violet-900 via-slate-900 to-black p-5 flex flex-col justify-between border border-white/15"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <img
                    src={storyViewer.avatar}
                    alt={storyViewer.name}
                    className="h-9 w-9 rounded-full object-cover"
                  />
                  <div>
                    <div className="text-sm font-bold text-white">{storyViewer.name}</div>
                    <div className="text-[11px] text-white/70">{storyViewer.handle}</div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setStoryViewer(null)}
                  className="text-white p-1"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              <p className="text-center text-lg font-extrabold text-white px-4">
                {storyViewer.text}
              </p>
              <div className="h-1 rounded-full bg-white/30 overflow-hidden">
                <div className="h-full w-full bg-white" />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

/* ============================================================================
 * 2. ALLTOK (TikTok Authentic Short-Video Vertical UI)
 * ============================================================================ */
export const AllTokView: React.FC<SocialActionCallbacks> = ({
  playerId,
  gameState,
  posts,
  onCreatePost,
  onToggleLike,
  onAddComment,
}) => {
  const releasedSongs = gameState.songs.filter((s) => s.released);
  const feed = posts.filter((p) => p.platform === 'alltok');
  const [tokTab, setTokTab] = useState<'foryou' | 'following'>('foryou');
  const [showCreate, setShowCreate] = useState(false);
  const [hookText, setHookText] = useState('');
  const [selectedSong, setSelectedSong] = useState(releasedSongs[0]?.title ?? '');
  const [activeCommentPost, setActiveCommentPost] = useState<string | null>(null);
  const [cmtDraft, setCmtDraft] = useState('');

  const shownFeed =
    tokTab === 'following' ? feed.filter((p) => p.isPlayer) : feed;

  const handlePublishTok = (e: React.FormEvent) => {
    e.preventDefault();
    if (!hookText.trim()) return;
    soundEngine.playSuccessChord();
    onCreatePost({
      platform: 'alltok',
      content: hookText.trim(),
      attachedSongTitle: selectedSong || 'Son original',
      mediaTone: COVER_TONES[Math.floor(Math.random() * COVER_TONES.length)],
      tag: '#AllTokViral',
    });
    setHookText('');
    setShowCreate(false);
  };

  return (
    <div className="space-y-4">
      {/* TikTok Top Bar */}
      <div className="liquid-glass rounded-3xl px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-4 text-sm font-extrabold">
          <button
            type="button"
            onClick={() => setTokTab('following')}
            className={tokTab === 'following' ? 'text-slate-900 dark:text-white underline underline-offset-4' : 'text-slate-500'}
          >
            Mes vidéos
          </button>
          <button
            type="button"
            onClick={() => setTokTab('foryou')}
            className={tokTab === 'foryou' ? 'text-slate-900 dark:text-white underline underline-offset-4' : 'text-slate-500'}
          >
            Pour toi
          </button>
        </div>
        <button
          type="button"
          onClick={() => setShowCreate((v) => !v)}
          className="min-h-[38px] rounded-full bg-gradient-to-r from-cyan-400 to-rose-500 text-slate-950 px-3.5 text-xs font-extrabold flex items-center gap-1"
        >
          <Plus className="h-4 w-4" />
          <span>Créer AllTok</span>
        </button>
      </div>

      {showCreate && (
        <form onSubmit={handlePublishTok} className="liquid-glass rounded-3xl p-4 space-y-3">
          <div className="text-sm font-extrabold text-slate-900 dark:text-white">
            Filmer un AllTok (booste la viralité de ton titre)
          </div>
          <input
            type="text"
            maxLength={140}
            value={hookText}
            onChange={(e) => setHookText(e.target.value)}
            placeholder="Ex: POV tu découvres ce refrain à 2h du mat #PourToi"
            className="w-full min-h-[44px] rounded-2xl liquid-glass-subtle px-4 text-sm text-slate-900 dark:text-white"
          />
          <select
            value={selectedSong}
            onChange={(e) => setSelectedSong(e.target.value)}
            className="w-full min-h-[42px] rounded-2xl liquid-glass-subtle px-3 text-xs text-slate-900 dark:text-white bg-transparent"
          >
            <option value="" className="bg-slate-900">Son original (voix studio)</option>
            {releasedSongs.map((s) => (
              <option key={s.id} value={s.title} className="bg-slate-900">
                🎵 {s.title}
              </option>
            ))}
          </select>
          <button
            type="submit"
            disabled={!hookText.trim()}
            className="w-full min-h-[44px] rounded-2xl bg-rose-500 text-white text-xs font-extrabold disabled:opacity-40"
          >
            Publier sur AllTok
          </button>
        </form>
      )}

      {/* Vertical TikTok Cards */}
      <div className="space-y-4">
        {shownFeed.map((post, idx) => {
          const isLiked = post.likedByIds.includes(playerId);
          return (
            <div
              key={post.id}
              className={`relative rounded-[32px] bg-gradient-to-br ${post.mediaTone} min-h-[420px] p-5 flex flex-col justify-between overflow-hidden shadow-xl border border-white/15`}
            >
              {/* Top Audio Status */}
              <div className="flex items-center justify-between text-xs text-white/80 font-mono">
                <span>AllTok · {formatCompactNumber(post.views)} vues</span>
                <button
                  type="button"
                  onClick={() => soundEngine.playTrackPreview(idx)}
                  className="rounded-full bg-black/40 backdrop-blur px-3 py-1 text-[11px] font-bold text-white flex items-center gap-1"
                >
                  <Play className="h-3 w-3 fill-current" />
                  <span>Écouter extrait</span>
                </button>
              </div>

              {/* Center Visual Hook */}
              <div className="my-auto pr-14">
                <div className="inline-block rounded-2xl bg-black/35 backdrop-blur-md px-4 py-3 text-white font-extrabold text-lg sm:text-xl leading-snug">
                  {post.content}
                </div>
              </div>

              {/* Bottom Left Author + Sound Marquee & Right Vertical Action Column */}
              <div className="flex items-end justify-between gap-3">
                <div className="min-w-0 flex-1 space-y-1.5 text-white">
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm font-extrabold">{post.authorHandle}</span>
                    {post.verified && <BadgeCheck className="h-4 w-4 text-cyan-400" />}
                  </div>
                  <div className="text-xs text-white/80 flex items-center gap-1.5 truncate">
                    <Music className="h-3.5 w-3.5 shrink-0" />
                    <span className="truncate">
                      Son officiel — {post.attachedSongTitle ?? post.authorName}
                    </span>
                  </div>
                </div>

                {/* TikTok Right Vertical Action Stack */}
                <div className="flex flex-col items-center gap-4 text-white shrink-0">
                  <img
                    src={post.authorAvatar}
                    alt={post.authorName}
                    className="h-11 w-11 rounded-full object-cover border-2 border-white shadow"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      soundEngine.playGlassTap();
                      onToggleLike(post.id);
                    }}
                    className="flex flex-col items-center gap-0.5"
                  >
                    <Heart className={`h-7 w-7 ${isLiked ? 'fill-rose-500 text-rose-500' : ''}`} />
                    <span className="text-[11px] font-mono font-bold">
                      {formatCompactNumber(post.likes)}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setActiveCommentPost(activeCommentPost === post.id ? null : post.id)
                    }
                    className="flex flex-col items-center gap-0.5"
                  >
                    <MessageCircle className="h-7 w-7" />
                    <span className="text-[11px] font-mono font-bold">
                      {post.comments.length}
                    </span>
                  </button>
                  <div className="h-10 w-10 rounded-full bg-slate-950 border-4 border-slate-700 flex items-center justify-center animate-spin" style={{ animationDuration: '6s' }}>
                    <Disc3 className="h-5 w-5 text-cyan-300" />
                  </div>
                </div>
              </div>

              {/* Drawer for Comments */}
              {activeCommentPost === post.id && (
                <div className="mt-4 rounded-2xl bg-black/75 backdrop-blur-lg p-3 space-y-2 text-white">
                  <div className="max-h-28 overflow-y-auto space-y-1 text-xs">
                    {post.comments.length === 0 ? (
                      <p className="text-white/60">Sois le premier à commenter ce AllTok.</p>
                    ) : (
                      post.comments.map((c) => (
                        <div key={c.id}>
                          <span className="font-bold text-cyan-300 mr-1.5">{c.authorName}</span>
                          {c.text}
                        </div>
                      ))
                    )}
                  </div>
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (!cmtDraft.trim()) return;
                      onAddComment(post.id, cmtDraft.trim());
                      setCmtDraft('');
                    }}
                    className="flex gap-2"
                  >
                    <input
                      type="text"
                      value={cmtDraft}
                      onChange={(e) => setCmtDraft(e.target.value)}
                      placeholder="Commenter..."
                      className="flex-1 rounded-full bg-white/15 px-3 py-1.5 text-xs text-white"
                    />
                    <button type="submit" className="text-xs font-bold text-rose-400 px-2">
                      Envoyer
                    </button>
                  </form>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

/* ============================================================================
 * 3. ALLX (X / Twitter Microblogging Authentic UI)
 * ============================================================================ */
export const AllXView: React.FC<SocialActionCallbacks> = ({
  playerId,
  gameState,
  posts,
  onCreatePost,
  onToggleLike,
  onToggleRepost,
  onAddComment,
}) => {
  const { artist } = gameState;
  const feed = posts.filter((p) => p.platform === 'allx');
  const [tab, setTab] = useState<'feed' | 'trends'>('feed');
  const [text, setText] = useState('');
  const [replyTargetId, setReplyTargetId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    soundEngine.playSuccessChord();
    onCreatePost({
      platform: 'allx',
      content: text.trim(),
      tag: '#AllStarz',
    });
    setText('');
  };

  return (
    <div className="space-y-4">
      {/* X Header Tabs */}
      <div className="liquid-glass rounded-3xl p-1.5 grid grid-cols-2 gap-1">
        <button
          type="button"
          onClick={() => setTab('feed')}
          className={`min-h-[42px] rounded-2xl text-sm font-extrabold ${
            tab === 'feed' ? 'bg-slate-950 text-white dark:bg-white dark:text-slate-950' : 'text-slate-600 dark:text-slate-300'
          }`}
        >
          Pour vous
        </button>
        <button
          type="button"
          onClick={() => setTab('trends')}
          className={`min-h-[42px] rounded-2xl text-sm font-extrabold ${
            tab === 'trends' ? 'bg-slate-950 text-white dark:bg-white dark:text-slate-950' : 'text-slate-600 dark:text-slate-300'
          }`}
        >
          Tendances Musique
        </button>
      </div>

      {tab === 'trends' ? (
        <div className="liquid-glass rounded-3xl p-5 space-y-3">
          <div className="text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-sky-500" />
            <span>Tendances en direct · Musique</span>
          </div>
          {[
            { rank: 1, tag: '#AllStarzCharts', postsCount: '48,2 k posts' },
            { rank: 2, tag: `#${artist.genre.toUpperCase()}FR`, postsCount: '29,4 k posts' },
            { rank: 3, tag: '#NouveauSingle', postsCount: '19,8 k posts' },
            { rank: 4, tag: artist.stageName.replace(/\s+/g, ''), postsCount: `${formatCompactNumber(artist.fans)} mentions` },
          ].map((tr) => (
            <div key={tr.tag} className="liquid-glass-subtle rounded-2xl p-3.5 flex items-center justify-between">
              <div>
                <div className="text-[11px] text-slate-500">Tendance N°{tr.rank}</div>
                <div className="text-sm font-extrabold text-slate-900 dark:text-white">{tr.tag}</div>
              </div>
              <span className="text-xs font-mono text-slate-500">{tr.postsCount}</span>
            </div>
          ))}
        </div>
      ) : (
        <>
          {/* Composer */}
          <form onSubmit={handleSubmit} className="liquid-glass rounded-3xl p-4 space-y-3">
            <div className="flex gap-3">
              <img
                src={artist.avatarUrl}
                alt={artist.stageName}
                className="h-10 w-10 rounded-full object-cover shrink-0"
              />
              <textarea
                rows={2}
                maxLength={280}
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Quoi de neuf dans l'industrie ?"
                className="flex-1 bg-transparent text-sm text-slate-900 dark:text-white placeholder:text-slate-400 resize-none focus:outline-none"
              />
            </div>
            <div className="flex items-center justify-between border-t border-slate-900/10 dark:border-white/10 pt-2.5">
              <span className="text-xs font-mono text-slate-500">{text.length}/280</span>
              <button
                type="submit"
                disabled={!text.trim()}
                className="min-h-[38px] rounded-full bg-sky-500 text-white px-5 text-xs font-extrabold disabled:opacity-40"
              >
                Poster
              </button>
            </div>
          </form>

          {/* X Timeline */}
          <div className="liquid-glass rounded-3xl divide-y divide-slate-900/10 dark:divide-white/10">
            {feed.map((post) => {
              const isLiked = post.likedByIds.includes(playerId);
              const isReposted = post.repostedByIds.includes(playerId);
              const isReplying = replyTargetId === post.id;

              return (
                <div key={post.id} className="p-4 space-y-2.5">
                  <div className="flex gap-3">
                    <img
                      src={post.authorAvatar}
                      alt={post.authorName}
                      className="h-10 w-10 rounded-full object-cover shrink-0"
                    />
                    <div className="min-w-0 flex-1 space-y-1.5">
                      <div className="flex items-center gap-1.5 flex-wrap text-sm">
                        <span className="font-extrabold text-slate-900 dark:text-white">
                          {post.authorName}
                        </span>
                        {post.verified && <BadgeCheck className="h-4 w-4 text-sky-500 shrink-0" />}
                        <span className="text-xs text-slate-500 dark:text-slate-400">
                          {post.authorHandle} · {formatTimeAgo(post.createdAt)}
                        </span>
                      </div>

                      <p className="text-sm text-slate-800 dark:text-slate-100 leading-relaxed">
                        {post.content}
                      </p>

                      {/* 4-action X bar */}
                      <div className="pt-1 flex items-center justify-between max-w-sm text-xs font-mono text-slate-500 dark:text-slate-400">
                        <button
                          type="button"
                          onClick={() => setReplyTargetId(isReplying ? null : post.id)}
                          className="flex items-center gap-1 hover:text-sky-500"
                        >
                          <MessageCircle className="h-4 w-4" />
                          <span>{post.comments.length}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            soundEngine.playGlassTap();
                            onToggleRepost(post.id);
                          }}
                          className={`flex items-center gap-1 ${isReposted ? 'text-emerald-500 font-bold' : 'hover:text-emerald-500'}`}
                        >
                          <Repeat2 className="h-4 w-4" />
                          <span>{formatCompactNumber(post.reposts)}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            soundEngine.playGlassTap();
                            onToggleLike(post.id);
                          }}
                          className={`flex items-center gap-1 ${isLiked ? 'text-rose-500 font-bold' : 'hover:text-rose-500'}`}
                        >
                          <Heart className={`h-4 w-4 ${isLiked ? 'fill-current' : ''}`} />
                          <span>{formatCompactNumber(post.likes)}</span>
                        </button>
                        <span className="flex items-center gap-1">
                          <BarChart2 className="h-4 w-4" />
                          <span>{formatCompactNumber(post.views)}</span>
                        </span>
                      </div>

                      {/* Replies */}
                      {post.comments.length > 0 && (
                        <div className="pt-2 space-y-1 border-l-2 border-slate-500/20 pl-3">
                          {post.comments.slice(-2).map((c) => (
                            <div key={c.id} className="text-xs text-slate-600 dark:text-slate-300">
                              <span className="font-bold text-slate-900 dark:text-white mr-1">
                                {c.authorHandle}
                              </span>
                              {c.text}
                            </div>
                          ))}
                        </div>
                      )}

                      {isReplying && (
                        <form
                          onSubmit={(e) => {
                            e.preventDefault();
                            if (!replyText.trim()) return;
                            onAddComment(post.id, replyText.trim());
                            setReplyText('');
                          }}
                          className="pt-2 flex gap-2"
                        >
                          <input
                            type="text"
                            value={replyText}
                            onChange={(e) => setReplyText(e.target.value)}
                            placeholder="Poster votre réponse"
                            className="flex-1 rounded-full liquid-glass-subtle px-3 py-1.5 text-xs text-slate-900 dark:text-white"
                          />
                          <button type="submit" className="text-xs font-bold text-sky-500 px-2">
                            Répondre
                          </button>
                        </form>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
};

/* ============================================================================
 * 4. ALLTUB (YouTube Authentic 16:9 Video Platform UI)
 * ============================================================================ */
export const AllTubView: React.FC<
  SocialActionCallbacks & {
    onPublishLocalVlog: (
      title: string,
      videoType: 'Session Studio' | 'Live Performance' | 'Interview'
    ) => { error?: string };
  }
> = ({
  playerId,
  gameState,
  posts,
  onCreatePost,
  onToggleLike,
  onAddComment,
  onPublishLocalVlog,
}) => {
  const { artist } = gameState;
  const videos = posts.filter((p) => p.platform === 'alltub');
  const [vlogTitle, setVlogTitle] = useState('Session Studio Nocturne');
  const [vlogType, setVlogType] = useState<'Session Studio' | 'Live Performance' | 'Interview'>('Session Studio');
  const [selectedVideo, setSelectedVideo] = useState<SharedSocialPost | null>(null);
  const [commentDraft, setCommentDraft] = useState('');
  const [err, setErr] = useState<string | null>(null);

  const handleUpload = (e: React.FormEvent) => {
    e.preventDefault();
    const res = onPublishLocalVlog(vlogTitle, vlogType);
    if (res.error) {
      setErr(res.error);
      return;
    }
    setErr(null);
    soundEngine.playSuccessChord();
    onCreatePost({
      platform: 'alltub',
      title: `${artist.stageName} — ${vlogTitle.trim()} (${vlogType})`,
      content: `Nouvelle vidéo ${vlogType} en ligne sur ma chaîne AllTub.`,
      tag: vlogType,
      videoDuration: '04:12',
      mediaTone: 'from-rose-700/80 via-slate-900 to-black',
    });
  };

  return (
    <div className="space-y-4">
      {/* Uploader */}
      <form onSubmit={handleUpload} className="liquid-glass rounded-3xl p-4 sm:p-5 space-y-3">
        <div className="flex items-center justify-between">
          <div className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <Video className="h-4 w-4 text-rose-500" />
            <span>Mettre une vidéo en ligne (10 Én.)</span>
          </div>
          {err && <span className="text-xs text-rose-500 font-bold">{err}</span>}
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
          <input
            type="text"
            maxLength={50}
            value={vlogTitle}
            onChange={(e) => setVlogTitle(e.target.value)}
            className="sm:col-span-6 min-h-[42px] rounded-2xl liquid-glass-subtle px-3.5 text-sm text-slate-900 dark:text-white"
          />
          <select
            value={vlogType}
            onChange={(e) => setVlogType(e.target.value as typeof vlogType)}
            className="sm:col-span-3 min-h-[42px] rounded-2xl liquid-glass-subtle px-3 text-xs font-bold text-slate-900 dark:text-white bg-transparent"
          >
            <option value="Session Studio" className="bg-slate-900">Session Studio</option>
            <option value="Live Performance" className="bg-slate-900">Live Performance</option>
            <option value="Interview" className="bg-slate-900">Interview</option>
          </select>
          <button
            type="submit"
            disabled={artist.energy < 10}
            className="sm:col-span-3 min-h-[42px] rounded-2xl bg-rose-600 text-white text-xs font-extrabold disabled:opacity-40"
          >
            Publier
          </button>
        </div>
      </form>

      {/* Active Player Card */}
      {selectedVideo && (
        <div className="liquid-glass rounded-3xl overflow-hidden">
          <div className={`aspect-video w-full bg-gradient-to-br ${selectedVideo.mediaTone} p-5 flex flex-col justify-between`}>
            <div className="flex items-center justify-between text-white">
              <span className="rounded-full bg-black/50 px-3 py-1 text-xs font-bold">
                Lecture · {selectedVideo.authorName}
              </span>
              <button
                type="button"
                onClick={() => setSelectedVideo(null)}
                className="rounded-full bg-black/50 p-1.5"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="text-center space-y-2">
              <button
                type="button"
                onClick={() => soundEngine.playTrackPreview(3)}
                className="h-14 w-14 rounded-full bg-rose-600 text-white flex items-center justify-center mx-auto shadow-lg"
              >
                <Play className="h-6 w-6 fill-current ml-0.5" />
              </button>
              <div className="text-sm font-bold text-white">{selectedVideo.title ?? selectedVideo.content}</div>
            </div>
            <div className="h-1 rounded-full bg-white/25 overflow-hidden">
              <div className="h-full w-2/3 bg-rose-500" />
            </div>
          </div>

          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div className="text-xs font-mono text-slate-500 dark:text-slate-400">
                {formatCompactNumber(selectedVideo.views)} vues · {formatTimeAgo(selectedVideo.createdAt)}
              </div>
              <button
                type="button"
                onClick={() => onToggleLike(selectedVideo.id)}
                className="min-h-[34px] rounded-full liquid-glass-subtle px-3.5 text-xs font-bold flex items-center gap-1.5 text-slate-900 dark:text-white"
              >
                <Heart className={`h-4 w-4 ${selectedVideo.likedByIds.includes(playerId) ? 'fill-rose-500 text-rose-500' : ''}`} />
                <span>{formatCompactNumber(selectedVideo.likes)}</span>
              </button>
            </div>

            <div className="space-y-1.5 max-h-32 overflow-y-auto">
              {(posts.find((p) => p.id === selectedVideo.id)?.comments ?? selectedVideo.comments).map((c) => (
                <div key={c.id} className="text-xs text-slate-700 dark:text-slate-300">
                  <span className="font-bold text-slate-900 dark:text-white mr-1.5">{c.authorName}</span>
                  {c.text}
                </div>
              ))}
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!commentDraft.trim()) return;
                onAddComment(selectedVideo.id, commentDraft.trim());
                setCommentDraft('');
              }}
              className="flex gap-2"
            >
              <input
                type="text"
                value={commentDraft}
                onChange={(e) => setCommentDraft(e.target.value)}
                placeholder="Ajouter un commentaire..."
                className="flex-1 min-h-[38px] rounded-full liquid-glass-subtle px-3.5 text-xs text-slate-900 dark:text-white"
              />
              <button type="submit" className="text-xs font-bold text-rose-500 px-3">
                <Send className="h-4 w-4" />
              </button>
            </form>
          </div>
        </div>
      )}

      {/* YouTube Video Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {videos.map((v) => (
          <button
            key={v.id}
            type="button"
            onClick={() => {
              soundEngine.playGlassTap();
              setSelectedVideo(v);
            }}
            className="liquid-glass rounded-3xl overflow-hidden text-left hover:brightness-105 transition"
          >
            <div className={`relative aspect-video w-full bg-gradient-to-br ${v.mediaTone} flex items-center justify-center`}>
              <Play className="h-10 w-10 text-white fill-white/90 drop-shadow" />
              <span className="absolute bottom-2 right-2 rounded bg-black/80 px-1.5 py-0.5 text-[10px] font-mono font-bold text-white">
                {v.videoDuration ?? '03:30'}
              </span>
            </div>
            <div className="p-3.5 flex gap-3">
              <img
                src={v.authorAvatar}
                alt={v.authorName}
                className="h-9 w-9 rounded-full object-cover shrink-0"
              />
              <div className="min-w-0">
                <div className="text-sm font-extrabold text-slate-900 dark:text-white line-clamp-2">
                  {v.title ?? v.content}
                </div>
                <div className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                  {v.authorName} · {formatCompactNumber(v.views)} vues
                </div>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

/* ============================================================================
 * 5. ALLCLOUD (SoundCloud Underground Waveform Demos)
 * ============================================================================ */
export const AllCloudView: React.FC<SocialActionCallbacks> = ({
  playerId,
  gameState,
  posts,
  onCreatePost,
  onToggleLike,
}) => {
  const tracks = posts.filter((p) => p.platform === 'allcloud');
  const [demoTitle, setDemoTitle] = useState('');

  const handleUploadDemo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!demoTitle.trim()) return;
    soundEngine.playSuccessChord();
    onCreatePost({
      platform: 'allcloud',
      title: demoTitle.trim(),
      content: `Freestyle / Maquette inédite de ${gameState.artist.stageName}`,
      tag: 'Demo AllCloud',
      mediaTone: 'from-orange-500/80 via-amber-700/80 to-slate-900',
    });
    setDemoTitle('');
  };

  return (
    <div className="space-y-4">
      <form onSubmit={handleUploadDemo} className="liquid-glass rounded-3xl p-4 flex gap-2">
        <input
          type="text"
          maxLength={44}
          value={demoTitle}
          onChange={(e) => setDemoTitle(e.target.value)}
          placeholder="Partager une maquette ou un freestyle sur AllCloud..."
          className="flex-1 min-h-[44px] rounded-2xl liquid-glass-subtle px-4 text-sm text-slate-900 dark:text-white"
        />
        <button
          type="submit"
          disabled={!demoTitle.trim()}
          className="min-h-[44px] rounded-2xl bg-orange-600 text-white px-4 text-xs font-extrabold disabled:opacity-40"
        >
          Uploader
        </button>
      </form>

      <div className="space-y-3">
        {tracks.map((tr, i) => {
          const isLiked = tr.likedByIds.includes(playerId);
          return (
            <div key={tr.id} className="liquid-glass rounded-3xl p-4 space-y-3">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <button
                    type="button"
                    onClick={() => soundEngine.playTrackPreview(i)}
                    className="h-11 w-11 rounded-full bg-orange-600 text-white flex items-center justify-center shrink-0 active:scale-95 transition"
                  >
                    <Play className="h-5 w-5 fill-current ml-0.5" />
                  </button>
                  <div className="min-w-0">
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      {tr.authorName} · {tr.authorHandle}
                    </div>
                    <div className="text-sm font-extrabold text-slate-900 dark:text-white truncate">
                      {tr.title ?? tr.content}
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => onToggleLike(tr.id)}
                  className={`min-h-[34px] rounded-full liquid-glass-subtle px-3 text-xs font-mono font-bold flex items-center gap-1 ${
                    isLiked ? 'text-orange-500' : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  <Heart className={`h-3.5 w-3.5 ${isLiked ? 'fill-current' : ''}`} />
                  <span>{formatCompactNumber(tr.likes)}</span>
                </button>
              </div>

              {/* Waveform visualizer bars */}
              <div className="flex items-end gap-[3px] h-10 px-1">
                {Array.from({ length: 32 }).map((_, barIdx) => {
                  const h = 25 + ((barIdx * 19 + i * 11) % 75);
                  return (
                    <div
                      key={barIdx}
                      className={`flex-1 rounded-full ${
                        barIdx < 12 ? 'bg-orange-500' : 'bg-slate-400/40 dark:bg-white/20'
                      }`}
                      style={{ height: `${h}%` }}
                    />
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

/* ============================================================================
 * 6. ALLPRESS (Music Media, Critics & Reviews)
 * ============================================================================ */
export const AllPressView: React.FC<{ gameState: GameState }> = ({ gameState }) => {
  const { artist, songs, charts } = gameState;
  const released = songs.filter((s) => s.released);
  const topChart = charts.find((c) => c.isPlayer);

  return (
    <div className="space-y-4">
      <div className="liquid-glass rounded-3xl p-5 flex items-center gap-3">
        <Newspaper className="h-7 w-7 text-amber-400 shrink-0" />
        <div>
          <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
            AllPress · Revue Musicale
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Critiques d’albums, notes éditoriales et tendances de l’industrie
          </p>
        </div>
      </div>

      {topChart && (
        <div className="liquid-glass rounded-3xl p-5 space-y-1.5 border border-amber-400/30">
          <div className="text-xs font-extrabold uppercase tracking-wider text-amber-500">
            À la Une · Charts
          </div>
          <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">
            {artist.stageName} s’installe à la place N°{topChart.rank} avec « {topChart.title} »
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            Avec {formatCompactNumber(topChart.weeklyStreams)} écoutes hebdomadaires, le morceau s’impose comme l’une des sensations {getGenreLabel(artist.genre)} de la semaine.
          </p>
        </div>
      )}

      {released.length === 0 ? (
        <div className="liquid-glass rounded-3xl p-6 text-center text-sm text-slate-500 dark:text-slate-400">
          Publie un premier morceau dans Music pour recevoir tes premières critiques AllPress.
        </div>
      ) : (
        <div className="space-y-3">
          {released.map((s) => {
            const score = Math.min(9.8, Math.max(5.5, Number((s.quality / 10).toFixed(1))));
            return (
              <div key={s.id} className="liquid-glass rounded-3xl p-4 flex items-center justify-between gap-4">
                <div className="min-w-0">
                  <div className="text-xs font-bold text-amber-500">
                    Critique AllPress · {getGenreLabel(s.genre)}
                  </div>
                  <div className="text-base font-extrabold text-slate-900 dark:text-white truncate">
                    « {s.title} » — {artist.stageName}
                  </div>
                  <p className="mt-0.5 text-xs text-slate-600 dark:text-slate-300">
                    {score >= 8
                      ? 'Production chirurgicale et identité forte qui marque la scène actuelle.'
                      : 'Un titre solide qui consolide la progression artistique.'}
                  </p>
                </div>
                <div className="h-14 w-14 rounded-2xl bg-amber-400 text-slate-950 font-mono font-extrabold text-lg flex items-center justify-center shrink-0">
                  {score}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
