import React, { useMemo, useState } from 'react';
import {
  Archive,
  ArrowDown,
  ArrowUp,
  Building2,
  Calendar,
  CalendarClock,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Edit3,
  Globe2,
  GripVertical,
  History,
  Hotel,
  LayoutDashboard,
  Map as MapIcon,
  MapPin,
  Mic,
  Plane,
  Plus,
  Search,
  Sparkles,
  Ticket,
  Trash2,
  TrendingUp,
  Truck,
  Users,
  Wallet,
  X,
} from 'lucide-react';
import { Reorder, useDragControls } from 'motion/react';
import {
  CONCERT_VENUES,
  STAFF_CATALOG,
  STAGE_HERO_URL,
  TOUR_LODGING_OPTIONS,
  TOUR_PRODUCTION_OPTIONS,
  TOUR_TRANSPORT_OPTIONS,
} from '../data/gameData';
import {
  haversineDistanceKm,
  TOUR_CONTINENTS,
} from '../data/tourDestinations';
import {
  estimateTourDateForecast,
  normalizeTour,
} from '../engine/simulation';
import {
  ConcertLog,
  GameState,
  LodgingTier,
  ProductionTier,
  TourContinent,
  TourDateItem,
  TransportTier,
} from '../types/game';
import { soundEngine } from '../utils/audio';
import {
  formatCompactNumber,
  formatCurrency,
  formatGameDate,
  formatShortDate,
} from '../utils/format';
import { TourRouteMap } from './TourRouteMap';

type TourSubTab = 'dashboard' | 'map' | 'calendar' | 'logistics' | 'history';
type CapacityFilter = 'all' | 'small' | 'medium' | 'large' | 'stadium';

export interface TourManagerCallbacks {
  onPerformSoloConcert: (
    venueId: string,
    ticketPrice: number,
    logistics?: {
      transportTier?: TransportTier;
      lodgingTier?: LodgingTier;
      productionTier?: ProductionTier;
    }
  ) => { log: ConcertLog | null; error?: string };
  onCreateCustomTour: (params: {
    name: string;
    defaultTransportTier: TransportTier;
    defaultLodgingTier: LodgingTier;
    defaultProductionTier: ProductionTier;
  }) => { error?: string };
  onUpdateTourSettings: (updates: {
    name?: string;
    status?: 'draft' | 'active';
    defaultTransportTier?: TransportTier;
    defaultLodgingTier?: LodgingTier;
    defaultProductionTier?: ProductionTier;
  }) => void;
  onAddTourDate: (params: {
    venueId: string;
    dayOffset: number;
    ticketPrice: number;
    transportTier?: TransportTier;
    lodgingTier?: LodgingTier;
    productionTier?: ProductionTier;
  }) => { error?: string };
  onUpdateTourDate: (
    dateId: string,
    updates: Partial<{
      venueId: string;
      dayOffset: number;
      ticketPrice: number;
      transportTier: TransportTier;
      lodgingTier: LodgingTier;
      productionTier: ProductionTier;
    }>
  ) => void;
  onMoveTourDate: (dateId: string, direction: 'up' | 'down') => void;
  onReorderTourDates: (orderedUnplayedIds: string[]) => void;
  onPostponeTourDate: (dateId: string, newDayOffset: number) => void;
  onRemoveTourDate: (dateId: string) => void;
  onPlayTourDateById: (dateId?: string) => {
    log: ConcertLog | null;
    tourFinished: boolean;
    error?: string;
  };
  onArchiveTour: () => void;
}

interface DraggableCalendarCardProps {
  item: TourDateItem;
  stepNumber: number;
  isFirstUnplayed: boolean;
  isLastUnplayed: boolean;
  isEditing: boolean;
  isPostponing: boolean;
  postponeTargetDay: number;
  setPostponeTargetDay: (day: number) => void;
  onToggleEdit: () => void;
  onTogglePostpone: () => void;
  onMoveTourDate: (dateId: string, direction: 'up' | 'down') => void;
  onUpdateTourDate: TourManagerCallbacks['onUpdateTourDate'];
  onPostponeTourDate: (dateId: string, newDayOffset: number) => void;
  onRemoveTourDate: (dateId: string) => void;
  onPlayDate: (dateId: string) => void;
  onFeedback: (msg: string | null) => void;
}

const DraggableCalendarCard: React.FC<DraggableCalendarCardProps> = ({
  item,
  stepNumber,
  isFirstUnplayed,
  isLastUnplayed,
  isEditing,
  isPostponing,
  postponeTargetDay,
  setPostponeTargetDay,
  onToggleEdit,
  onTogglePostpone,
  onMoveTourDate,
  onUpdateTourDate,
  onPostponeTourDate,
  onRemoveTourDate,
  onPlayDate,
  onFeedback,
}) => {
  const dragControls = useDragControls();
  const fillPct = Math.min(
    100,
    Math.round((item.ticketsSold / Math.max(1, item.capacity)) * 100)
  );

  return (
    <Reorder.Item
      value={item.id}
      dragListener={false}
      dragControls={dragControls}
      whileDrag={{ scale: 1.02 }}
      className="liquid-glass-subtle rounded-2xl p-3.5 space-y-2.5 select-none"
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-start gap-2 min-w-0">
          <button
            type="button"
            aria-label={`Glisser-déposer ${item.venueName}`}
            onPointerDown={(e) => {
              soundEngine.playGlassTap();
              dragControls.start(e);
            }}
            className="min-h-[44px] min-w-[34px] -ml-1 rounded-xl flex items-center justify-center cursor-grab active:cursor-grabbing touch-none text-slate-400 hover:text-slate-700 dark:hover:text-white shrink-0"
          >
            <GripVertical className="h-4 w-4" />
          </button>

          <div className="min-w-0">
            <div className="flex items-center gap-1.5 text-[11px] font-bold">
              <span className="font-mono text-slate-500">#{stepNumber}</span>
              <span className="text-slate-400">·</span>
              <span
                className={
                  item.status === 'postponed'
                    ? 'text-amber-500'
                    : 'text-sky-600 dark:text-sky-300'
                }
              >
                {item.status === 'postponed' ? 'Reporté' : 'Programmé'}
              </span>
              <span className="text-slate-400">·</span>
              <span className="text-slate-600 dark:text-slate-300">
                {formatShortDate(item.dayOffset)}
              </span>
            </div>
            <div className="text-sm font-extrabold text-slate-900 dark:text-white truncate">
              {item.venueName}
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400">
              {item.city}, {item.country} · Billet {formatCurrency(item.ticketPrice)}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            aria-label="Monter la date"
            disabled={isFirstUnplayed}
            onClick={() => onMoveTourDate(item.id, 'up')}
            className="h-8 w-8 rounded-lg liquid-glass flex items-center justify-center disabled:opacity-30"
          >
            <ArrowUp className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            aria-label="Descendre la date"
            disabled={isLastUnplayed}
            onClick={() => onMoveTourDate(item.id, 'down')}
            className="h-8 w-8 rounded-lg liquid-glass flex items-center justify-center disabled:opacity-30"
          >
            <ArrowDown className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Capacity & Presales Bar */}
      <div className="space-y-1">
        <div className="flex items-center justify-between text-[11px] font-mono tabular-nums text-slate-600 dark:text-slate-300">
          <span>
            Préventes : {formatCompactNumber(item.ticketsSold)} /{' '}
            {formatCompactNumber(item.capacity)}
          </span>
          <span>{fillPct}%</span>
        </div>
        <div className="h-1.5 rounded-full bg-slate-900/10 dark:bg-white/10 overflow-hidden">
          <div
            className="h-full rounded-full bg-violet-500"
            style={{ width: `${fillPct}%` }}
          />
        </div>
      </div>

      {/* Inline Edit Panel (allowed before AND after launch) */}
      {isEditing && (
        <div className="pt-2 border-t border-slate-900/10 dark:border-white/10 space-y-2.5">
          <div className="grid grid-cols-1 gap-2">
            <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300">
              Changer de salle
            </label>
            <select
              value={item.venueId}
              onChange={(e) =>
                onUpdateTourDate(item.id, { venueId: e.target.value })
              }
              className="w-full min-h-[38px] rounded-xl liquid-glass px-2.5 text-xs font-bold text-slate-900 dark:text-white bg-transparent"
            >
              {CONCERT_VENUES.map((v) => (
                <option key={v.id} value={v.id} className="bg-slate-900 text-white">
                  {v.city} ({v.country}) · {v.name} ({formatCompactNumber(v.capacity)} pl.)
                </option>
              ))}
            </select>
          </div>

          <div>
            <div className="flex items-center justify-between text-[11px] font-bold">
              <span>Prix billet</span>
              <span className="font-mono text-violet-500">
                {formatCurrency(item.ticketPrice)}
              </span>
            </div>
            <input
              type="range"
              min={8}
              max={Math.max(60, item.ticketPrice + 60)}
              value={item.ticketPrice}
              onChange={(e) =>
                onUpdateTourDate(item.id, {
                  ticketPrice: Number(e.target.value),
                })
              }
              className="w-full accent-violet-600"
            />
          </div>

          <div className="grid grid-cols-3 gap-1.5">
            <select
              value={item.transportTier}
              onChange={(e) =>
                onUpdateTourDate(item.id, {
                  transportTier: e.target.value as TransportTier,
                })
              }
              className="min-h-[36px] rounded-xl liquid-glass px-2 text-[11px] font-bold bg-transparent"
            >
              {TOUR_TRANSPORT_OPTIONS.map((t) => (
                <option key={t.id} value={t.id} className="bg-slate-900 text-white">
                  {t.name.split(' ')[0]}
                </option>
              ))}
            </select>
            <select
              value={item.lodgingTier}
              onChange={(e) =>
                onUpdateTourDate(item.id, {
                  lodgingTier: e.target.value as LodgingTier,
                })
              }
              className="min-h-[36px] rounded-xl liquid-glass px-2 text-[11px] font-bold bg-transparent"
            >
              {TOUR_LODGING_OPTIONS.map((l) => (
                <option key={l.id} value={l.id} className="bg-slate-900 text-white">
                  {l.name.replace('Hôtel ', '')}
                </option>
              ))}
            </select>
            <select
              value={item.productionTier}
              onChange={(e) =>
                onUpdateTourDate(item.id, {
                  productionTier: e.target.value as ProductionTier,
                })
              }
              className="min-h-[36px] rounded-xl liquid-glass px-2 text-[11px] font-bold bg-transparent"
            >
              {TOUR_PRODUCTION_OPTIONS.map((p) => (
                <option key={p.id} value={p.id} className="bg-slate-900 text-white">
                  {p.name.split(' ')[0]}
                </option>
              ))}
            </select>
          </div>
        </div>
      )}

      {/* Postpone Picker */}
      {isPostponing && (
        <div className="pt-2 border-t border-slate-900/10 dark:border-white/10 space-y-2">
          <div className="text-[11px] font-bold text-amber-500">
            Reporter au : {formatGameDate(postponeTargetDay)}
          </div>
          <div className="flex flex-wrap gap-1.5">
            {[3, 7, 14].map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => setPostponeTargetDay(item.dayOffset + d)}
                className="min-h-[34px] px-2.5 rounded-lg liquid-glass text-[11px] font-bold"
              >
                +{d} jours
              </button>
            ))}
            <button
              type="button"
              onClick={() => {
                onPostponeTourDate(item.id, postponeTargetDay);
                onTogglePostpone();
                onFeedback(`Date reportée au ${formatShortDate(postponeTargetDay)}.`);
              }}
              className="min-h-[34px] px-3 rounded-lg bg-amber-500 text-slate-950 text-[11px] font-extrabold ml-auto"
            >
              Confirmer report
            </button>
          </div>
        </div>
      )}

      {/* Row Actions */}
      <div className="flex flex-wrap items-center gap-1.5 pt-1">
        <button
          type="button"
          onClick={() => onPlayDate(item.id)}
          className="flex-1 min-h-[38px] px-3 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 text-xs font-extrabold flex items-center justify-center gap-1"
        >
          <Mic className="h-3.5 w-3.5" />
          <span>Jouer</span>
        </button>

        <button
          type="button"
          onClick={onToggleEdit}
          className="min-h-[38px] px-2.5 rounded-xl liquid-glass text-xs font-bold flex items-center gap-1"
        >
          <Edit3 className="h-3.5 w-3.5" />
          <span>Éditer</span>
        </button>

        <button
          type="button"
          onClick={onTogglePostpone}
          className="min-h-[38px] px-2.5 rounded-xl liquid-glass text-xs font-bold flex items-center gap-1"
        >
          <CalendarClock className="h-3.5 w-3.5" />
          <span>Reporter</span>
        </button>

        <button
          type="button"
          aria-label="Supprimer cette date"
          onClick={() => {
            onRemoveTourDate(item.id);
            onFeedback('Date retirée de l’itinéraire.');
          }}
          className="min-h-[38px] w-9 rounded-xl liquid-glass text-rose-500 flex items-center justify-center"
        >
          <Trash2 className="h-3.5 w-3.5" />
        </button>
      </div>
    </Reorder.Item>
  );
};

interface TourManagerViewProps extends TourManagerCallbacks {
  gameState: GameState;
  onFeedback: (msg: string | null) => void;
}

export const TourManagerView: React.FC<TourManagerViewProps> = ({
  gameState,
  onFeedback,
  onPerformSoloConcert,
  onCreateCustomTour,
  onUpdateTourSettings,
  onAddTourDate,
  onUpdateTourDate,
  onMoveTourDate,
  onReorderTourDates,
  onPostponeTourDate,
  onRemoveTourDate,
  onPlayTourDateById,
  onArchiveTour,
}) => {
  const { artist, concerts, merch } = gameState;
  const activeTour = useMemo(
    () => normalizeTour(gameState.activeTour, artist.dayOffset),
    [gameState.activeTour, artist.dayOffset]
  );
  const tourHistory = gameState.tourHistory ?? [];

  const [subTab, setSubTab] = useState<TourSubTab>('dashboard');
  const [lastShowReport, setLastShowReport] = useState<ConcertLog | null>(null);

  // New Tour Creator state
  const [newTourName, setNewTourName] = useState('Prisme World Tour');
  const [newTransport, setNewTransport] = useState<TransportTier>('van');
  const [newLodging, setNewLodging] = useState<LodgingTier>('standard');
  const [newProduction, setNewProduction] = useState<ProductionTier>('acoustic');

  // Editable tour title inline when tour exists
  const [editingTourName, setEditingTourName] = useState(false);
  const [tourNameDraft, setTourNameDraft] = useState(activeTour?.name ?? '');

  // Venue & Date Planner filters (Search + Continent -> Country -> City -> Capacity)
  const [venueSearchQuery, setVenueSearchQuery] = useState<string>('');
  const [selectedContinent, setSelectedContinent] = useState<'Tous' | TourContinent>('Tous');
  const [selectedCountry, setSelectedCountry] = useState<string>('Tous');
  const [selectedCity, setSelectedCity] = useState<string>('Toutes');
  const [capacityFilter, setCapacityFilter] = useState<CapacityFilter>('all');

  const countries = useMemo(() => {
    const set = new Set<string>();
    CONCERT_VENUES.filter(
      (v) =>
        selectedContinent === 'Tous' ||
        (v.continent ?? 'Europe') === selectedContinent
    ).forEach((v) => set.add(v.country ?? 'France'));
    return ['Tous', ...Array.from(set)];
  }, [selectedContinent]);

  const citiesForCountry = useMemo(() => {
    const set = new Set<string>();
    CONCERT_VENUES.filter((v) => {
      if (
        selectedContinent !== 'Tous' &&
        (v.continent ?? 'Europe') !== selectedContinent
      ) {
        return false;
      }
      if (selectedCountry !== 'Tous' && (v.country ?? 'France') !== selectedCountry) {
        return false;
      }
      return true;
    }).forEach((v) => set.add(v.city));
    return ['Toutes', ...Array.from(set)];
  }, [selectedContinent, selectedCountry]);

  const filteredVenues = useMemo(() => {
    const q = venueSearchQuery.trim().toLowerCase();
    return CONCERT_VENUES.filter((v) => {
      if (
        selectedContinent !== 'Tous' &&
        (v.continent ?? 'Europe') !== selectedContinent
      ) {
        return false;
      }
      if (selectedCountry !== 'Tous' && (v.country ?? 'France') !== selectedCountry) {
        return false;
      }
      if (selectedCity !== 'Toutes' && v.city !== selectedCity) {
        return false;
      }
      if (q) {
        const hay = `${v.city} ${v.country ?? ''} ${v.continent ?? ''} ${v.name}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      if (capacityFilter === 'small' && v.capacity >= 600) return false;
      if (capacityFilter === 'medium' && (v.capacity < 600 || v.capacity > 5000)) return false;
      if (capacityFilter === 'large' && (v.capacity <= 5000 || v.capacity > 25000)) return false;
      if (capacityFilter === 'stadium' && v.capacity <= 25000) return false;
      return true;
    });
  }, [venueSearchQuery, selectedContinent, selectedCountry, selectedCity, capacityFilter]);

  const [selectedVenueId, setSelectedVenueId] = useState<string>(CONCERT_VENUES[0].id);
  const selectedVenue = useMemo(
    () =>
      CONCERT_VENUES.find((v) => v.id === selectedVenueId) ??
      filteredVenues[0] ??
      CONCERT_VENUES[0],
    [selectedVenueId, filteredVenues]
  );

  const [plannedDayOffset, setPlannedDayOffset] = useState<number>(artist.dayOffset + 3);
  const [plannedTicketPrice, setPlannedTicketPrice] = useState<number>(
    selectedVenue.recommendedPrice
  );
  const [plannedTransport, setPlannedTransport] = useState<TransportTier>(
    activeTour?.defaultTransportTier ?? 'van'
  );
  const [plannedLodging, setPlannedLodging] = useState<LodgingTier>(
    activeTour?.defaultLodgingTier ?? 'standard'
  );
  const [plannedProduction, setPlannedProduction] = useState<ProductionTier>(
    activeTour?.defaultProductionTier ?? 'acoustic'
  );

  // Editing / Postponing an existing date
  const [editingDateId, setEditingDateId] = useState<string | null>(null);
  const [postponingDateId, setPostponingDateId] = useState<string | null>(null);
  const [postponeTargetDay, setPostponeTargetDay] = useState<number>(artist.dayOffset + 7);
  const [expandedHistoryId, setExpandedHistoryId] = useState<string | null>(null);

  const selectedForecast = useMemo(
    () =>
      estimateTourDateForecast(gameState, {
        venueId: selectedVenue.id,
        ticketPrice: plannedTicketPrice,
        dayOffset: plannedDayOffset,
        transportTier: plannedTransport,
        lodgingTier: plannedLodging,
        productionTier: plannedProduction,
      }),
    [
      gameState,
      selectedVenue.id,
      plannedTicketPrice,
      plannedDayOffset,
      plannedTransport,
      plannedLodging,
      plannedProduction,
    ]
  );

  // Aggregate tour projections & realized KPIs
  const tourAggregate = useMemo(() => {
    const dates = activeTour?.dates ?? [];
    let realizedRevenue = 0;
    let realizedCosts = 0;
    let realizedProfit = 0;
    let realizedAttendance = 0;
    let projectedRevenue = 0;
    let projectedCosts = 0;
    let projectedAttendance = 0;
    let totalCapacity = 0;
    let totalPresales = 0;
    const costByCategory = {
      venueCost: 0,
      transportCost: 0,
      lodgingCost: 0,
      crewCost: 0,
      productionCost: 0,
    };
    const visitedCountries = new Set<string>();
    const visitedCities = new Set<string>();
    const visitedContinents = new Set<string>();
    const venueLookup = new Map(CONCERT_VENUES.map((v) => [v.id, v]));
    let totalDistanceKm = 0;
    let prevLat: number | null = null;
    let prevLng: number | null = null;

    dates.forEach((d) => {
      if (d.status === 'cancelled') return;
      totalCapacity += d.capacity;
      visitedCountries.add(d.country);
      visitedCities.add(d.city);
      const venue = venueLookup.get(d.venueId);
      const continent = d.continent ?? venue?.continent;
      if (continent) visitedContinents.add(continent);
      if (venue?.lat !== undefined && venue?.lng !== undefined) {
        if (prevLat !== null && prevLng !== null) {
          totalDistanceKm += haversineDistanceKm(prevLat, prevLng, venue.lat, venue.lng);
        }
        prevLat = venue.lat;
        prevLng = venue.lng;
      }

      if (d.status === 'played' && d.report) {
        realizedRevenue += d.report.grossRevenue;
        realizedCosts += d.report.costs?.totalCost ?? 0;
        realizedProfit += d.report.netProfit;
        realizedAttendance += d.report.attendance;
        totalPresales += d.report.attendance;
        if (d.report.costs) {
          costByCategory.venueCost += d.report.costs.venueCost;
          costByCategory.transportCost += d.report.costs.transportCost;
          costByCategory.lodgingCost += d.report.costs.lodgingCost;
          costByCategory.crewCost += d.report.costs.crewCost;
          costByCategory.productionCost += d.report.costs.productionCost;
        }
      } else {
        totalPresales += d.ticketsSold;
        const f = estimateTourDateForecast(gameState, {
          venueId: d.venueId,
          ticketPrice: d.ticketPrice,
          dayOffset: d.dayOffset,
          transportTier: d.transportTier,
          lodgingTier: d.lodgingTier,
          productionTier: d.productionTier,
        });
        if (f) {
          projectedRevenue += f.grossRevenue;
          projectedCosts += f.costs.totalCost;
          projectedAttendance += f.estimatedAttendance;
          costByCategory.venueCost += f.costs.venueCost;
          costByCategory.transportCost += f.costs.transportCost;
          costByCategory.lodgingCost += f.costs.lodgingCost;
          costByCategory.crewCost += f.costs.crewCost;
          costByCategory.productionCost += f.costs.productionCost;
        }
      }
    });

    const nextPlayable =
      dates.find((d) => d.status === 'scheduled' || d.status === 'postponed') ?? null;

    return {
      dates,
      playedCount: dates.filter((d) => d.status === 'played').length,
      upcomingCount: dates.filter(
        (d) => d.status === 'scheduled' || d.status === 'postponed'
      ).length,
      realizedRevenue,
      realizedCosts,
      realizedProfit,
      realizedAttendance,
      projectedRevenue,
      projectedCosts,
      projectedProfit: projectedRevenue - projectedCosts,
      projectedAttendance,
      totalCapacity,
      totalPresales,
      costByCategory,
      continentsCount: visitedContinents.size,
      countriesCount: visitedCountries.size,
      citiesCount: visitedCities.size,
      totalDistanceKm,
      nextPlayable,
    };
  }, [activeTour, gameState]);

  const activeStaffLive = useMemo(
    () =>
      STAFF_CATALOG.filter(
        (s) =>
          artist.hiredStaffIds.includes(s.id) &&
          (s.id === 'tour_director' || s.id === 'manager')
      ),
    [artist.hiredStaffIds]
  );

  const unlockedMerchCount = merch.filter((m) => m.unlocked).length;

  const handleSelectVenue = (venueId: string) => {
    const v = CONCERT_VENUES.find((x) => x.id === venueId);
    if (!v) return;
    setSelectedVenueId(v.id);
    setPlannedTicketPrice(v.recommendedPrice);
    if (v.region === 'monde') {
      setPlannedTransport('flight');
    }
  };

  const handlePlayDate = (dateId?: string) => {
    const res = onPlayTourDateById(dateId);
    if (res.error) {
      onFeedback(res.error);
      return;
    }
    soundEngine.playSuccessChord();
    if (res.log) {
      setLastShowReport(res.log);
      onFeedback(
        `Concert joué à ${res.log.venueName} (${res.log.city}) : ${res.log.attendance.toLocaleString('fr-FR')} spectateurs · Résultat ${res.log.netProfit >= 0 ? '+' : ''}${formatCurrency(res.log.netProfit)}.`
      );
    }
  };

  return (
    <div className="space-y-5">
      {/* Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl liquid-glass">
        <div className="relative h-44 w-full overflow-hidden">
          <img
            src={STAGE_HERO_URL}
            alt="Scène de concert"
            referrerPolicy="no-referrer"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/50 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 p-5 flex flex-wrap items-end justify-between gap-3">
            <div>
              <p className="text-xs font-semibold text-sky-200">
                {artist.concertsPlayed} concerts joués · {formatShortDate(artist.dayOffset)}
              </p>
              <h2 className="text-2xl font-extrabold text-white">Tour Manager</h2>
              <p className="text-xs text-slate-300 mt-0.5">
                Construis, ajuste et pilote tes tournées ville par ville en toute liberté
              </p>
            </div>
            <div className="flex items-center gap-4 font-mono tabular-nums text-white">
              <div className="text-right">
                <div className="text-[11px] font-sans text-slate-300">Scène</div>
                <div className="text-base font-bold">{artist.skills.stage}/99</div>
              </div>
              <div className="text-right">
                <div className="text-[11px] font-sans text-slate-300">Budget dispo</div>
                <div className="text-base font-bold text-emerald-300">
                  {formatCurrency(artist.cash)}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Sub-navigation Tabs */}
      <div className="liquid-glass rounded-2xl p-1.5 grid grid-cols-2 sm:grid-cols-5 gap-1.5">
        {[
          { id: 'dashboard' as const, label: 'Tableau de bord', Icon: LayoutDashboard },
          {
            id: 'map' as const,
            label: `Carte (${tourAggregate.dates.length})`,
            Icon: MapIcon,
          },
          {
            id: 'calendar' as const,
            label: `Calendrier (${tourAggregate.dates.length})`,
            Icon: Calendar,
          },
          { id: 'logistics' as const, label: 'Logistique & Coûts', Icon: Truck },
          { id: 'history' as const, label: `Historique (${concerts.length})`, Icon: History },
        ].map(({ id, label, Icon }) => {
          const active = subTab === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => {
                soundEngine.playGlassTap();
                setSubTab(id);
              }}
              className={`min-h-[44px] rounded-xl px-3 py-2 text-xs font-extrabold flex items-center justify-center gap-1.5 whitespace-nowrap transition ${
                active
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950 shadow-sm'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Icon className="h-4 w-4 shrink-0" />
              <span className="truncate">{label}</span>
            </button>
          );
        })}
      </div>

      {/* Last Concert Live Report Banner */}
      {lastShowReport && (
        <div className="liquid-glass rounded-3xl p-4 flex flex-wrap items-center justify-between gap-3">
          <div className="space-y-0.5">
            <div className="text-xs font-extrabold text-emerald-600 dark:text-emerald-300">
              Dernier concert · {lastShowReport.venueName} ({lastShowReport.city}
              {lastShowReport.country ? `, ${lastShowReport.country}` : ''})
            </div>
            <div className="text-xs font-mono tabular-nums text-slate-600 dark:text-slate-300">
              {formatCompactNumber(lastShowReport.attendance)}/
              {formatCompactNumber(lastShowReport.capacity)} spect. · Satisfaction{' '}
              {lastShowReport.satisfaction}% · +{formatCompactNumber(lastShowReport.fansGained)}{' '}
              fans · +{lastShowReport.hypeGained} Pop.
            </div>
          </div>
          <div className="text-right font-mono tabular-nums">
            <div
              className={`text-base font-extrabold ${
                lastShowReport.netProfit >= 0
                  ? 'text-emerald-600 dark:text-emerald-300'
                  : 'text-rose-500'
              }`}
            >
              {lastShowReport.netProfit >= 0 ? '+' : ''}
              {formatCurrency(lastShowReport.netProfit)}
            </div>
            <div className="text-[11px] text-slate-500">Bénéfice net</div>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 1: TABLEAU DE BORD                                              */}
      {/* =================================================================== */}
      {subTab === 'dashboard' && (
        <div className="space-y-5">
          {!activeTour ? (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
              <section className="lg:col-span-7 liquid-glass rounded-3xl p-5 space-y-4">
                <div>
                  <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">
                    Créer une tournée sur mesure
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Aucun itinéraire imposé : tu ajoutes autant de dates, de pays et de salles que tu veux, modifiables avant et après le lancement.
                  </p>
                </div>

                <div className="space-y-2">
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-200">
                    Nom de la tournée
                  </label>
                  <input
                    type="text"
                    value={newTourName}
                    onChange={(e) => setNewTourName(e.target.value)}
                    placeholder="Ex. Verre Liquide Tour 2026"
                    className="w-full min-h-[44px] rounded-2xl liquid-glass-subtle px-4 text-sm font-semibold text-slate-900 dark:text-white"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="space-y-1.5">
                    <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300">
                      Transport par défaut
                    </label>
                    <select
                      value={newTransport}
                      onChange={(e) => setNewTransport(e.target.value as TransportTier)}
                      className="w-full min-h-[44px] rounded-2xl liquid-glass-subtle px-3 text-xs font-bold text-slate-900 dark:text-white bg-transparent"
                    >
                      {TOUR_TRANSPORT_OPTIONS.map((t) => (
                        <option key={t.id} value={t.id} className="bg-slate-900 text-white">
                          {t.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300">
                      Hébergement par défaut
                    </label>
                    <select
                      value={newLodging}
                      onChange={(e) => setNewLodging(e.target.value as LodgingTier)}
                      className="w-full min-h-[44px] rounded-2xl liquid-glass-subtle px-3 text-xs font-bold text-slate-900 dark:text-white bg-transparent"
                    >
                      {TOUR_LODGING_OPTIONS.map((l) => (
                        <option key={l.id} value={l.id} className="bg-slate-900 text-white">
                          {l.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300">
                      Production scénique
                    </label>
                    <select
                      value={newProduction}
                      onChange={(e) => setNewProduction(e.target.value as ProductionTier)}
                      className="w-full min-h-[44px] rounded-2xl liquid-glass-subtle px-3 text-xs font-bold text-slate-900 dark:text-white bg-transparent"
                    >
                      {TOUR_PRODUCTION_OPTIONS.map((p) => (
                        <option key={p.id} value={p.id} className="bg-slate-900 text-white">
                          {p.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2.5 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      const res = onCreateCustomTour({
                        name: newTourName,
                        defaultTransportTier: newTransport,
                        defaultLodgingTier: newLodging,
                        defaultProductionTier: newProduction,
                      });
                      if (res.error) {
                        onFeedback(res.error);
                        return;
                      }
                      soundEngine.playSuccessChord();
                      setPlannedTransport(newTransport);
                      setPlannedLodging(newLodging);
                      setPlannedProduction(newProduction);
                      setSubTab('calendar');
                    }}
                    className="flex-1 min-w-[200px] min-h-[48px] rounded-2xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 active:scale-[0.99] transition"
                  >
                    <Plus className="h-4 w-4" />
                    <span>Créer la tournée & choisir les salles</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      soundEngine.playGlassTap();
                      setSubTab('calendar');
                    }}
                    className="min-h-[48px] px-4 rounded-2xl liquid-glass-subtle text-xs font-bold text-slate-800 dark:text-slate-100"
                  >
                    Parcourir les salles
                  </button>
                </div>
              </section>

              <section className="lg:col-span-5 liquid-glass rounded-3xl p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                    Aperçu du circuit mondial
                  </h3>
                  <Globe2 className="h-4 w-4 text-sky-500" />
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {CONCERT_VENUES.length} salles disponibles dans{' '}
                  {new Set(CONCERT_VENUES.map((v) => v.country ?? 'France')).size} pays sur{' '}
                  {TOUR_CONTINENTS.length} continents, de 90 à 72 000 places.
                </p>
                <div className="grid grid-cols-2 gap-2.5 pt-1 font-mono tabular-nums">
                  <div className="liquid-glass-subtle rounded-2xl p-3">
                    <div className="text-[11px] font-sans text-slate-500">Fanbase actuelle</div>
                    <div className="text-base font-extrabold text-slate-900 dark:text-white">
                      {formatCompactNumber(artist.fans)}
                    </div>
                  </div>
                  <div className="liquid-glass-subtle rounded-2xl p-3">
                    <div className="text-[11px] font-sans text-slate-500">Popularité</div>
                    <div className="text-base font-extrabold text-violet-600 dark:text-violet-300">
                      {artist.hype}/100
                    </div>
                  </div>
                  <div className="liquid-glass-subtle rounded-2xl p-3">
                    <div className="text-[11px] font-sans text-slate-500">Équipe live</div>
                    <div className="text-xs font-sans font-bold text-slate-800 dark:text-slate-100 mt-0.5">
                      {activeStaffLive.length > 0
                        ? activeStaffLive.map((s) => s.role).join(' · ')
                        : 'Aucun recrutement live'}
                    </div>
                  </div>
                  <div className="liquid-glass-subtle rounded-2xl p-3">
                    <div className="text-[11px] font-sans text-slate-500">Stand Merch</div>
                    <div className="text-xs font-sans font-bold text-emerald-600 dark:text-emerald-300 mt-0.5">
                      {unlockedMerchCount > 0
                        ? `+${(unlockedMerchCount * 2.5).toFixed(1)} €/spect.`
                        : 'Non débloqué'}
                    </div>
                  </div>
                </div>
              </section>
            </div>
          ) : (
            <div className="space-y-5">
              {/* Active Tour Header + Status Switch + Rename */}
              <div className="liquid-glass rounded-3xl p-5 space-y-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="space-y-1 flex-1 min-w-[220px]">
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-500 dark:text-slate-400">
                      <span
                        className={`font-extrabold ${
                          activeTour.status === 'active'
                            ? 'text-emerald-600 dark:text-emerald-300'
                            : 'text-amber-600 dark:text-amber-300'
                        }`}
                      >
                        {activeTour.status === 'active' ? 'Tournée en cours' : 'Brouillon modifiable'}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>
                        {tourAggregate.continentsCount} cont. · {tourAggregate.countriesCount} pays ·{' '}
                        {tourAggregate.citiesCount} villes
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">
                        {formatCompactNumber(tourAggregate.totalDistanceKm)} km
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>
                        {tourAggregate.playedCount}/{tourAggregate.dates.length} jouées
                      </span>
                    </div>

                    {editingTourName ? (
                      <div className="flex items-center gap-2 pt-1">
                        <input
                          type="text"
                          value={tourNameDraft}
                          onChange={(e) => setTourNameDraft(e.target.value)}
                          className="flex-1 min-h-[42px] rounded-xl liquid-glass-subtle px-3 text-base font-extrabold text-slate-900 dark:text-white"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            onUpdateTourSettings({ name: tourNameDraft });
                            setEditingTourName(false);
                          }}
                          className="min-h-[42px] px-4 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 text-xs font-extrabold"
                        >
                          Valider
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <h3 className="text-xl font-extrabold text-slate-900 dark:text-white">
                          {activeTour.name}
                        </h3>
                        <button
                          type="button"
                          aria-label="Renommer la tournée"
                          onClick={() => {
                            setTourNameDraft(activeTour.name);
                            setEditingTourName(true);
                          }}
                          className="h-8 w-8 rounded-lg liquid-glass-subtle flex items-center justify-center text-slate-600 dark:text-slate-300"
                        >
                          <Edit3 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    {activeTour.status !== 'active' ? (
                      <button
                        type="button"
                        disabled={tourAggregate.upcomingCount === 0}
                        onClick={() => {
                          soundEngine.playSuccessChord();
                          onUpdateTourSettings({ status: 'active' });
                          onFeedback('Tournée lancée ! Tu peux toujours ajouter ou modifier des dates en cours de route.');
                        }}
                        className="min-h-[44px] px-4 rounded-2xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-extrabold disabled:opacity-40"
                      >
                        Lancer la tournée
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          onUpdateTourSettings({ status: 'draft' });
                        }}
                        className="min-h-[44px] px-3.5 rounded-2xl liquid-glass-subtle text-xs font-bold text-slate-700 dark:text-slate-200"
                      >
                        Mettre en pause
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => {
                        soundEngine.playGlassTap();
                        setSubTab('map');
                      }}
                      className="min-h-[44px] px-3.5 rounded-2xl liquid-glass-subtle text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5"
                    >
                      <MapIcon className="h-3.5 w-3.5 text-sky-500" />
                      <span>Carte interactive</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        soundEngine.playGlassTap();
                        setSubTab('calendar');
                      }}
                      className="min-h-[44px] px-3.5 rounded-2xl liquid-glass-subtle text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5"
                    >
                      <Plus className="h-3.5 w-3.5" />
                      <span>Ajouter une date</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        soundEngine.playGlassTap();
                        onArchiveTour();
                        onFeedback(
                          tourAggregate.playedCount > 0
                            ? 'Tournée clôturée et archivée dans le bilan.'
                            : 'Brouillon de tournée fermé.'
                        );
                      }}
                      className="min-h-[44px] px-3.5 rounded-2xl liquid-glass-subtle text-xs font-bold text-rose-600 dark:text-rose-300 flex items-center gap-1.5"
                    >
                      <Archive className="h-3.5 w-3.5" />
                      <span>{tourAggregate.playedCount > 0 ? 'Clôturer' : 'Supprimer'}</span>
                    </button>
                  </div>
                </div>

                {/* Global Tour KPI Grid */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 pt-1 font-mono tabular-nums">
                  <div className="liquid-glass-subtle rounded-2xl p-3.5">
                    <div className="text-[11px] font-sans text-slate-500 dark:text-slate-400">
                      Recettes (Réalisé / Prév.)
                    </div>
                    <div className="text-lg font-extrabold text-emerald-600 dark:text-emerald-300 mt-0.5">
                      {formatCurrency(tourAggregate.realizedRevenue)}
                    </div>
                    <div className="text-[11px] text-slate-500">
                      +{formatCurrency(tourAggregate.projectedRevenue)} à venir
                    </div>
                  </div>

                  <div className="liquid-glass-subtle rounded-2xl p-3.5">
                    <div className="text-[11px] font-sans text-slate-500 dark:text-slate-400">
                      Dépenses (Réalisé / Prév.)
                    </div>
                    <div className="text-lg font-extrabold text-rose-600 dark:text-rose-300 mt-0.5">
                      -{formatCurrency(tourAggregate.realizedCosts)}
                    </div>
                    <div className="text-[11px] text-slate-500">
                      -{formatCurrency(tourAggregate.projectedCosts)} estimées
                    </div>
                  </div>

                  <div className="liquid-glass-subtle rounded-2xl p-3.5">
                    <div className="text-[11px] font-sans text-slate-500 dark:text-slate-400">
                      Bénéfice net tournée
                    </div>
                    <div
                      className={`text-lg font-extrabold mt-0.5 ${
                        tourAggregate.realizedProfit >= 0
                          ? 'text-emerald-600 dark:text-emerald-300'
                          : 'text-rose-600 dark:text-rose-300'
                      }`}
                    >
                      {tourAggregate.realizedProfit >= 0 ? '+' : ''}
                      {formatCurrency(tourAggregate.realizedProfit)}
                    </div>
                    <div className="text-[11px] text-slate-500">
                      Prév. total :{' '}
                      {formatCurrency(
                        tourAggregate.realizedProfit + tourAggregate.projectedProfit
                      )}
                    </div>
                  </div>

                  <div className="liquid-glass-subtle rounded-2xl p-3.5">
                    <div className="text-[11px] font-sans text-slate-500 dark:text-slate-400">
                      Billets / Capacité totale
                    </div>
                    <div className="text-lg font-extrabold text-slate-900 dark:text-white mt-0.5">
                      {formatCompactNumber(tourAggregate.totalPresales)} /{' '}
                      {formatCompactNumber(tourAggregate.totalCapacity)}
                    </div>
                    <div className="text-[11px] text-slate-500">
                      {tourAggregate.totalCapacity > 0
                        ? `${Math.round(
                            (tourAggregate.totalPresales / tourAggregate.totalCapacity) * 100
                          )}% vendus`
                        : 'Aucune capacité'}
                    </div>
                  </div>
                </div>
              </div>

              {/* Next Playable Date Spotlight */}
              {tourAggregate.nextPlayable ? (
                <div className="liquid-glass rounded-3xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="text-xs font-extrabold text-violet-600 dark:text-violet-300">
                      Prochaine date prête · {formatGameDate(tourAggregate.nextPlayable.dayOffset)}
                    </div>
                    <div className="text-lg font-extrabold text-slate-900 dark:text-white">
                      {tourAggregate.nextPlayable.venueName} — {tourAggregate.nextPlayable.city},{' '}
                      {tourAggregate.nextPlayable.country}
                    </div>
                    <div className="text-xs font-mono tabular-nums text-slate-600 dark:text-slate-300">
                      Billet {formatCurrency(tourAggregate.nextPlayable.ticketPrice)} · Préventes{' '}
                      {formatCompactNumber(tourAggregate.nextPlayable.ticketsSold)}/
                      {formatCompactNumber(tourAggregate.nextPlayable.capacity)} pl.
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handlePlayDate(tourAggregate.nextPlayable?.id)}
                    className="min-h-[48px] px-5 rounded-2xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 shrink-0 active:scale-[0.98] transition"
                  >
                    <Mic className="h-4 w-4" />
                    <span>Jouer ce concert</span>
                  </button>
                </div>
              ) : (
                <div className="liquid-glass rounded-3xl p-5 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div className="text-sm font-extrabold text-slate-900 dark:text-white">
                      {tourAggregate.dates.length === 0
                        ? 'Aucune date dans l’itinéraire'
                        : 'Toutes les dates actuelles ont été jouées !'}
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Tu peux ajouter de nouvelles dates pour prolonger la tournée ou la clôturer.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setSubTab('calendar')}
                    className="min-h-[44px] px-4 rounded-2xl bg-violet-600 text-white text-xs font-extrabold flex items-center gap-1.5"
                  >
                    <Plus className="h-4 w-4" />
                    <span>Programmer une date</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Archived Tours */}
          {tourHistory.length > 0 && (
            <section className="liquid-glass rounded-3xl p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                  Tournées archivées
                </h3>
                <span className="text-xs font-mono text-slate-500">
                  {tourHistory.length} archivée{tourHistory.length > 1 ? 's' : ''}
                </span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {tourHistory.map((t) => (
                  <div key={t.id} className="liquid-glass-subtle rounded-2xl p-4 space-y-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-extrabold text-slate-900 dark:text-white truncate">
                        {t.name}
                      </span>
                      <span
                        className={`text-xs font-mono font-bold tabular-nums ${
                          t.totalProfit >= 0
                            ? 'text-emerald-600 dark:text-emerald-300'
                            : 'text-rose-500'
                        }`}
                      >
                        {t.totalProfit >= 0 ? '+' : ''}
                        {formatCurrency(t.totalProfit)}
                      </span>
                    </div>
                    <div className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
                      {t.completedDates} dates · {formatCompactNumber(t.totalAttendance)} spect. · Recettes{' '}
                      {formatCurrency(t.totalRevenue ?? t.totalProfit)}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 2: CARTE INTERACTIVE & GLISSER-DÉPOSER DE L'ITINÉRAIRE         */}
      {/* =================================================================== */}
      {subTab === 'map' && (
        <TourRouteMap
          dates={tourAggregate.dates}
          tourName={activeTour?.name}
          onReorderUnplayed={(orderedUnplayedIds) => {
            onReorderTourDates(orderedUnplayedIds);
          }}
          onPlayDate={(dateId) => handlePlayDate(dateId)}
          onRemoveDate={(dateId) => {
            onRemoveTourDate(dateId);
            onFeedback('Étape retirée de l’itinéraire.');
          }}
          onSelectVenueForAdd={(venueId) => {
            const venue = CONCERT_VENUES.find((v) => v.id === venueId);
            if (!venue) return;
            const nextDay =
              tourAggregate.dates.length > 0
                ? Math.max(
                    artist.dayOffset,
                    ...tourAggregate.dates.map((d) => d.dayOffset)
                  ) + 3
                : artist.dayOffset + 3;
            const res = onAddTourDate({
              venueId: venue.id,
              dayOffset: nextDay,
              ticketPrice: venue.recommendedPrice,
              transportTier:
                venue.region === 'monde'
                  ? 'flight'
                  : activeTour?.defaultTransportTier ?? plannedTransport,
              lodgingTier: activeTour?.defaultLodgingTier ?? plannedLodging,
              productionTier:
                activeTour?.defaultProductionTier ?? plannedProduction,
            });
            if (res.error) {
              onFeedback(res.error);
              return;
            }
            onFeedback(
              `Étape ajoutée depuis la carte : ${venue.name} (${venue.city}) le ${formatShortDate(nextDay)}.`
            );
          }}
        />
      )}

      {/* =================================================================== */}
      {/* TAB 3: CALENDRIER & PROGRAMMATION LIBRE                             */}
      {/* =================================================================== */}
      {subTab === 'calendar' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Left: Free Venue + Calendar + Pricing Builder */}
          <section className="lg:col-span-7 liquid-glass rounded-3xl p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                Choisir un continent, un pays, une ville et une salle
              </h3>
              <span className="text-xs font-mono text-slate-500">
                {filteredVenues.length} salle{filteredVenues.length > 1 ? 's' : ''}
              </span>
            </div>

            {/* Search by city / country / venue */}
            <div className="relative">
              <Search className="h-4 w-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={venueSearchQuery}
                onChange={(e) => setVenueSearchQuery(e.target.value)}
                placeholder="Rechercher une ville, un pays ou une salle..."
                className="w-full min-h-[42px] rounded-2xl liquid-glass-subtle pl-10 pr-9 text-xs font-semibold text-slate-900 dark:text-white placeholder:text-slate-400"
              />
              {venueSearchQuery && (
                <button
                  type="button"
                  aria-label="Effacer la recherche"
                  onClick={() => setVenueSearchQuery('')}
                  className="h-7 w-7 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-700 dark:hover:text-white absolute right-2 top-1/2 -translate-y-1/2"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>

            {/* Continent filter */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5">
              <button
                type="button"
                onClick={() => {
                  setSelectedContinent('Tous');
                  setSelectedCountry('Tous');
                  setSelectedCity('Toutes');
                }}
                className={`min-h-[36px] px-3 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 transition ${
                  selectedContinent === 'Tous'
                    ? 'bg-violet-600 text-white'
                    : 'liquid-glass-subtle text-slate-600 dark:text-slate-300'
                }`}
              >
                Tous continents
              </button>
              {TOUR_CONTINENTS.map((cont) => (
                <button
                  key={cont.id}
                  type="button"
                  onClick={() => {
                    setSelectedContinent(cont.id);
                    setSelectedCountry('Tous');
                    setSelectedCity('Toutes');
                  }}
                  className={`min-h-[36px] px-3 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 transition ${
                    selectedContinent === cont.id
                      ? 'bg-violet-600 text-white'
                      : 'liquid-glass-subtle text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {cont.label}
                </button>
              ))}
            </div>

            {/* Country filter */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              {countries.map((country) => (
                <button
                  key={country}
                  type="button"
                  onClick={() => {
                    setSelectedCountry(country);
                    setSelectedCity('Toutes');
                  }}
                  className={`min-h-[38px] px-3 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 transition ${
                    selectedCountry === country
                      ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950'
                      : 'liquid-glass-subtle text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {country}
                </button>
              ))}
            </div>

            {/* City & Capacity filters */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">Ville</label>
                <select
                  value={selectedCity}
                  onChange={(e) => setSelectedCity(e.target.value)}
                  className="w-full min-h-[42px] rounded-xl liquid-glass-subtle px-3 text-xs font-bold text-slate-900 dark:text-white bg-transparent"
                >
                  {citiesForCountry.map((c) => (
                    <option key={c} value={c} className="bg-slate-900 text-white">
                      {c}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">
                  Capacité de salle
                </label>
                <select
                  value={capacityFilter}
                  onChange={(e) => setCapacityFilter(e.target.value as CapacityFilter)}
                  className="w-full min-h-[42px] rounded-xl liquid-glass-subtle px-3 text-xs font-bold text-slate-900 dark:text-white bg-transparent"
                >
                  <option value="all" className="bg-slate-900 text-white">
                    Toutes les capacités
                  </option>
                  <option value="small" className="bg-slate-900 text-white">
                    Intime / Club (&lt; 600 pl.)
                  </option>
                  <option value="medium" className="bg-slate-900 text-white">
                    Théâtre / Salle (600 - 5 000 pl.)
                  </option>
                  <option value="large" className="bg-slate-900 text-white">
                    Zénith / Arena (5 001 - 25 000 pl.)
                  </option>
                  <option value="stadium" className="bg-slate-900 text-white">
                    Stades (25 000+ pl.)
                  </option>
                </select>
              </div>
            </div>

            {/* Venues List */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-72 overflow-y-auto pr-1">
              {filteredVenues.map((venue) => {
                const active = selectedVenue.id === venue.id;
                const belowRec = artist.fans < venue.minFans;
                return (
                  <button
                    key={venue.id}
                    type="button"
                    onClick={() => handleSelectVenue(venue.id)}
                    className={`text-left rounded-2xl p-3.5 transition ${
                      active
                        ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950'
                        : 'liquid-glass-subtle text-slate-900 dark:text-white'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 text-xs font-extrabold">
                      <span className="truncate">{venue.name}</span>
                      <span className="font-mono tabular-nums shrink-0">
                        {formatCompactNumber(venue.capacity)} pl.
                      </span>
                    </div>
                    <div className="mt-1 flex items-center gap-1 text-[11px] opacity-80 truncate">
                      <MapPin className="h-3 w-3 shrink-0" />
                      <span>
                        {venue.city}, {venue.country ?? 'France'} · {venue.showType}
                      </span>
                    </div>
                    <div className="mt-1.5 flex items-center justify-between text-[11px] font-mono tabular-nums opacity-75">
                      <span>Loc. {formatCurrency(venue.bookingCost)}</span>
                      <span className={belowRec ? 'text-amber-400 font-sans font-bold' : ''}>
                        {belowRec
                          ? `Conseillé : ${formatCompactNumber(venue.minFans)} fans`
                          : `Billet ~${formatCurrency(venue.recommendedPrice)}`}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Date Picker + Ticket Price Slider */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div className="liquid-glass-subtle rounded-2xl p-3.5 space-y-2.5">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-700 dark:text-slate-200">Date du concert</span>
                  <span className="font-mono text-sky-600 dark:text-sky-300">
                    J+{plannedDayOffset - artist.dayOffset}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      setPlannedDayOffset((d) => Math.max(artist.dayOffset, d - 1))
                    }
                    className="h-10 w-10 rounded-xl liquid-glass flex items-center justify-center font-bold text-sm"
                  >
                    -1j
                  </button>
                  <div className="text-center text-xs font-extrabold text-slate-900 dark:text-white">
                    {formatGameDate(plannedDayOffset)}
                  </div>
                  <button
                    type="button"
                    onClick={() => setPlannedDayOffset((d) => d + 1)}
                    className="h-10 w-10 rounded-xl liquid-glass flex items-center justify-center font-bold text-sm"
                  >
                    +1j
                  </button>
                </div>
                <div className="grid grid-cols-4 gap-1">
                  {[0, 3, 7, 14].map((offset) => (
                    <button
                      key={offset}
                      type="button"
                      onClick={() => setPlannedDayOffset(artist.dayOffset + offset)}
                      className={`min-h-[34px] rounded-lg text-[11px] font-bold ${
                        plannedDayOffset === artist.dayOffset + offset
                          ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950'
                          : 'liquid-glass text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      {offset === 0 ? 'Auj.' : `+${offset}j`}
                    </button>
                  ))}
                </div>
              </div>

              <div className="liquid-glass-subtle rounded-2xl p-3.5 space-y-2.5">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-700 dark:text-slate-200">Prix du billet</span>
                  <span className="font-mono tabular-nums text-violet-600 dark:text-violet-300">
                    {formatCurrency(plannedTicketPrice)}
                  </span>
                </div>
                <input
                  type="range"
                  min={8}
                  max={Math.max(50, selectedVenue.recommendedPrice * 2)}
                  value={plannedTicketPrice}
                  onChange={(e) => setPlannedTicketPrice(Number(e.target.value))}
                  className="w-full accent-violet-600"
                />
                <div className="grid grid-cols-3 gap-1">
                  {[
                    { label: '-20%', val: Math.max(8, Math.round(selectedVenue.recommendedPrice * 0.8)) },
                    { label: 'Conseillé', val: selectedVenue.recommendedPrice },
                    { label: '+25%', val: Math.round(selectedVenue.recommendedPrice * 1.25) },
                  ].map((p) => (
                    <button
                      key={p.label}
                      type="button"
                      onClick={() => setPlannedTicketPrice(p.val)}
                      className="min-h-[34px] rounded-lg liquid-glass text-[11px] font-bold text-slate-700 dark:text-slate-200"
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Live Financial & Attendance Forecast */}
            {selectedForecast && (
              <div className="liquid-glass-subtle rounded-2xl p-4 space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <span className="font-bold text-slate-700 dark:text-slate-200">
                    Prévision pour {selectedVenue.name}
                  </span>
                  <span className="text-slate-500 dark:text-slate-400">
                    {selectedForecast.demandFeedback}
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 font-mono tabular-nums text-xs">
                  <div>
                    <div className="font-sans text-[11px] text-slate-500">Affluence est.</div>
                    <div className="font-extrabold text-slate-900 dark:text-white">
                      {formatCompactNumber(selectedForecast.estimatedAttendance)} ({selectedForecast.fillRatePct}%)
                    </div>
                  </div>
                  <div>
                    <div className="font-sans text-[11px] text-slate-500">Recettes est.</div>
                    <div className="font-extrabold text-emerald-600 dark:text-emerald-300">
                      +{formatCurrency(selectedForecast.grossRevenue)}
                    </div>
                  </div>
                  <div>
                    <div className="font-sans text-[11px] text-slate-500">Coûts totaux</div>
                    <div className="font-extrabold text-rose-600 dark:text-rose-300">
                      -{formatCurrency(selectedForecast.costs.totalCost)}
                    </div>
                  </div>
                  <div>
                    <div className="font-sans text-[11px] text-slate-500">Bénéfice est.</div>
                    <div
                      className={`font-extrabold ${
                        selectedForecast.estimatedNetProfit >= 0
                          ? 'text-emerald-600 dark:text-emerald-300'
                          : 'text-rose-500'
                      }`}
                    >
                      {selectedForecast.estimatedNetProfit >= 0 ? '+' : ''}
                      {formatCurrency(selectedForecast.estimatedNetProfit)}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Action Buttons: Add to Tour OR Play Solo */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => {
                  const res = onAddTourDate({
                    venueId: selectedVenue.id,
                    dayOffset: plannedDayOffset,
                    ticketPrice: plannedTicketPrice,
                    transportTier: plannedTransport,
                    lodgingTier: plannedLodging,
                    productionTier: plannedProduction,
                  });
                  if (res.error) {
                    onFeedback(res.error);
                    return;
                  }
                  soundEngine.playSuccessChord();
                  setPlannedDayOffset((d) => d + 3);
                  onFeedback(
                    `Date ajoutée : ${selectedVenue.name} (${selectedVenue.city}) le ${formatShortDate(plannedDayOffset)}.`
                  );
                }}
                className="min-h-[48px] rounded-2xl bg-violet-600 hover:bg-violet-500 text-white font-extrabold text-sm flex items-center justify-center gap-2 active:scale-[0.98] transition"
              >
                <Plus className="h-4 w-4" />
                <span>Ajouter à la tournée</span>
              </button>

              <button
                type="button"
                disabled={
                  !selectedForecast ||
                  artist.cash < selectedForecast.costs.totalCost ||
                  artist.energy < selectedForecast.energyCost
                }
                onClick={() => {
                  const res = onPerformSoloConcert(selectedVenue.id, plannedTicketPrice, {
                    transportTier: plannedTransport,
                    lodgingTier: plannedLodging,
                    productionTier: plannedProduction,
                  });
                  if (res.error) {
                    onFeedback(res.error);
                    return;
                  }
                  soundEngine.playSuccessChord();
                  if (res.log) {
                    setLastShowReport(res.log);
                    onFeedback(
                      `Concert solo terminé à ${res.log.venueName} : +${formatCurrency(res.log.netProfit)} net.`
                    );
                  }
                }}
                className="min-h-[48px] rounded-2xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 disabled:opacity-40 active:scale-[0.98] transition"
              >
                <Ticket className="h-4 w-4" />
                <span>
                  Concert solo ({formatCurrency(selectedForecast?.costs.totalCost ?? selectedVenue.bookingCost)})
                </span>
              </button>
            </div>
          </section>

          {/* Right: Active Tour Schedule (Full Modify / Move / Postpone / Delete / Play) */}
          <section className="lg:col-span-5 liquid-glass rounded-3xl p-5 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <div>
                <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                  {activeTour ? activeTour.name : 'Itinéraire de tournée'}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {activeTour
                    ? `${tourAggregate.dates.length} date(s) · Glisse les poignées pour réorganiser`
                    : 'Ajoute ta première date pour démarrer une tournée'}
                </p>
              </div>
              <div className="flex items-center gap-1.5">
                {tourAggregate.dates.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      soundEngine.playGlassTap();
                      setSubTab('map');
                    }}
                    className="min-h-[36px] px-2.5 rounded-xl liquid-glass-subtle text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center gap-1"
                  >
                    <MapIcon className="h-3.5 w-3.5 text-sky-500" />
                    <span>Carte</span>
                  </button>
                )}
                {activeTour && activeTour.status !== 'active' && tourAggregate.upcomingCount > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      soundEngine.playSuccessChord();
                      onUpdateTourSettings({ status: 'active' });
                    }}
                    className="min-h-[36px] px-3 rounded-xl bg-violet-600 text-white text-xs font-extrabold"
                  >
                    Lancer
                  </button>
                )}
              </div>
            </div>

            {tourAggregate.dates.length === 0 ? (
              <div className="liquid-glass-subtle rounded-2xl p-6 text-center space-y-2">
                <Calendar className="h-8 w-8 text-slate-400 mx-auto" />
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Sélectionne un pays, une salle et clique sur « Ajouter à la tournée » pour construire ton calendrier librement.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-1">
                {(() => {
                  const playedDates = tourAggregate.dates.filter(
                    (d: TourDateItem) => d.status === 'played'
                  );
                  const unplayedDates = tourAggregate.dates.filter(
                    (d: TourDateItem) => d.status !== 'played'
                  );
                  const unplayedIds = unplayedDates.map((d: TourDateItem) => d.id);

                  return (
                    <>
                      {playedDates.map((item: TourDateItem, idx: number) => {
                        const fillPct = Math.min(
                          100,
                          Math.round(
                            (item.ticketsSold / Math.max(1, item.capacity)) * 100
                          )
                        );
                        return (
                          <div
                            key={item.id}
                            className="liquid-glass-subtle rounded-2xl p-3.5 space-y-2 opacity-85"
                          >
                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5 text-[11px] font-bold">
                                <span className="font-mono text-slate-500">
                                  #{idx + 1}
                                </span>
                                <span className="text-slate-400">·</span>
                                <span className="text-emerald-600 dark:text-emerald-300">
                                  Joué
                                </span>
                                <span className="text-slate-400">·</span>
                                <span className="text-slate-600 dark:text-slate-300">
                                  {formatShortDate(item.dayOffset)}
                                </span>
                              </div>
                              <div className="text-sm font-extrabold text-slate-900 dark:text-white truncate">
                                {item.venueName}
                              </div>
                              <div className="text-xs text-slate-500 dark:text-slate-400">
                                {item.city}, {item.country} · Billet{' '}
                                {formatCurrency(item.ticketPrice)}
                              </div>
                            </div>
                            <div className="space-y-1">
                              <div className="flex items-center justify-between text-[11px] font-mono tabular-nums text-slate-600 dark:text-slate-300">
                                <span>
                                  Spectateurs : {formatCompactNumber(item.ticketsSold)}{' '}
                                  / {formatCompactNumber(item.capacity)}
                                </span>
                                <span>{fillPct}%</span>
                              </div>
                              <div className="h-1.5 rounded-full bg-slate-900/10 dark:bg-white/10 overflow-hidden">
                                <div
                                  className="h-full rounded-full bg-emerald-500"
                                  style={{ width: `${fillPct}%` }}
                                />
                              </div>
                            </div>
                            {item.report && (
                              <div className="flex items-center justify-between text-xs font-mono pt-1 border-t border-slate-900/10 dark:border-white/10">
                                <span className="text-slate-500">
                                  Sat. {item.report.satisfaction}%
                                </span>
                                <span
                                  className={`font-bold ${
                                    item.report.netProfit >= 0
                                      ? 'text-emerald-600 dark:text-emerald-300'
                                      : 'text-rose-500'
                                  }`}
                                >
                                  {item.report.netProfit >= 0 ? '+' : ''}
                                  {formatCurrency(item.report.netProfit)}
                                </span>
                              </div>
                            )}
                          </div>
                        );
                      })}

                      {unplayedDates.length > 0 && (
                        <Reorder.Group
                          axis="y"
                          values={unplayedIds}
                          onReorder={(newOrder) => onReorderTourDates(newOrder)}
                          className="space-y-2.5"
                        >
                          {unplayedDates.map((item: TourDateItem, uIdx: number) => (
                            <DraggableCalendarCard
                              key={item.id}
                              item={item}
                              stepNumber={playedDates.length + uIdx + 1}
                              isFirstUnplayed={uIdx === 0}
                              isLastUnplayed={uIdx === unplayedDates.length - 1}
                              isEditing={editingDateId === item.id}
                              isPostponing={postponingDateId === item.id}
                              postponeTargetDay={postponeTargetDay}
                              setPostponeTargetDay={setPostponeTargetDay}
                              onToggleEdit={() => {
                                setPostponingDateId(null);
                                setEditingDateId(
                                  editingDateId === item.id ? null : item.id
                                );
                              }}
                              onTogglePostpone={() => {
                                setEditingDateId(null);
                                setPostponeTargetDay(item.dayOffset + 7);
                                setPostponingDateId(
                                  postponingDateId === item.id ? null : item.id
                                );
                              }}
                              onMoveTourDate={onMoveTourDate}
                              onUpdateTourDate={onUpdateTourDate}
                              onPostponeTourDate={onPostponeTourDate}
                              onRemoveTourDate={onRemoveTourDate}
                              onPlayDate={(id) => handlePlayDate(id)}
                              onFeedback={onFeedback}
                            />
                          ))}
                        </Reorder.Group>
                      )}
                    </>
                  );
                })()}
              </div>
            )}
          </section>
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 3: LOGISTIQUE, ÉQUIPE & VENTILATION DES COÛTS                   */}
      {/* =================================================================== */}
      {subTab === 'logistics' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-7 space-y-4">
            {/* Transport */}
            <section className="liquid-glass rounded-3xl p-5 space-y-3">
              <div className="flex items-center gap-2">
                <Plane className="h-4 w-4 text-sky-500" />
                <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                  Transport & Déplacements
                </h3>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {TOUR_TRANSPORT_OPTIONS.map((opt) => {
                  const active =
                    (activeTour?.defaultTransportTier ?? plannedTransport) === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => {
                        setPlannedTransport(opt.id);
                        if (activeTour) {
                          onUpdateTourSettings({ defaultTransportTier: opt.id });
                        }
                      }}
                      className={`text-left rounded-2xl p-3.5 transition ${
                        active
                          ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950'
                          : 'liquid-glass-subtle text-slate-900 dark:text-white'
                      }`}
                    >
                      <div className="text-xs font-extrabold">{opt.name}</div>
                      <p className="text-[11px] opacity-80 mt-1">{opt.subtitle}</p>
                      <div className="mt-2 text-[11px] font-mono tabular-nums opacity-90">
                        Base {formatCurrency(opt.baseCost)} · -{opt.energyRelief} én.
                      </div>
                    </button>
                  );
                })}
              </div>
            </section>

            {/* Lodging */}
            <section className="liquid-glass rounded-3xl p-5 space-y-3">
              <div className="flex items-center gap-2">
                <Hotel className="h-4 w-4 text-violet-500" />
                <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                  Hébergement Artiste & Équipe
                </h3>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {TOUR_LODGING_OPTIONS.map((opt) => {
                  const active = (activeTour?.defaultLodgingTier ?? plannedLodging) === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => {
                        setPlannedLodging(opt.id);
                        if (activeTour) {
                          onUpdateTourSettings({ defaultLodgingTier: opt.id });
                        }
                      }}
                      className={`text-left rounded-2xl p-3.5 transition ${
                        active
                          ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950'
                          : 'liquid-glass-subtle text-slate-900 dark:text-white'
                      }`}
                    >
                      <div className="text-xs font-extrabold">{opt.name}</div>
                      <p className="text-[11px] opacity-80 mt-1">{opt.subtitle}</p>
                      <div className="mt-2 text-[11px] font-mono tabular-nums opacity-90">
                        Base {formatCurrency(opt.baseCost)} · +{opt.satisfactionBonus}% sat.
                      </div>
                    </button>
                  );
                })}
              </div>
            </section>

            {/* Production */}
            <section className="liquid-glass rounded-3xl p-5 space-y-3">
              <div className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-amber-500" />
                <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                  Production Scénique & Technique
                </h3>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {TOUR_PRODUCTION_OPTIONS.map((opt) => {
                  const active =
                    (activeTour?.defaultProductionTier ?? plannedProduction) === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => {
                        setPlannedProduction(opt.id);
                        if (activeTour) {
                          onUpdateTourSettings({ defaultProductionTier: opt.id });
                        }
                      }}
                      className={`text-left rounded-2xl p-3.5 transition ${
                        active
                          ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950'
                          : 'liquid-glass-subtle text-slate-900 dark:text-white'
                      }`}
                    >
                      <div className="text-xs font-extrabold">{opt.name}</div>
                      <p className="text-[11px] opacity-80 mt-1">{opt.subtitle}</p>
                      <div className="mt-2 text-[11px] font-mono tabular-nums opacity-90">
                        Base {formatCurrency(opt.baseCost)} · ×{opt.attendanceBoost} demande
                      </div>
                    </button>
                  );
                })}
              </div>
            </section>
          </div>

          {/* Right: Budget Breakdown & Staff Impact */}
          <div className="lg:col-span-5 space-y-4">
            <section className="liquid-glass rounded-3xl p-5 space-y-4">
              <div className="flex items-center gap-2">
                <Wallet className="h-4 w-4 text-emerald-500" />
                <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                  Budget détaillé {activeTour ? `· ${activeTour.name}` : '· Simulation'}
                </h3>
              </div>

              {activeTour && tourAggregate.dates.length > 0 ? (
                <div className="space-y-2.5 text-xs font-mono tabular-nums">
                  {[
                    {
                      label: 'Location des salles',
                      value: tourAggregate.costByCategory.venueCost,
                      Icon: Building2,
                    },
                    {
                      label: 'Transport & fret',
                      value: tourAggregate.costByCategory.transportCost,
                      Icon: Truck,
                    },
                    {
                      label: 'Hébergement équipe',
                      value: tourAggregate.costByCategory.lodgingCost,
                      Icon: Hotel,
                    },
                    {
                      label: 'Équipe technique & sécurité',
                      value: tourAggregate.costByCategory.crewCost,
                      Icon: Users,
                    },
                    {
                      label: 'Production scénique',
                      value: tourAggregate.costByCategory.productionCost,
                      Icon: Sparkles,
                    },
                  ].map(({ label, value, Icon }) => (
                    <div
                      key={label}
                      className="liquid-glass-subtle rounded-2xl px-3.5 py-2.5 flex items-center justify-between"
                    >
                      <span className="font-sans font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-2">
                        <Icon className="h-3.5 w-3.5 text-slate-400" />
                        <span>{label}</span>
                      </span>
                      <span className="font-bold text-rose-600 dark:text-rose-300">
                        -{formatCurrency(value)}
                      </span>
                    </div>
                  ))}

                  <div className="pt-2 border-t border-slate-900/10 dark:border-white/10 flex items-center justify-between text-sm font-extrabold">
                    <span className="font-sans text-slate-900 dark:text-white">
                      Total estimé (réalisé + prévu)
                    </span>
                    <span className="text-emerald-600 dark:text-emerald-300">
                      {formatCurrency(
                        tourAggregate.realizedProfit + tourAggregate.projectedProfit
                      )}{' '}
                      net
                    </span>
                  </div>
                </div>
              ) : (
                selectedForecast && (
                  <div className="space-y-2 text-xs font-mono tabular-nums">
                    <p className="font-sans text-slate-500 dark:text-slate-400">
                      Estimation unitaire pour {selectedVenue.name} ({selectedVenue.city}) :
                    </p>
                    <div className="liquid-glass-subtle rounded-2xl px-3.5 py-2 flex justify-between">
                      <span className="font-sans">Salle</span>
                      <span className="text-rose-500">
                        -{formatCurrency(selectedForecast.costs.venueCost)}
                      </span>
                    </div>
                    <div className="liquid-glass-subtle rounded-2xl px-3.5 py-2 flex justify-between">
                      <span className="font-sans">Transport</span>
                      <span className="text-rose-500">
                        -{formatCurrency(selectedForecast.costs.transportCost)}
                      </span>
                    </div>
                    <div className="liquid-glass-subtle rounded-2xl px-3.5 py-2 flex justify-between">
                      <span className="font-sans">Hébergement</span>
                      <span className="text-rose-500">
                        -{formatCurrency(selectedForecast.costs.lodgingCost)}
                      </span>
                    </div>
                    <div className="liquid-glass-subtle rounded-2xl px-3.5 py-2 flex justify-between">
                      <span className="font-sans">Équipe & sécurité</span>
                      <span className="text-rose-500">
                        -{formatCurrency(selectedForecast.costs.crewCost)}
                      </span>
                    </div>
                    <div className="liquid-glass-subtle rounded-2xl px-3.5 py-2 flex justify-between">
                      <span className="font-sans">Production</span>
                      <span className="text-rose-500">
                        -{formatCurrency(selectedForecast.costs.productionCost)}
                      </span>
                    </div>
                  </div>
                )
              )}
            </section>

            <section className="liquid-glass rounded-3xl p-5 space-y-3">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-violet-500" />
                <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                  Bonus Équipe & Merch
                </h3>
              </div>
              <div className="space-y-2 text-xs">
                {STAFF_CATALOG.filter(
                  (s) => s.id === 'manager' || s.id === 'tour_director'
                ).map((s) => {
                  const hired = artist.hiredStaffIds.includes(s.id);
                  return (
                    <div
                      key={s.id}
                      className="liquid-glass-subtle rounded-2xl p-3 flex items-center justify-between gap-2"
                    >
                      <div>
                        <div className="font-bold text-slate-900 dark:text-white">
                          {s.role} · {s.name}
                        </div>
                        <div className="text-slate-500 dark:text-slate-400">
                          {s.bonusDescription}
                        </div>
                      </div>
                      <span
                        className={`font-bold shrink-0 ${
                          hired ? 'text-emerald-500' : 'text-slate-400'
                        }`}
                      >
                        {hired ? 'Actif' : 'Non recruté'}
                      </span>
                    </div>
                  );
                })}
                <div className="liquid-glass-subtle rounded-2xl p-3 flex items-center justify-between">
                  <span className="font-bold text-slate-900 dark:text-white">
                    Recettes Merch sur place
                  </span>
                  <span className="font-mono font-bold text-emerald-600 dark:text-emerald-300">
                    +{(unlockedMerchCount * 2.5).toFixed(1)} € / spectateur
                  </span>
                </div>
              </div>
            </section>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 4: HISTORIQUE INDIVIDUEL DES CONCERTS                           */}
      {/* =================================================================== */}
      {subTab === 'history' && (
        <section className="liquid-glass rounded-3xl p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                Historique individuel des concerts
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Chaque date jouée conserve le détail complet de ses recettes, charges et retombées.
              </p>
            </div>
            <span className="text-xs font-mono tabular-nums text-slate-500">
              {concerts.length} concert{concerts.length > 1 ? 's' : ''}
            </span>
          </div>

          {concerts.length === 0 ? (
            <div className="liquid-glass-subtle rounded-2xl p-8 text-center space-y-2">
              <CheckCircle2 className="h-8 w-8 text-slate-400 mx-auto" />
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Aucun concert joué pour le moment. Programme une date dans le Calendrier pour commencer ton parcours live.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {concerts.map((c) => {
                const expanded = expandedHistoryId === c.id;
                const fillPct = Math.round((c.attendance / Math.max(1, c.capacity)) * 100);
                return (
                  <div key={c.id} className="liquid-glass-subtle rounded-2xl p-4 space-y-3">
                    <button
                      type="button"
                      onClick={() => setExpandedHistoryId(expanded ? null : c.id)}
                      className="w-full text-left flex flex-wrap items-center justify-between gap-3"
                    >
                      <div className="min-w-0 space-y-0.5">
                        <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400">
                          <span>
                            {c.dayOffset !== undefined
                              ? formatShortDate(c.dayOffset)
                              : `Semaine ${c.week}`}
                          </span>
                          <span>·</span>
                          <span>
                            {c.city}
                            {c.country ? `, ${c.country}` : ''}
                          </span>
                          {c.tourName && (
                            <>
                              <span>·</span>
                              <span className="font-bold text-violet-600 dark:text-violet-300">
                                {c.tourName}
                              </span>
                            </>
                          )}
                        </div>
                        <div className="text-sm font-extrabold text-slate-900 dark:text-white truncate">
                          {c.venueName} — {c.showType}
                        </div>
                        <div className="text-xs font-mono tabular-nums text-slate-600 dark:text-slate-300">
                          {formatCompactNumber(c.attendance)}/{formatCompactNumber(c.capacity)}{' '}
                          spectateurs ({fillPct}%) · Billet {formatCurrency(c.ticketPrice)} ·
                          Satisfaction {c.satisfaction}%
                        </div>
                      </div>

                      <div className="flex items-center gap-3 shrink-0">
                        <div className="text-right font-mono tabular-nums">
                          <div
                            className={`text-sm font-extrabold ${
                              c.netProfit >= 0
                                ? 'text-emerald-600 dark:text-emerald-300'
                                : 'text-rose-500'
                            }`}
                          >
                            {c.netProfit >= 0 ? '+' : ''}
                            {formatCurrency(c.netProfit)}
                          </div>
                          <div className="text-[11px] text-slate-500">
                            +{formatCompactNumber(c.fansGained)} fans
                          </div>
                        </div>
                        {expanded ? (
                          <ChevronUp className="h-4 w-4 text-slate-400" />
                        ) : (
                          <ChevronDown className="h-4 w-4 text-slate-400" />
                        )}
                      </div>
                    </button>

                    {expanded && (
                      <div className="pt-3 border-t border-slate-900/10 dark:border-white/10 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono tabular-nums">
                        <div className="space-y-1.5">
                          <div className="font-sans font-bold text-emerald-600 dark:text-emerald-300">
                            Recettes détaillées
                          </div>
                          <div className="flex justify-between">
                            <span className="font-sans text-slate-500">Billetterie</span>
                            <span>
                              +{formatCurrency(c.ticketRevenue ?? c.attendance * c.ticketPrice)}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="font-sans text-slate-500">Stand Merch</span>
                            <span>
                              +
                              {formatCurrency(
                                c.merchRevenue ??
                                  Math.max(0, c.grossRevenue - c.attendance * c.ticketPrice)
                              )}
                            </span>
                          </div>
                          <div className="flex justify-between font-bold border-t border-slate-900/10 dark:border-white/10 pt-1">
                            <span className="font-sans">Total brut</span>
                            <span className="text-emerald-600 dark:text-emerald-300">
                              +{formatCurrency(c.grossRevenue)}
                            </span>
                          </div>
                        </div>

                        <div className="space-y-1.5">
                          <div className="font-sans font-bold text-rose-600 dark:text-rose-300">
                            Dépenses détaillées
                          </div>
                          {c.costs ? (
                            <>
                              <div className="flex justify-between">
                                <span className="font-sans text-slate-500">Location salle</span>
                                <span>-{formatCurrency(c.costs.venueCost)}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="font-sans text-slate-500">Transport</span>
                                <span>-{formatCurrency(c.costs.transportCost)}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="font-sans text-slate-500">Hébergement</span>
                                <span>-{formatCurrency(c.costs.lodgingCost)}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="font-sans text-slate-500">Équipe & Prod</span>
                                <span>
                                  -{formatCurrency(c.costs.crewCost + c.costs.productionCost)}
                                </span>
                              </div>
                            </>
                          ) : (
                            <div className="flex justify-between">
                              <span className="font-sans text-slate-500">Frais globaux</span>
                              <span>-{formatCurrency(c.grossRevenue - c.netProfit)}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </section>
      )}
    </div>
  );
};
