import React, { useMemo, useState } from 'react';
import {
  Compass,
  Globe2,
  GripVertical,
  MapPin,
  Mic,
  Plus,
  Route,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import { Reorder, useDragControls } from 'motion/react';
import { CONCERT_VENUES } from '../data/gameData';
import {
  haversineDistanceKm,
  TOUR_CONTINENTS,
  TOUR_DESTINATIONS,
} from '../data/tourDestinations';
import {
  ConcertVenue,
  TourCityDestination,
  TourContinent,
  TourDateItem,
} from '../types/game';
import { soundEngine } from '../utils/audio';
import {
  formatCompactNumber,
  formatCurrency,
  formatShortDate,
} from '../utils/format';

type MapFocusRegion = 'world' | 'europe' | 'americas' | 'asia' | 'oceania';

const MAP_WIDTH = 800;
const MAP_HEIGHT = 400;

const REGION_VIEWBOX: Record<
  MapFocusRegion,
  { label: string; vb: string; w: number }
> = {
  world: { label: 'Monde', vb: '0 15 800 365', w: 800 },
  europe: { label: 'Europe', vb: '355 58 112 80', w: 112 },
  americas: { label: 'Amériques', vb: '95 65 200 135', w: 200 },
  asia: { label: 'Asie', vb: '575 88 185 162', w: 185 },
  oceania: { label: 'Océanie', vb: '640 252 160 124', w: 160 },
};

function toMapXY(lat: number, lng: number): [number, number] {
  const x = ((lng + 180) / 360) * MAP_WIDTH;
  const y = ((82 - lat) / 140) * MAP_HEIGHT;
  return [x, y];
}

function pointsToSvgPath(coords: Array<[number, number]>): string {
  return (
    coords
      .map(([lat, lng], i) => {
        const [x, y] = toMapXY(lat, lng);
        return `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ') + ' Z'
  );
}

const CONTINENT_PATHS = [
  // North America
  pointsToSvgPath([
    [68, -165],
    [70, -140],
    [69, -105],
    [62, -92],
    [58, -78],
    [52, -56],
    [45, -62],
    [44, -68],
    [41, -71],
    [40, -74],
    [35, -76],
    [25, -80],
    [29, -83],
    [28, -96],
    [20, -97],
    [18, -87],
    [14, -84],
    [9, -79],
    [15, -93],
    [20, -105],
    [28, -112],
    [32, -117],
    [38, -123],
    [48, -125],
    [58, -136],
    [60, -150],
    [62, -165],
  ]),
  // Greenland
  pointsToSvgPath([
    [81, -45],
    [79, -18],
    [70, -22],
    [60, -44],
    [67, -54],
    [76, -68],
  ]),
  // South America
  pointsToSvgPath([
    [11, -74],
    [10, -62],
    [5, -52],
    [-5, -35],
    [-18, -39],
    [-24, -46],
    [-35, -57],
    [-54, -68],
    [-52, -74],
    [-40, -73],
    [-20, -70],
    [-5, -81],
    [5, -77],
  ]),
  // UK
  pointsToSvgPath([
    [58.5, -5],
    [57.5, -2],
    [53, -0.5],
    [51.2, 1.4],
    [50.2, -5.2],
    [52, -5],
    [54, -3.5],
    [56, -5.5],
  ]),
  // Ireland
  pointsToSvgPath([
    [55.2, -7.5],
    [54, -6],
    [52, -6.5],
    [51.8, -9.8],
    [54, -9.8],
  ]),
  // Continental Europe
  pointsToSvgPath([
    [36, -9],
    [38.5, -9.3],
    [43.5, -9],
    [43.3, -1.8],
    [46, -1.2],
    [48.5, -4.5],
    [50, 1.5],
    [51.2, 2.6],
    [53.5, 6.5],
    [54.5, 8.5],
    [57, 8.5],
    [55, 10.5],
    [54, 14],
    [56, 21],
    [59, 24],
    [60, 30],
    [68, 32],
    [70, 25],
    [68, 15],
    [63, 10],
    [59, 5.5],
    [58, 8],
    [56, 12.5],
    [54, 19],
    [55, 21],
    [52, 24],
    [48, 26],
    [45, 30],
    [42, 29],
    [40, 26],
    [37, 22],
    [40, 19.5],
    [42, 16],
    [40, 18],
    [38, 15.5],
    [41, 13.5],
    [44, 9.5],
    [43.3, 5.4],
    [42.5, 3],
    [39, 0],
    [36, -5.5],
  ]),
  // Africa
  pointsToSvgPath([
    [35.8, -5.5],
    [37, 10],
    [32, 15],
    [31, 32],
    [20, 38],
    [11, 44],
    [11, 51],
    [2, 45],
    [-10, 40],
    [-25, 35],
    [-34, 20],
    [-22, 14],
    [-5, 12],
    [5, 2],
    [5, -8],
    [15, -17],
    [28, -13],
  ]),
  // Asia
  pointsToSvgPath([
    [42, 29],
    [42, 42],
    [45, 48],
    [55, 60],
    [68, 68],
    [72, 105],
    [70, 140],
    [65, 175],
    [55, 160],
    [50, 140],
    [42, 132],
    [38, 128],
    [35, 126],
    [38, 121],
    [31, 122],
    [22, 114],
    [20, 106],
    [12, 109],
    [10, 104],
    [2, 103],
    [8, 98],
    [16, 96],
    [22, 90],
    [15, 80],
    [8, 77],
    [22, 68],
    [25, 60],
    [27, 50],
    [13, 44],
    [20, 39],
    [31, 33],
    [37, 35],
    [39, 26],
  ]),
  // Japan
  pointsToSvgPath([
    [45, 142],
    [42, 145],
    [41, 141],
    [38, 141],
    [35.5, 140.5],
    [34.5, 137],
    [33.5, 131],
    [34.5, 131],
    [36, 136],
    [39, 140],
    [41, 140],
    [43, 140],
  ]),
  // Australia
  pointsToSvgPath([
    [-12, 131],
    [-12, 142],
    [-25, 153],
    [-38, 147],
    [-35, 136],
    [-33, 115],
    [-22, 114],
  ]),
  // New Zealand (North & South Islands)
  pointsToSvgPath([
    [-34.5, 173],
    [-37.5, 178.5],
    [-41.5, 175],
    [-39, 174],
    [-36.5, 174.3],
  ]),
  pointsToSvgPath([
    [-40.8, 172.5],
    [-43.5, 172.8],
    [-46.5, 168.5],
    [-45.8, 166.5],
    [-42.5, 170.5],
  ]),
];

interface DraggableStopRowProps {
  item: TourDateItem;
  stepNumber: number;
  isHighlighted: boolean;
  distanceFromPrevKm: number | null;
  onHighlight: (dateId: string | null) => void;
  onPlayDate: (dateId: string) => void;
  onRemoveDate: (dateId: string) => void;
}

const DraggableStopRow: React.FC<DraggableStopRowProps> = ({
  item,
  stepNumber,
  isHighlighted,
  distanceFromPrevKm,
  onHighlight,
  onPlayDate,
  onRemoveDate,
}) => {
  const dragControls = useDragControls();
  const fillPct = Math.min(
    100,
    Math.round((item.ticketsSold / Math.max(1, item.capacity)) * 100)
  );

  return (
    <Reorder.Item
      value={item.id}
      dragListener={false}
      dragControls={dragControls}
      onMouseEnter={() => onHighlight(item.id)}
      onMouseLeave={() => onHighlight(null)}
      whileDrag={{ scale: 1.02 }}
      className={`rounded-2xl p-3 transition select-none ${
        isHighlighted
          ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950 shadow-lg'
          : 'liquid-glass-subtle text-slate-900 dark:text-white'
      }`}
    >
      <div className="flex items-center gap-2.5">
        <button
          type="button"
          aria-label={`Glisser ${item.venueName}`}
          onPointerDown={(e) => {
            soundEngine.playGlassTap();
            dragControls.start(e);
          }}
          className="min-h-[44px] min-w-[36px] rounded-xl flex items-center justify-center cursor-grab active:cursor-grabbing touch-none opacity-75 hover:opacity-100"
        >
          <GripVertical className="h-4 w-4" />
        </button>

        <div
          className={`h-7 w-7 rounded-full text-xs font-extrabold font-mono flex items-center justify-center shrink-0 ${
            item.status === 'postponed'
              ? 'bg-amber-500 text-slate-950'
              : 'bg-violet-600 text-white'
          }`}
        >
          {stepNumber}
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5 text-[11px] opacity-80">
            <span className="font-mono font-bold">
              {formatShortDate(item.dayOffset)}
            </span>
            <span>·</span>
            <span className="truncate">
              {item.city}, {item.country}
            </span>
            {distanceFromPrevKm !== null && distanceFromPrevKm > 0 && (
              <>
                <span>·</span>
                <span className="font-mono shrink-0">
                  {formatCompactNumber(distanceFromPrevKm)} km
                </span>
              </>
            )}
          </div>
          <div className="text-xs sm:text-sm font-extrabold truncate">
            {item.venueName}
          </div>
          <div className="text-[11px] font-mono tabular-nums opacity-75">
            {formatCurrency(item.ticketPrice)} · {fillPct}% prévendu
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={() => onPlayDate(item.id)}
            className={`min-h-[38px] px-2.5 rounded-xl text-xs font-extrabold flex items-center gap-1 ${
              isHighlighted
                ? 'bg-violet-500 text-white'
                : 'bg-slate-900 dark:bg-white text-white dark:text-slate-950'
            }`}
          >
            <Mic className="h-3.5 w-3.5" />
            <span>Jouer</span>
          </button>

          <button
            type="button"
            aria-label={`Supprimer ${item.venueName}`}
            onClick={() => onRemoveDate(item.id)}
            className={`min-h-[38px] w-9 rounded-xl flex items-center justify-center ${
              isHighlighted
                ? 'bg-rose-500/20 text-rose-300'
                : 'liquid-glass text-rose-500'
            }`}
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </Reorder.Item>
  );
};

interface TourRouteMapProps {
  dates: TourDateItem[];
  tourName?: string;
  onReorderUnplayed: (orderedUnplayedIds: string[]) => void;
  onPlayDate: (dateId: string) => void;
  onRemoveDate: (dateId: string) => void;
  onSelectVenueForAdd: (venueId: string) => void;
}

interface CatalogCityEntry {
  city: TourCityDestination;
  venues: ConcertVenue[];
}

export const TourRouteMap: React.FC<TourRouteMapProps> = ({
  dates,
  tourName,
  onReorderUnplayed,
  onPlayDate,
  onRemoveDate,
  onSelectVenueForAdd,
}) => {
  const [focusRegion, setFocusRegion] = useState<MapFocusRegion>('world');
  const [continentFilter, setContinentFilter] = useState<'Tous' | TourContinent>('Tous');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [highlightedDateId, setHighlightedDateId] = useState<string | null>(null);
  const [inspectedCityId, setInspectedCityId] = useState<string | null>(null);

  const regionConfig = REGION_VIEWBOX[focusRegion];
  const scale = regionConfig.w / MAP_WIDTH;

  const venueMap = useMemo(
    () => new Map(CONCERT_VENUES.map((v) => [v.id, v])),
    []
  );

  // Extensible catalog cities derived from TOUR_DESTINATIONS + linked CONCERT_VENUES
  const catalogCities = useMemo<CatalogCityEntry[]>(() => {
    return TOUR_DESTINATIONS.map((city) => ({
      city,
      venues: CONCERT_VENUES.filter(
        (v) =>
          v.cityId === city.id ||
          (v.city.toLowerCase() === city.name.toLowerCase() &&
            (v.country ?? 'France').toLowerCase() === city.country.toLowerCase())
      ),
    })).filter((entry) => entry.venues.length > 0);
  }, []);

  const filteredCatalogCities = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return catalogCities.filter(({ city }) => {
      if (continentFilter !== 'Tous' && city.continent !== continentFilter) {
        return false;
      }
      if (!q) return true;
      return (
        city.name.toLowerCase().includes(q) ||
        city.country.toLowerCase().includes(q) ||
        city.continent.toLowerCase().includes(q)
      );
    });
  }, [catalogCities, continentFilter, searchQuery]);

  // Tour stops enriched with coordinates & automatic Haversine distances
  const routeStops = useMemo(() => {
    let prevLat: number | null = null;
    let prevLng: number | null = null;
    return dates.map((d, idx) => {
      const venue = venueMap.get(d.venueId);
      const lat = venue?.lat ?? 48.8566;
      const lng = venue?.lng ?? 2.3522;
      const [x, y] = toMapXY(lat, lng);
      const distanceKm =
        prevLat !== null && prevLng !== null
          ? haversineDistanceKm(prevLat, prevLng, lat, lng)
          : null;
      prevLat = lat;
      prevLng = lng;
      return {
        item: d,
        stepNumber: idx + 1,
        lat,
        lng,
        x,
        y,
        distanceKm,
      };
    });
  }, [dates, venueMap]);

  const totalRouteKm = useMemo(
    () => routeStops.reduce((sum, s) => sum + (s.distanceKm ?? 0), 0),
    [routeStops]
  );

  const routeCoverage = useMemo(() => {
    const countries = new Set<string>();
    const continents = new Set<string>();
    dates.forEach((d) => {
      if (d.status === 'cancelled') return;
      countries.add(d.country);
      const v = venueMap.get(d.venueId);
      const continent = d.continent ?? v?.continent;
      if (continent) continents.add(continent);
    });
    return {
      countriesCount: countries.size,
      continentsCount: continents.size,
    };
  }, [dates, venueMap]);

  const playedStops = useMemo(
    () => routeStops.filter((s) => s.item.status === 'played'),
    [routeStops]
  );
  const unplayedStops = useMemo(
    () => routeStops.filter((s) => s.item.status !== 'played'),
    [routeStops]
  );

  const unplayedIds = useMemo(
    () => unplayedStops.map((s) => s.item.id),
    [unplayedStops]
  );

  const inspectedCityData = useMemo(
    () => catalogCities.find((entry) => entry.city.id === inspectedCityId) ?? null,
    [catalogCities, inspectedCityId]
  );

  const highlightedStop = useMemo(
    () => routeStops.find((s) => s.item.id === highlightedDateId) ?? null,
    [routeStops, highlightedDateId]
  );

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
      {/* Left: Interactive SVG World / Regional Map */}
      <section className="lg:col-span-7 liquid-glass rounded-3xl p-4 sm:p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <div className="flex items-center gap-1.5 text-xs font-extrabold text-sky-600 dark:text-sky-300">
              <Globe2 className="h-3.5 w-3.5" />
              <span>Carte interactive · {tourName || 'Itinéraire libre'}</span>
            </div>
            <div className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400 mt-0.5">
              {routeStops.length} étape{routeStops.length > 1 ? 's' : ''} ·{' '}
              {routeCoverage.countriesCount} pays · {routeCoverage.continentsCount} cont. ·{' '}
              {formatCompactNumber(totalRouteKm)} km cumulés
            </div>
          </div>

          <div className="flex items-center gap-1 p-1 rounded-xl liquid-glass-subtle overflow-x-auto max-w-full">
            {(Object.keys(REGION_VIEWBOX) as MapFocusRegion[]).map((key) => (
              <button
                key={key}
                type="button"
                onClick={() => {
                  soundEngine.playGlassTap();
                  setFocusRegion(key);
                }}
                className={`min-h-[34px] px-2.5 rounded-lg text-[11px] font-bold whitespace-nowrap transition ${
                  focusRegion === key
                    ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950 shadow-sm'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                {REGION_VIEWBOX[key].label}
              </button>
            ))}
          </div>
        </div>

        {/* City / Country Search & Continent Filter Bar */}
        <div className="space-y-2">
          <div className="relative">
            <Search className="h-4 w-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher une ville ou un pays (ex. Sydney, Séoul, Canada)..."
              className="w-full min-h-[42px] rounded-2xl liquid-glass-subtle pl-10 pr-9 text-xs font-semibold text-slate-900 dark:text-white placeholder:text-slate-400"
            />
            {searchQuery && (
              <button
                type="button"
                aria-label="Effacer la recherche"
                onClick={() => setSearchQuery('')}
                className="h-7 w-7 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-700 dark:hover:text-white absolute right-2 top-1/2 -translate-y-1/2"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5">
            <button
              type="button"
              onClick={() => {
                soundEngine.playGlassTap();
                setContinentFilter('Tous');
                setFocusRegion('world');
              }}
              className={`min-h-[34px] px-3 rounded-xl text-[11px] font-bold whitespace-nowrap shrink-0 transition ${
                continentFilter === 'Tous'
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950'
                  : 'liquid-glass-subtle text-slate-600 dark:text-slate-300'
              }`}
            >
              Tous ({catalogCities.length} villes)
            </button>
            {TOUR_CONTINENTS.map((cont) => {
              const count = catalogCities.filter(
                (c) => c.city.continent === cont.id
              ).length;
              const active = continentFilter === cont.id;
              return (
                <button
                  key={cont.id}
                  type="button"
                  onClick={() => {
                    soundEngine.playGlassTap();
                    setContinentFilter(cont.id);
                    setFocusRegion(cont.mapFocusRegion);
                  }}
                  className={`min-h-[34px] px-3 rounded-xl text-[11px] font-bold whitespace-nowrap shrink-0 transition ${
                    active
                      ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950'
                      : 'liquid-glass-subtle text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {cont.label} ({count})
                </button>
              );
            })}
          </div>
        </div>

        {/* SVG Map Canvas */}
        <div className="relative rounded-2xl overflow-hidden bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 border border-white/10">
          <svg
            viewBox={regionConfig.vb}
            className="w-full h-[250px] sm:h-[320px] select-none transition-all duration-300"
            role="img"
            aria-label="Carte interactive de la tournée"
          >
            <defs>
              <radialGradient id="mapGlow" cx="50%" cy="45%" r="60%">
                <stop offset="0%" stopColor="rgba(56,189,248,0.12)" />
                <stop offset="100%" stopColor="rgba(15,23,42,0)" />
              </radialGradient>
            </defs>

            <rect x="0" y="0" width={MAP_WIDTH} height={MAP_HEIGHT} fill="url(#mapGlow)" />

            {/* Subtle Latitude/Longitude Graticules */}
            {[-60, -30, 0, 30, 60].map((lat) => {
              const [, y] = toMapXY(lat, 0);
              return (
                <line
                  key={`lat_${lat}`}
                  x1={0}
                  y1={y}
                  x2={MAP_WIDTH}
                  y2={y}
                  stroke="rgba(148,163,184,0.1)"
                  strokeWidth={0.8 * scale}
                />
              );
            })}
            {[-120, -60, 0, 60, 120].map((lng) => {
              const [x] = toMapXY(0, lng);
              return (
                <line
                  key={`lng_${lng}`}
                  x1={x}
                  y1={0}
                  x2={x}
                  y2={MAP_HEIGHT}
                  stroke="rgba(148,163,184,0.1)"
                  strokeWidth={0.8 * scale}
                />
              );
            })}

            {/* Continent Silhouettes */}
            <g>
              {CONTINENT_PATHS.map((d, i) => (
                <path
                  key={`land_${i}`}
                  d={d}
                  fill="rgba(255,255,255,0.08)"
                  stroke="rgba(148,163,184,0.28)"
                  strokeWidth={0.9 * scale}
                  strokeLinejoin="round"
                />
              ))}
            </g>

            {/* Catalog Destination City Pins (filtered by continent/search, clickable to inspect & add) */}
            {catalogCities.map(({ city }) => {
              const [cx, cy] = toMapXY(city.lat, city.lng);
              const matchesFilter = filteredCatalogCities.some(
                (f) => f.city.id === city.id
              );
              const isScheduled = routeStops.some(
                (s) => s.item.cityId === city.id || s.item.city === city.name
              );
              const isInspected = inspectedCityId === city.id;
              return (
                <g
                  key={city.id}
                  onClick={() => {
                    soundEngine.playGlassTap();
                    setInspectedCityId(isInspected ? null : city.id);
                  }}
                  opacity={matchesFilter ? 1 : 0.22}
                  className="cursor-pointer"
                >
                  <circle
                    cx={cx}
                    cy={cy}
                    r={(isInspected ? 6.5 : 3.8) * scale}
                    fill={
                      isInspected
                        ? '#38bdf8'
                        : isScheduled
                          ? 'rgba(139,92,246,0.45)'
                          : 'rgba(148,163,184,0.55)'
                    }
                    stroke="rgba(255,255,255,0.65)"
                    strokeWidth={0.8 * scale}
                  />
                  {(focusRegion !== 'world' || isInspected || (searchQuery.trim().length > 0 && matchesFilter)) && (
                    <text
                      x={cx}
                      y={cy - 7 * scale}
                      textAnchor="middle"
                      fill="rgba(226,232,240,0.9)"
                      fontSize={9 * scale}
                      fontWeight={600}
                    >
                      {city.name}
                    </text>
                  )}
                </g>
              );
            })}

            {/* Curved Route Arcs between sequential Tour Stops */}
            {routeStops.map((stop, idx) => {
              if (idx === 0) return null;
              const prev = routeStops[idx - 1];
              const dx = stop.x - prev.x;
              const dy = stop.y - prev.y;
              const dist = Math.hypot(dx, dy);
              if (dist < 0.5) return null;
              const midX = (prev.x + stop.x) / 2;
              const midY = (prev.y + stop.y) / 2 - Math.min(48 * scale, dist * 0.24);
              const segmentPlayed =
                prev.item.status === 'played' && stop.item.status === 'played';

              return (
                <path
                  key={`arc_${prev.item.id}_${stop.item.id}`}
                  d={`M ${prev.x.toFixed(1)} ${prev.y.toFixed(1)} Q ${midX.toFixed(1)} ${midY.toFixed(1)} ${stop.x.toFixed(1)} ${stop.y.toFixed(1)}`}
                  fill="none"
                  stroke={segmentPlayed ? '#34d399' : '#a78bfa'}
                  strokeWidth={(segmentPlayed ? 2.2 : 2.0) * scale}
                  strokeDasharray={segmentPlayed ? undefined : `${5 * scale} ${3.5 * scale}`}
                  strokeLinecap="round"
                  opacity={0.92}
                />
              );
            })}

            {/* Numbered Tour Stop Markers */}
            {routeStops.map((stop) => {
              const isPlayed = stop.item.status === 'played';
              const isPostponed = stop.item.status === 'postponed';
              const isHighlighted = highlightedDateId === stop.item.id;
              const radius = (isHighlighted ? 11.5 : 8.5) * scale;
              const fillColor = isPlayed
                ? '#10b981'
                : isPostponed
                  ? '#f59e0b'
                  : '#7c3aed';
              const matchedCity = catalogCities.find(
                (c) =>
                  c.city.id === stop.item.cityId ||
                  c.city.name.toLowerCase() === stop.item.city.toLowerCase()
              );

              return (
                <g
                  key={`pin_${stop.item.id}`}
                  onMouseEnter={() => setHighlightedDateId(stop.item.id)}
                  onMouseLeave={() => setHighlightedDateId(null)}
                  onClick={() => {
                    soundEngine.playGlassTap();
                    setHighlightedDateId(
                      highlightedDateId === stop.item.id ? null : stop.item.id
                    );
                    if (matchedCity) {
                      setInspectedCityId(matchedCity.city.id);
                    }
                  }}
                  className="cursor-pointer"
                >
                  {isHighlighted && (
                    <circle
                      cx={stop.x}
                      cy={stop.y}
                      r={16 * scale}
                      fill="rgba(167,139,250,0.28)"
                    />
                  )}
                  <circle
                    cx={stop.x}
                    cy={stop.y}
                    r={radius}
                    fill={fillColor}
                    stroke="#ffffff"
                    strokeWidth={1.6 * scale}
                  />
                  <text
                    x={stop.x}
                    y={stop.y + 3 * scale}
                    textAnchor="middle"
                    fill="#ffffff"
                    fontSize={8.5 * scale}
                    fontWeight={800}
                  >
                    {stop.stepNumber}
                  </text>
                </g>
              );
            })}
          </svg>

          {/* Floating Map Legend */}
          <div className="px-3.5 py-2.5 bg-slate-950/70 backdrop-blur-md border-t border-white/10 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-300">
            <div className="flex flex-wrap items-center gap-3">
              <span className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-violet-500" />
                Programmé
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-amber-500" />
                Reporté
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
                Joué
              </span>
            </div>
            <span className="text-slate-400">
              Touchez une ville pour afficher ses salles
            </span>
          </div>
        </div>

        {/* Filtered Cities Quick-Select Strip */}
        {(searchQuery.trim().length > 0 || continentFilter !== 'Tous') && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-[11px] font-bold text-slate-500 dark:text-slate-400">
              <span>
                {filteredCatalogCities.length} destination
                {filteredCatalogCities.length > 1 ? 's' : ''} trouvée
                {filteredCatalogCities.length > 1 ? 's' : ''}
              </span>
              {filteredCatalogCities.length > 0 && (
                <span>Sélectionne une ville pour voir ses salles</span>
              )}
            </div>
            {filteredCatalogCities.length === 0 ? (
              <div className="liquid-glass-subtle rounded-2xl p-3 text-xs text-slate-500">
                Aucune ville ou pays ne correspond à « {searchQuery} ».
              </div>
            ) : (
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                {filteredCatalogCities.map(({ city }) => {
                  const selected = inspectedCityId === city.id;
                  return (
                    <button
                      key={`strip_${city.id}`}
                      type="button"
                      onClick={() => {
                        soundEngine.playGlassTap();
                        setInspectedCityId(selected ? null : city.id);
                      }}
                      className={`min-h-[36px] px-3 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 flex items-center gap-1.5 transition ${
                        selected
                          ? 'bg-sky-500 text-white shadow-sm'
                          : 'liquid-glass-subtle text-slate-800 dark:text-slate-100'
                      }`}
                    >
                      <MapPin className="h-3 w-3 shrink-0" />
                      <span>{city.name}</span>
                      <span className="opacity-70 font-normal">({city.country})</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Highlighted Stop OR Clicked City Quick Card */}
        {highlightedStop && (
          <div className="liquid-glass-subtle rounded-2xl p-3.5 flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="text-xs font-extrabold text-violet-600 dark:text-violet-300">
                Étape #{highlightedStop.stepNumber} ·{' '}
                {formatShortDate(highlightedStop.item.dayOffset)}
                {highlightedStop.distanceKm !== null && highlightedStop.distanceKm > 0
                  ? ` · +${formatCompactNumber(highlightedStop.distanceKm)} km`
                  : ''}
              </div>
              <div className="text-sm font-extrabold text-slate-900 dark:text-white">
                {highlightedStop.item.venueName} — {highlightedStop.item.city},{' '}
                {highlightedStop.item.country}
              </div>
              <div className="text-xs font-mono text-slate-500 dark:text-slate-400">
                Billet {formatCurrency(highlightedStop.item.ticketPrice)} ·{' '}
                {formatCompactNumber(highlightedStop.item.ticketsSold)}/
                {formatCompactNumber(highlightedStop.item.capacity)} pl.
              </div>
            </div>
            {highlightedStop.item.status !== 'played' && (
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => onPlayDate(highlightedStop.item.id)}
                  className="min-h-[40px] px-4 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 text-xs font-extrabold flex items-center gap-1.5"
                >
                  <Mic className="h-3.5 w-3.5" />
                  <span>Jouer cette étape</span>
                </button>
                <button
                  type="button"
                  aria-label="Retirer cette étape"
                  onClick={() => {
                    onRemoveDate(highlightedStop.item.id);
                    setHighlightedDateId(null);
                  }}
                  className="min-h-[40px] w-10 rounded-xl liquid-glass text-rose-500 flex items-center justify-center"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            )}
          </div>
        )}

        {inspectedCityData && (
          <div className="liquid-glass-subtle rounded-2xl p-3.5 space-y-2.5">
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="flex items-center gap-1.5 text-xs font-extrabold text-slate-900 dark:text-white">
                  <MapPin className="h-3.5 w-3.5 text-sky-500" />
                  <span>
                    {inspectedCityData.city.name}, {inspectedCityData.city.country}
                  </span>
                  <span className="text-[11px] font-semibold text-sky-600 dark:text-sky-300">
                    · {inspectedCityData.city.continent}
                  </span>
                </div>
                <div className="text-[11px] font-mono text-slate-500 mt-0.5">
                  ID {inspectedCityData.city.id} ·{' '}
                  {inspectedCityData.city.lat.toFixed(2)}°,{' '}
                  {inspectedCityData.city.lng.toFixed(2)}°
                </div>
              </div>
              <button
                type="button"
                onClick={() => setInspectedCityId(null)}
                className="text-xs font-bold text-slate-500"
              >
                Fermer
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {inspectedCityData.venues.map((v) => (
                <button
                  key={v.id}
                  type="button"
                  onClick={() => {
                    soundEngine.playSuccessChord();
                    onSelectVenueForAdd(v.id);
                  }}
                  className="liquid-glass rounded-xl p-2.5 text-left flex items-center justify-between gap-2 hover:scale-[1.01] transition"
                >
                  <div className="min-w-0">
                    <div className="text-xs font-extrabold text-slate-900 dark:text-white truncate">
                      {v.name}
                    </div>
                    <div className="text-[11px] font-mono text-slate-500">
                      {formatCompactNumber(v.capacity)} pl. · ~{formatCurrency(v.recommendedPrice)}
                    </div>
                  </div>
                  <span className="h-8 w-8 rounded-lg bg-violet-600 text-white flex items-center justify-center shrink-0">
                    <Plus className="h-4 w-4" />
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* Right: Interactive Drag-and-Drop Itinerary Reordering */}
      <section className="lg:col-span-5 liquid-glass rounded-3xl p-4 sm:p-5 space-y-3.5">
        <div className="flex items-start justify-between gap-2">
          <div>
            <div className="flex items-center gap-1.5 text-sm font-extrabold text-slate-900 dark:text-white">
              <Route className="h-4 w-4 text-violet-500" />
              <span>Ordre & Glisser-Déposer</span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Maintiens la poignée pour réorganiser l’itinéraire sur la carte et recalculer distances et créneaux.
            </p>
          </div>
          <Compass className="h-4 w-4 text-sky-500 shrink-0 mt-0.5" />
        </div>

        {routeStops.length === 0 ? (
          <div className="liquid-glass-subtle rounded-2xl p-6 text-center space-y-2">
            <MapPin className="h-7 w-7 text-slate-400 mx-auto" />
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Clique sur une ville de la carte ou utilise la recherche par ville/pays pour tracer ton itinéraire.
            </p>
          </div>
        ) : (
          <div className="space-y-2.5 max-h-[480px] overflow-y-auto pr-1">
            {/* Locked Played Stops */}
            {playedStops.map((stop) => (
              <div
                key={stop.item.id}
                onMouseEnter={() => setHighlightedDateId(stop.item.id)}
                onMouseLeave={() => setHighlightedDateId(null)}
                className="liquid-glass-subtle rounded-2xl p-3 opacity-80 flex items-center gap-2.5"
              >
                <div className="h-7 w-7 rounded-full bg-emerald-500 text-white text-xs font-extrabold font-mono flex items-center justify-center shrink-0">
                  {stop.stepNumber}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-[11px] font-mono text-emerald-600 dark:text-emerald-300 font-bold">
                    Joué · {formatShortDate(stop.item.dayOffset)} · {stop.item.city}
                    {stop.distanceKm !== null && stop.distanceKm > 0
                      ? ` · ${formatCompactNumber(stop.distanceKm)} km`
                      : ''}
                  </div>
                  <div className="text-xs font-extrabold text-slate-900 dark:text-white truncate">
                    {stop.item.venueName}
                  </div>
                </div>
              </div>
            ))}

            {/* Draggable Unplayed Stops */}
            {unplayedStops.length > 0 && (
              <Reorder.Group
                axis="y"
                values={unplayedIds}
                onReorder={(newOrder) => {
                  onReorderUnplayed(newOrder);
                }}
                className="space-y-2"
              >
                {unplayedStops.map((stop) => (
                  <DraggableStopRow
                    key={stop.item.id}
                    item={stop.item}
                    stepNumber={stop.stepNumber}
                    isHighlighted={highlightedDateId === stop.item.id}
                    distanceFromPrevKm={stop.distanceKm}
                    onHighlight={setHighlightedDateId}
                    onPlayDate={onPlayDate}
                    onRemoveDate={onRemoveDate}
                  />
                ))}
              </Reorder.Group>
            )}
          </div>
        )}
      </section>
    </div>
  );
};
