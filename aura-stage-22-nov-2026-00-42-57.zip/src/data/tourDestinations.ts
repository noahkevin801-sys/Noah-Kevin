import { TourCityDestination, TourContinent } from '../types/game';

export interface ContinentRegionMeta {
  id: TourContinent;
  label: string;
  mapFocusRegion: 'europe' | 'americas' | 'asia' | 'oceania' | 'world';
}

/**
 * Extensible registry of continents/regions for international touring.
 * Adding a new region in future phases only requires appending an entry here
 * and adding matching cities to TOUR_DESTINATIONS.
 */
export const TOUR_CONTINENTS: ContinentRegionMeta[] = [
  { id: 'Europe', label: 'Europe', mapFocusRegion: 'europe' },
  { id: 'Amérique du Nord', label: 'Amérique du Nord', mapFocusRegion: 'americas' },
  { id: 'Asie', label: 'Asie', mapFocusRegion: 'asia' },
  { id: 'Océanie', label: 'Océanie', mapFocusRegion: 'oceania' },
];

/**
 * Phase 1 international city destinations catalog.
 * Each city has a unique ID, official name, country, continent, and WGS84 coordinates.
 */
export const TOUR_DESTINATIONS: TourCityDestination[] = [
  // Europe (existing French & European cities + Phase 1 expansions)
  {
    id: 'city_lyon',
    name: 'Lyon',
    country: 'France',
    countryCode: 'FR',
    continent: 'Europe',
    lat: 45.764,
    lng: 4.8357,
    region: 'france',
  },
  {
    id: 'city_paris',
    name: 'Paris',
    country: 'France',
    countryCode: 'FR',
    continent: 'Europe',
    lat: 48.8566,
    lng: 2.3522,
    region: 'france',
  },
  {
    id: 'city_marseille',
    name: 'Marseille',
    country: 'France',
    countryCode: 'FR',
    continent: 'Europe',
    lat: 43.2965,
    lng: 5.3698,
    region: 'france',
  },
  {
    id: 'city_bordeaux',
    name: 'Bordeaux',
    country: 'France',
    countryCode: 'FR',
    continent: 'Europe',
    lat: 44.8378,
    lng: -0.5792,
    region: 'france',
  },
  {
    id: 'city_saint_denis',
    name: 'Saint-Denis',
    country: 'France',
    countryCode: 'FR',
    continent: 'Europe',
    lat: 48.9244,
    lng: 2.3601,
    region: 'france',
  },
  {
    id: 'city_brussels',
    name: 'Bruxelles',
    country: 'Belgique',
    countryCode: 'BE',
    continent: 'Europe',
    lat: 50.8503,
    lng: 4.3517,
    region: 'europe',
  },
  {
    id: 'city_manchester',
    name: 'Manchester',
    country: 'Royaume-Uni',
    countryCode: 'GB',
    continent: 'Europe',
    lat: 53.4808,
    lng: -2.2426,
    region: 'europe',
  },
  {
    id: 'city_london',
    name: 'Londres',
    country: 'Royaume-Uni',
    countryCode: 'GB',
    continent: 'Europe',
    lat: 51.5072,
    lng: -0.1276,
    region: 'europe',
  },
  {
    id: 'city_berlin',
    name: 'Berlin',
    country: 'Allemagne',
    countryCode: 'DE',
    continent: 'Europe',
    lat: 52.52,
    lng: 13.405,
    region: 'europe',
  },
  {
    id: 'city_madrid',
    name: 'Madrid',
    country: 'Espagne',
    countryCode: 'ES',
    continent: 'Europe',
    lat: 40.4168,
    lng: -3.7038,
    region: 'europe',
  },
  {
    id: 'city_amsterdam',
    name: 'Amsterdam',
    country: 'Pays-Bas',
    countryCode: 'NL',
    continent: 'Europe',
    lat: 52.3676,
    lng: 4.9041,
    region: 'europe',
  },
  {
    id: 'city_milan',
    name: 'Milan',
    country: 'Italie',
    countryCode: 'IT',
    continent: 'Europe',
    lat: 45.4642,
    lng: 9.19,
    region: 'europe',
  },
  {
    id: 'city_lisbon',
    name: 'Lisbonne',
    country: 'Portugal',
    countryCode: 'PT',
    continent: 'Europe',
    lat: 38.7223,
    lng: -9.1393,
    region: 'europe',
  },

  // États-Unis (Amérique du Nord)
  {
    id: 'city_new_york',
    name: 'New York',
    country: 'États-Unis',
    countryCode: 'US',
    continent: 'Amérique du Nord',
    lat: 40.7128,
    lng: -74.006,
    region: 'monde',
  },
  {
    id: 'city_los_angeles',
    name: 'Los Angeles',
    country: 'États-Unis',
    countryCode: 'US',
    continent: 'Amérique du Nord',
    lat: 34.0522,
    lng: -118.2437,
    region: 'monde',
  },
  {
    id: 'city_chicago',
    name: 'Chicago',
    country: 'États-Unis',
    countryCode: 'US',
    continent: 'Amérique du Nord',
    lat: 41.8781,
    lng: -87.6298,
    region: 'monde',
  },
  {
    id: 'city_miami',
    name: 'Miami',
    country: 'États-Unis',
    countryCode: 'US',
    continent: 'Amérique du Nord',
    lat: 25.7617,
    lng: -80.1918,
    region: 'monde',
  },
  {
    id: 'city_atlanta',
    name: 'Atlanta',
    country: 'États-Unis',
    countryCode: 'US',
    continent: 'Amérique du Nord',
    lat: 33.749,
    lng: -84.388,
    region: 'monde',
  },

  // Canada (Amérique du Nord)
  {
    id: 'city_montreal',
    name: 'Montréal',
    country: 'Canada',
    countryCode: 'CA',
    continent: 'Amérique du Nord',
    lat: 45.5017,
    lng: -73.5673,
    region: 'monde',
  },
  {
    id: 'city_toronto',
    name: 'Toronto',
    country: 'Canada',
    countryCode: 'CA',
    continent: 'Amérique du Nord',
    lat: 43.6532,
    lng: -79.3832,
    region: 'monde',
  },
  {
    id: 'city_vancouver',
    name: 'Vancouver',
    country: 'Canada',
    countryCode: 'CA',
    continent: 'Amérique du Nord',
    lat: 49.2827,
    lng: -123.1207,
    region: 'monde',
  },

  // Asie
  {
    id: 'city_tokyo',
    name: 'Tokyo',
    country: 'Japon',
    countryCode: 'JP',
    continent: 'Asie',
    lat: 35.6762,
    lng: 139.6503,
    region: 'monde',
  },
  {
    id: 'city_seoul',
    name: 'Séoul',
    country: 'Corée du Sud',
    countryCode: 'KR',
    continent: 'Asie',
    lat: 37.5665,
    lng: 126.978,
    region: 'monde',
  },
  {
    id: 'city_singapore',
    name: 'Singapour',
    country: 'Singapour',
    countryCode: 'SG',
    continent: 'Asie',
    lat: 1.3521,
    lng: 103.8198,
    region: 'monde',
  },
  {
    id: 'city_bangkok',
    name: 'Bangkok',
    country: 'Thaïlande',
    countryCode: 'TH',
    continent: 'Asie',
    lat: 13.7563,
    lng: 100.5018,
    region: 'monde',
  },

  // Océanie
  {
    id: 'city_sydney',
    name: 'Sydney',
    country: 'Australie',
    countryCode: 'AU',
    continent: 'Océanie',
    lat: -33.8688,
    lng: 151.2093,
    region: 'monde',
  },
  {
    id: 'city_melbourne',
    name: 'Melbourne',
    country: 'Australie',
    countryCode: 'AU',
    continent: 'Océanie',
    lat: -37.8136,
    lng: 144.9631,
    region: 'monde',
  },
  {
    id: 'city_auckland',
    name: 'Auckland',
    country: 'Nouvelle-Zélande',
    countryCode: 'NZ',
    continent: 'Océanie',
    lat: -36.8485,
    lng: 174.7633,
    region: 'monde',
  },
];

export const TOUR_DESTINATIONS_BY_ID: Record<string, TourCityDestination> =
  Object.fromEntries(TOUR_DESTINATIONS.map((city) => [city.id, city]));

export function haversineDistanceKm(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  return Math.round(R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
}

export function getDestinationForCityName(
  cityName: string,
  countryName?: string
): TourCityDestination | undefined {
  const normCity = cityName.trim().toLowerCase();
  const normCountry = countryName?.trim().toLowerCase();
  return TOUR_DESTINATIONS.find(
    (d) =>
      d.name.toLowerCase() === normCity &&
      (!normCountry || d.country.toLowerCase() === normCountry)
  );
}
