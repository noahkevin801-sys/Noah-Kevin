import {
  EventChoice,
  GameState,
  RandomEvent,
} from '../types/game';
import { RIVAL_ARTISTS } from '../data/gameData';

interface EventTemplate {
  id: string;
  cooldownWeeks: number;
  isEligible: (state: GameState) => boolean;
  weight: (state: GameState) => number;
  build: (state: GameState) => RandomEvent;
}

function pickRandom<T>(items: T[]): T {
  return items[Math.floor(Math.random() * items.length)];
}

function getLatestReleasedSong(state: GameState) {
  const released = state.songs.filter((s) => s.released);
  if (released.length === 0) return null;
  return released[0];
}

const EVENT_TEMPLATES: EventTemplate[] = [
  {
    id: 'collab_famous_artist',
    cooldownWeeks: 10,
    isEligible: (state) => state.artist.fans >= 800,
    weight: (state) => (state.artist.hype >= 35 ? 18 : 12),
    build: (state) => {
      const rival = pickRandom(RIVAL_ARTISTS);
      const studioFee = Math.max(800, Math.round(state.artist.fans * 0.04));
      const cappedFee = Math.min(studioFee, 18000);
      const songTitle = `${rival.titles[0]} (Remix)`;

      return {
        id: `evt_${state.artist.weeksActive}_collab`,
        templateId: 'collab_famous_artist',
        week: state.artist.weeksActive,
        title: `Collaboration avec ${rival.name}`,
        description: `${rival.name} a écouté tes derniers morceaux et te propose d’enregistrer un duo surprise dès cette semaine. Une occasion rare de toucher un tout nouveau public.`,
        category: 'collaboration',
        sentiment: 'positive',
        contextSubject: rival.name,
        choices: [
          {
            id: 'accept_vip',
            label: 'Enregistrer le duo en studio',
            summary: `Coût ${cappedFee.toLocaleString('fr-FR')} € · -15 Énergie · Sortie immédiate`,
            costCash: cappedFee,
            costEnergy: 15,
            outcomeText: `La session avec ${rival.name} a créé une alchimie immédiate. Le titre « ${songTitle} » propulse ta notoriété.`,
            sentimentResult: 'positive',
            delta: {
              fans: Math.round(1400 + state.artist.fans * 0.16),
              hype: 22,
              reputation: 6,
              autoReleaseCollabTitle: `${songTitle} (feat. ${rival.name})`,
            },
          },
          {
            id: 'accept_feature_verse',
            label: 'Envoyer un couplet à distance',
            summary: 'Gratuit · -8 Énergie · Gain modéré',
            costEnergy: 8,
            outcomeText: `Tu enregistres ta partie depuis ton Q.G. ${rival.name} partage l’extrait sur ses réseaux.`,
            sentimentResult: 'positive',
            delta: {
              fans: Math.round(550 + state.artist.fans * 0.06),
              hype: 10,
              skillBoost: { writing: 2 },
            },
          },
          {
            id: 'decline_focus',
            label: 'Décliner pour rester en solo',
            summary: 'Aucun coût · +Réputation artistique',
            outcomeText: `Tu préfères garder le cap sur ton projet personnel. Les puristes saluent ton intégrité.`,
            sentimentResult: 'neutral',
            delta: {
              reputation: 8,
              skillBoost: { vocals: 2 },
            },
          },
        ],
      };
    },
  },
  {
    id: 'tour_logistical_crisis',
    cooldownWeeks: 8,
    isEligible: (state) => state.artist.concertsPlayed >= 1 || state.artist.fans >= 1500,
    weight: (state) => (state.artist.concertsPlayed >= 2 ? 16 : 9),
    build: (state) => {
      const emergencyCost = Math.max(450, Math.min(12000, Math.round(state.artist.cash * 0.18)));
      return {
        id: `evt_${state.artist.weeksActive}_tour`,
        templateId: 'tour_logistical_crisis',
        week: state.artist.weeksActive,
        title: 'Imprévu technique en tournée',
        description:
          'Le van transportant tes retours scène et ton matériel d’éclairage est tombé en panne sur l’autoroute à quatre heures de l’ouverture des portes.',
        category: 'tour',
        sentiment: 'negative',
        choices: [
          {
            id: 'rent_backup',
            label: 'Louer du matériel en urgence',
            summary: `Coût ${emergencyCost.toLocaleString('fr-FR')} € · Sauve le show`,
            costCash: emergencyCost,
            costEnergy: 10,
            outcomeText:
              'Le prestataire local installe tout à temps. Le public ne s’est douté de rien et salue ton professionnalisme.',
            sentimentResult: 'positive',
            delta: {
              hype: 8,
              reputation: 7,
              fans: Math.round(180 + state.artist.fans * 0.03),
            },
          },
          {
            id: 'unplugged_set',
            label: 'Improviser une session acoustique',
            summary: '-14 Énergie · +Scène · Coût nul',
            costEnergy: 14,
            outcomeText:
              'Sans artifice, tu tiens la salle par ta seule présence vocale. Quelques fans sont surpris, mais le moment devient culte.',
            sentimentResult: 'neutral',
            delta: {
              hype: 5,
              reputation: 4,
              skillBoost: { stage: 3, vocals: 2 },
            },
          },
          {
            id: 'cancel_show',
            label: 'Reporter et dédommager la salle',
            summary: 'Perte de hype et de fans',
            outcomeText:
              'L’annonce de dernière minute déçoit les spectateurs qui avaient fait le déplacement.',
            sentimentResult: 'negative',
            delta: {
              hype: -12,
              reputation: -8,
              fans: -Math.min(Math.round(state.artist.fans * 0.04), 1200),
            },
          },
        ],
      };
    },
  },
  {
    id: 'viral_album_review',
    cooldownWeeks: 7,
    isEligible: (state) => getLatestReleasedSong(state) !== null,
    weight: () => 18,
    build: (state) => {
      const targetSong = getLatestReleasedSong(state)!;
      const isAcclaimed = targetSong.quality >= 64;

      if (isAcclaimed) {
        return {
          id: `evt_${state.artist.weeksActive}_review_pos`,
          templateId: 'viral_album_review',
          week: state.artist.weeksActive,
          title: 'Critique musicale virale',
          description: `Un vidéaste musical très suivi vient de publier une analyse passionnée de « ${targetSong.title} », saluant la finesse du mix et l’émotion du refrain.`,
          category: 'press',
          sentiment: 'positive',
          contextSubject: targetSong.title,
          choices: [
            {
              id: 'share_interview',
              label: 'Partager et proposer un décryptage live',
              summary: '-10 Énergie · Boost massif des écoutes',
              costEnergy: 10,
              outcomeText: `Ton passage en direct avec le critique déclenche une vague de nouveaux auditeurs sur « ${targetSong.title} ».`,
              sentimentResult: 'positive',
              delta: {
                hype: 18,
                fans: Math.round(900 + state.artist.fans * 0.14),
                activeTrackStreamMultiplier: 1.65,
              },
            },
            {
              id: 'thank_quietly',
              label: 'Remercier sobrement en ligne',
              summary: 'Aucun coût · Effet organique durable',
              outcomeText:
                'Ta retenue renforce ton image d’artiste exigeant et authentique.',
              sentimentResult: 'positive',
              delta: {
                hype: 9,
                reputation: 7,
                fans: Math.round(450 + state.artist.fans * 0.07),
                activeTrackStreamMultiplier: 1.3,
              },
            },
          ],
        };
      }

      return {
        id: `evt_${state.artist.weeksActive}_review_neg`,
        templateId: 'viral_album_review',
        week: state.artist.weeksActive,
        title: 'Critique virale mitigée',
        description: `Une chronique très partagée épingle la production de « ${targetSong.title} », jugée trop sage par rapport aux attentes du moment.`,
        category: 'press',
        sentiment: 'dilemma',
        contextSubject: targetSong.title,
        choices: [
          {
            id: 'respond_wit',
            label: 'Répondre avec autodérision',
            summary: 'Transforme le débat en viralité',
            outcomeText:
              'Ta réponse pleine d’esprit fait sourire les réseaux et attire des curieux venus écouter le titre.',
            sentimentResult: 'positive',
            delta: {
              hype: 10,
              fans: Math.round(250 + state.artist.fans * 0.04),
              activeTrackStreamMultiplier: 1.2,
            },
          },
          {
            id: 'back_to_lab',
            label: 'S’enfermer en studio pour progresser',
            summary: '-16 Énergie · +4 Production',
            costEnergy: 16,
            outcomeText:
              'Tu encaisses la critique avec maturité et retravailles tes textures sonores toute la nuit.',
            sentimentResult: 'neutral',
            delta: {
              reputation: 6,
              skillBoost: { production: 4, writing: 2 },
            },
          },
          {
            id: 'ignore_review',
            label: 'Ignorer la polémique',
            summary: 'Préserve ton énergie',
            outcomeText:
              'Le bruit retombe après quelques jours, mais l’élan du single ralentit légèrement.',
            sentimentResult: 'negative',
            delta: {
              hype: -6,
            },
          },
        ],
      };
    },
  },
  {
    id: 'streaming_sync_offer',
    cooldownWeeks: 12,
    isEligible: (state) => getLatestReleasedSong(state) !== null && state.artist.fans >= 1200,
    weight: () => 12,
    build: (state) => {
      const song = getLatestReleasedSong(state)!;
      const syncPayout = Math.round(2500 + Math.min(45000, state.artist.fans * 0.12));
      return {
        id: `evt_${state.artist.weeksActive}_sync`,
        templateId: 'streaming_sync_offer',
        week: state.artist.weeksActive,
        title: 'Synchronisation Série Internationale',
        description: `La supervision musicale d’une série événement souhaite intégrer « ${song.title} » dans le final de la saison.`,
        category: 'industry',
        sentiment: 'positive',
        contextSubject: song.title,
        choices: [
          {
            id: 'sign_sync',
            label: 'Céder la licence de diffusion',
            summary: `+${syncPayout.toLocaleString('fr-FR')} € · +Streams mondiaux`,
            outcomeText: `Dès la diffusion de l’épisode, « ${song.title} » grimpe dans les recherches musicales.`,
            sentimentResult: 'positive',
            delta: {
              cash: syncPayout,
              fans: Math.round(800 + state.artist.fans * 0.12),
              hype: 15,
              activeTrackStreamMultiplier: 1.7,
            },
          },
          {
            id: 'negotiate_exclusivity',
            label: 'Négocier une version acoustique dédiée',
            summary: `-12 Énergie · Bonus prestige + cachet`,
            costEnergy: 12,
            outcomeText:
              'La production adore ton arrangement sur mesure et te crédite dans le générique officiel.',
            sentimentResult: 'positive',
            delta: {
              cash: Math.round(syncPayout * 1.25),
              reputation: 9,
              hype: 18,
              fans: Math.round(1100 + state.artist.fans * 0.14),
            },
          },
        ],
      };
    },
  },
  {
    id: 'festival_headliner_slot',
    cooldownWeeks: 11,
    isEligible: (state) => state.artist.fans >= 4000,
    weight: () => 11,
    build: (state) => {
      const fee = Math.round(1800 + Math.min(35000, state.artist.fans * 0.08));
      return {
        id: `evt_${state.artist.weeksActive}_fest`,
        templateId: 'festival_headliner_slot',
        week: state.artist.weeksActive,
        title: 'Remplacement de dernière minute en festival',
        description:
          'Un artiste programmé sur la grande scène d’un festival d’été vient de se désister. L’organisation te propose le créneau de 22h30.',
        category: 'tour',
        sentiment: 'dilemma',
        choices: [
          {
            id: 'play_festival',
            label: 'Monter sur scène ce soir',
            summary: `-25 Énergie · +${fee.toLocaleString('fr-FR')} € · Foule massive`,
            costEnergy: 25,
            outcomeText:
              'Devant des milliers de festivaliers conquis, tu livres l’une des performances les plus marquantes de ta carrière.',
            sentimentResult: 'positive',
            delta: {
              cash: fee,
              fans: Math.round(1500 + state.artist.fans * 0.15),
              hype: 20,
              skillBoost: { stage: 4 },
            },
          },
          {
            id: 'decline_rest',
            label: 'Décliner par manque de préparation',
            summary: 'Préserve ton énergie et ta voix',
            outcomeText:
              'Tu préfères attendre de pouvoir proposer une scénographie à la hauteur de tes ambitions.',
            sentimentResult: 'neutral',
            delta: {
              energy: 10,
            },
          },
        ],
      };
    },
  },
  {
    id: 'demo_leak_incident',
    cooldownWeeks: 12,
    isEligible: (state) => state.songs.some((s) => !s.released) || state.songs.length >= 1,
    weight: () => 10,
    build: (state) => {
      return {
        id: `evt_${state.artist.weeksActive}_leak`,
        templateId: 'demo_leak_incident',
        week: state.artist.weeksActive,
        title: 'Fuite d’un extrait sur les réseaux',
        description:
          'Une maquette enregistrée il y a quelques semaines vient d’apparaître sur des forums de fans et cumule déjà des milliers de partages.',
        category: 'viral',
        sentiment: 'dilemma',
        choices: [
          {
            id: 'embrace_leak',
            label: 'Surfer sur l’engouement officiel',
            summary: '+Hype immédiate · Risque de mix imparfait',
            outcomeText:
              'Tu publies un extrait propre dans la foulée pour canaliser l’attention vers tes canaux officiels.',
            sentimentResult: 'positive',
            delta: {
              hype: 14,
              fans: Math.round(500 + state.artist.fans * 0.08),
              reputation: -2,
            },
          },
          {
            id: 'lock_and_polish',
            label: 'Retirer la fuite et perfectionner le master',
            summary: '-600 € frais juridiques · +Qualité studio',
            costCash: Math.min(600, Math.max(0, state.artist.cash)),
            outcomeText:
              'Ton équipe fait retirer les liens et tu profites du mystère pour soigner ton prochain rendu.',
            sentimentResult: 'neutral',
            delta: {
              reputation: 6,
              skillBoost: { production: 3 },
            },
          },
        ],
      };
    },
  },
  {
    id: 'luxury_brand_deal',
    cooldownWeeks: 14,
    isEligible: (state) => state.artist.fans >= 10_000,
    weight: () => 10,
    build: (state) => {
      const payout = Math.round(4500 + Math.min(60000, state.artist.fans * 0.09));
      return {
        id: `evt_${state.artist.weeksActive}_brand`,
        templateId: 'luxury_brand_deal',
        week: state.artist.weeksActive,
        title: 'Campagne Maison Audio & Mode',
        description:
          'Une maison de design acoustique souhaite associer ton image à son nouveau casque en verre et aluminium brossé.',
        category: 'industry',
        sentiment: 'dilemma',
        choices: [
          {
            id: 'accept_ambassador',
            label: 'Signer le contrat d’image',
            summary: `+${payout.toLocaleString('fr-FR')} € · -10 Énergie · Exposition`,
            costEnergy: 10,
            outcomeText:
              'La campagne s’affiche dans toutes les grandes villes et renforce solidement ta trésorerie.',
            sentimentResult: 'positive',
            delta: {
              cash: payout,
              hype: 10,
              reputation: -2,
            },
          },
          {
            id: 'refuse_commercial',
            label: 'Refuser pour préserver ton aura artistique',
            summary: '+10 Réputation · Soutien des fans fidèles',
            outcomeText:
              'Ton public apprécie que tu places la musique avant les partenariats commerciaux.',
            sentimentResult: 'positive',
            delta: {
              reputation: 10,
              fans: Math.round(350 + state.artist.fans * 0.04),
            },
          },
        ],
      };
    },
  },
  {
    id: 'vocal_strain_warning',
    cooldownWeeks: 9,
    isEligible: (state) => state.artist.energy < 45,
    weight: () => 18,
    build: (state) => ({
      id: `evt_${state.artist.weeksActive}_health`,
      templateId: 'vocal_strain_warning',
      week: state.artist.weeksActive,
      title: 'Fatigue vocale détectée',
      description:
        'Après plusieurs semaines intenses entre studio et déplacements, ta voix montre de sérieux signes de fatigue avant les prochaines échéances.',
      category: 'health',
      sentiment: 'negative',
      choices: [
        {
          id: 'specialist_care',
          label: 'Consulter un phoniatre spécialisé',
          summary: 'Coût 500 € · Restaure +35 Énergie',
          costCash: Math.min(500, Math.max(0, state.artist.cash)),
          outcomeText:
            'Des exercices ciblés et du repos te permettent de retrouver toute ta clarté vocale.',
          sentimentResult: 'positive',
          delta: {
            energy: 35,
            skillBoost: { vocals: 2 },
          },
        },
        {
          id: 'push_through',
          label: 'Forcer et continuer le rythme',
          summary: 'Aucun coût · Risque sur la qualité vocale',
          outcomeText:
            'Tu tiens bon sur le fil, mais ta fatigue se ressent dans tes performances de la semaine.',
          sentimentResult: 'negative',
          delta: {
            energy: -10,
            hype: -5,
            reputation: -3,
          },
        },
      ],
    }),
  },
  {
    id: 'morning_radio_trap',
    cooldownWeeks: 9,
    isEligible: (state) => state.artist.hype >= 20,
    weight: () => 11,
    build: (state) => ({
      id: `evt_${state.artist.weeksActive}_radio`,
      templateId: 'morning_radio_trap',
      week: state.artist.weeksActive,
      title: 'Matinale radio sous haute tension',
      description:
        'En direct devant des centaines de milliers d’auditeurs, l’animateur te lance une question piquante sur la concurrence dans les classements.',
      category: 'press',
      sentiment: 'dilemma',
      choices: [
        {
          id: 'bold_punchline',
          label: 'Assumer une ambition sans filtre',
          summary: '+Hype · +Fans · Légère controverse',
          outcomeText:
            'Ta séquence fait le tour des extraits radio de la journée et déclenche un pic d’attention.',
          sentimentResult: 'positive',
          delta: {
            hype: 15,
            fans: Math.round(400 + state.artist.fans * 0.06),
            reputation: -3,
          },
        },
        {
          id: 'diplomatic_class',
          label: 'Saluer le travail des autres artistes',
          summary: '+Réputation · +Écoutes calmes',
          outcomeText:
            'L’industrie et les programmateurs apprécient ta classe et ton professionnalisme.',
          sentimentResult: 'positive',
          delta: {
            reputation: 8,
            hype: 5,
            fans: Math.round(200 + state.artist.fans * 0.03),
          },
        },
      ],
    }),
  },
];

export function maybeTriggerRandomEvent(state: GameState): RandomEvent | null {
  const weeksSinceLast = state.artist.weeksActive - state.lastEventWeek;
  // Minimum 2 weeks between events, guaranteed by week 5 without event
  if (weeksSinceLast < 2) return null;

  const triggerChance = weeksSinceLast >= 4 ? 0.85 : weeksSinceLast === 3 ? 0.55 : 0.35;
  if (Math.random() > triggerChance) return null;

  const eligible = EVENT_TEMPLATES.filter((tpl) => {
    const blockedUntil = state.cooldownEventTemplates[tpl.id] ?? 0;
    return state.artist.weeksActive >= blockedUntil && tpl.isEligible(state);
  });

  if (eligible.length === 0) return null;

  const totalWeight = eligible.reduce((sum, tpl) => sum + tpl.weight(state), 0);
  let roll = Math.random() * totalWeight;
  for (const tpl of eligible) {
    roll -= tpl.weight(state);
    if (roll <= 0) {
      return tpl.build(state);
    }
  }
  return eligible[0].build(state);
}

export function getEventCooldown(templateId: string): number {
  const tpl = EVENT_TEMPLATES.find((t) => t.id === templateId);
  return tpl?.cooldownWeeks ?? 8;
}

export function canAffordEventChoice(state: GameState, choice: EventChoice): boolean {
  if (choice.costCash && state.artist.cash < choice.costCash) return false;
  if (choice.costEnergy && state.artist.energy < choice.costEnergy) return false;
  if (choice.requiresMinFans && state.artist.fans < choice.requiresMinFans) return false;
  return true;
}
