import { GameState } from '../types/game';
import { SharedComment, SharedSocialPost, SocialPlatform } from '../types/network';
import { COVER_TONES, RIVAL_ARTISTS } from '../data/gameData';
import { formatCompactNumber } from '../utils/format';

export function generateOfflineAiChatReply(
  contactId: string,
  userMessage: string,
  state: GameState
): string {
  const { artist, songs, charts } = state;
  const released = songs.filter((s) => s.released);
  const topSong = [...released].sort((a, b) => b.totalStreams - a.totalStreams)[0];
  const bestChart = charts.find((c) => c.isPlayer);
  const msg = userMessage.toLowerCase();

  if (contactId === 'room_global' || contactId === 'room_collab' || contactId === 'room_promo') {
    const rival = RIVAL_ARTISTS[Math.floor(Math.random() * RIVAL_ARTISTS.length)];
    if (msg.includes('feat') || msg.includes('collab') || msg.includes('studio')) {
      return `[IA Hors-ligne · ${rival.name}] Toujours chaud pour bosser sur un son ${artist.genre.toUpperCase()} ! Continue d'enregistrer dans Music et envoie ton extrait sur AllCloud.`;
    }
    if (msg.includes('stream') || msg.includes('chart') || msg.includes('top')) {
      return bestChart
        ? `[IA Hors-ligne · ${rival.name}] J'ai vu « ${bestChart.title} » classé N°${bestChart.rank} dans les Charts, gros respect !`
        : `[IA Hors-ligne · ${rival.name}] Poste tes morceaux sur AllTok avec un extrait vidéo, ça fait exploser les écoutes Alltify !`;
    }
    return `[IA Hors-ligne · ${rival.name}] Salut ${artist.stageName} ! En mode hors-ligne, l'IA simule le réseau des artistes pour que ta carrière continue sans coupure.`;
  }

  if (contactId === 'contact_manager') {
    if (released.length === 0) {
      return `Mode IA Hors-ligne : Enregistre et publie ton premier single dans Music pour lancer tes écoutes Alltify et apparaître sur AllPress.`;
    }
    if (msg.includes('argent') || msg.includes('budget') || msg.includes('euro')) {
      return `Ton solde est à ${artist.cash.toLocaleString('fr-FR')} €. Active des dates dans Tournées ou vends du merch pour sécuriser tes prochains clips.`;
    }
    if (msg.includes('clip') || msg.includes('promo') || msg.includes('viral')) {
      return topSong
        ? `« ${topSong.title} » tourne bien (${formatCompactNumber(topSong.totalStreams)} écoutes). Poste un challenge AllTok et un thread AllX pour doubler sa portée !`
        : `Publie régulièrement sur AllGram et AllTok pour garder ta Popularité (${artist.hype}/100) au maximum.`;
    }
    return `Analyse IA : ${formatCompactNumber(artist.monthlyListeners)} auditeurs/mois, Réputation ${artist.reputation}/100. Vise un Album dès que tu as 7 titres prêts !`;
  }

  if (contactId === 'contact_kaelen' || contactId === 'contact_naya') {
    const name = contactId === 'contact_kaelen' ? 'Kaelen' : 'Naya';
    if (artist.fame >= 35 || artist.fans >= 15_000) {
      return `${name} (IA) : Ton projet commence à faire du bruit partout sur AllX et AllGram. Dès qu'on croise nos plannings studio, on pose un featuring.`;
    }
    return `${name} (IA) : Force à toi ${artist.stageName} ! Continue de charbonner en studio et sur AllCloud, la constance paye toujours.`;
  }

  if (contactId === 'contact_starfeed') {
    return topSong
      ? `AllPress / StarFeed (IA) : Notre rédaction suit « ${topSong.title} » (${formatCompactNumber(topSong.totalStreams)} streams). Continue tes sorties pour décrocher une note 9/10 !`
      : `AllPress / StarFeed (IA) : Préviens-nous dès la sortie de ton premier EP ou Single pour figurer dans la revue de presse.`;
  }

  return `Communauté Fans (IA) : On est déjà ${formatCompactNumber(artist.fans)} derrière toi ${artist.stageName} ! Balance un extrait sur AllTok ce soir !`;
}

export function generateOfflineAiCommentsForPost(
  post: SharedSocialPost,
  artistName: string
): SharedComment[] {
  const handles = [
    { name: 'Rédaction AllPress', handle: '@allpress_fr' },
    { name: 'Léna Moreau', handle: '@lenamoreau' },
    { name: 'Kaelen', handle: '@kaelen_93' },
    { name: 'Fan Club Officiel', handle: '@allstarz_fans' },
  ];
  const pick = handles[Math.floor(Math.random() * handles.length)];
  const phrases: Record<SocialPlatform, string[]> = {
    allgram: [
      `Le visuel est incroyable, ${artistName} impose vraiment son univers.`,
      `Direct en story ! On attend la suite en studio.`,
    ],
    alltok: [
      `Le son reste coincé dans la tête depuis ce matin !`,
      `Tout le monde reprend l'extrait sur AllTok en ce moment.`,
    ],
    allx: [
      `Prise de parole validée par toute la scène musicale.`,
      `Gros mouvement stratégique pour la suite de l'ère.`,
    ],
    alltub: [
      `La réalisation est digne d'un court-métrage. Chef-d'œuvre.`,
      `En boucle depuis la mise en ligne sur AllTub !`,
    ],
    allcloud: [
      `Le mix brut a une texture folle, sors ça sur Alltify !`,
      `Pépites underground comme on aime sur AllCloud.`,
    ],
  };
  const pool = phrases[post.platform] ?? phrases.allgram;
  const text = pool[Math.floor(Math.random() * pool.length)];

  return [
    {
      id: `ai_cmt_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      authorId: 'ai_offline',
      authorName: pick.name,
      authorHandle: pick.handle,
      isAi: true,
      text,
      createdAt: Date.now(),
    },
  ];
}

export function generateOfflineAiSocialPost(platform: SocialPlatform): SharedSocialPost {
  const rival = RIVAL_ARTISTS[Math.floor(Math.random() * RIVAL_ARTISTS.length)];
  const now = Date.now();
  const templates: Record<SocialPlatform, string[]> = {
    allgram: [
      `Session tardive avant la prochaine date. Le visuel de « ${rival.titles[0]} » arrive cette semaine.`,
      `Merci pour l'énergie hier soir. Nouvelle direction artistique en cours.`,
    ],
    alltok: [
      `Extrait exclusif de « ${rival.titles[0]} » en 15 secondes · Utilise ce son !`,
      `Coulisses du tournage avant la sortie officielle #AllStarz #Studio`,
    ],
    allx: [
      `Honnêtement, la scène musicale francophone n'a jamais été aussi forte qu'en ce moment. #AllStarz`,
      `On prépare un album qui va tout changer sur Alltify cette année.`,
    ],
    alltub: [
      `${rival.name} — ${rival.titles[0]} (Session Live Acoustique)`,
      `Dans les coulisses de la tournée : 48h avec ${rival.name}`,
    ],
    allcloud: [
      `Maquette brute 03h du matin — « ${rival.titles[1] ?? rival.titles[0]} (Demo) »`,
      `Freestyle inédit enregistré en une prise sur AllCloud.`,
    ],
  };

  const pool = templates[platform];
  return {
    id: `ai_post_${platform}_${now}_${Math.floor(Math.random() * 1000)}`,
    platform,
    authorId: `rival_${rival.name}`,
    authorName: rival.name,
    authorHandle: rival.handle,
    authorAvatar: '/src/assets/images/artist_portrait_urban_1795252245054.jpg',
    verified: true,
    isPlayer: false,
    isAi: true,
    location: platform === 'allgram' ? 'Paris · Studio' : undefined,
    tag: platform === 'allx' ? '#Musique' : 'IA Hors-ligne',
    title: platform === 'alltub' || platform === 'allcloud' ? pool[0] : undefined,
    content: pool[Math.floor(Math.random() * pool.length)],
    mediaTone: COVER_TONES[Math.floor(Math.random() * COVER_TONES.length)],
    attachedSongTitle: rival.titles[0],
    videoDuration: platform === 'alltub' ? '03:28' : undefined,
    likes: Math.round(rival.fameLevel * 120),
    likedByIds: [],
    reposts: Math.round(rival.fameLevel * 18),
    repostedByIds: [],
    views: Math.round(rival.fameLevel * 1450),
    comments: [],
    createdAt: now,
  };
}
