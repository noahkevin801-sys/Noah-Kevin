import {
  ARTIST_AVATARS,
  CHAT_CONTACTS,
  CLIP_OPTIONS,
  CONCERT_VENUES,
  COVER_TONES,
  FEATURING_ARTISTS,
  GENRES,
  INITIAL_ALLTUB_VIDEOS,
  INITIAL_BUZZ_POSTS,
  INITIAL_MERCH_CATALOG,
  INITIAL_STREAM_NEWS,
  LABEL_OFFERS,
  ORIGINS,
  PROJECT_FORMAT_RULES,
  PROMO_CAMPAIGNS,
  RIVAL_ARTISTS,
  STAFF_CATALOG,
  STUDIO_TIERS,
  TOUR_LODGING_OPTIONS,
  TOUR_PRODUCTION_OPTIONS,
  TOUR_TRANSPORT_OPTIONS,
} from '../data/gameData';
import {
  AllTubVideo,
  ArtistSkills,
  AwardTrophy,
  BuzzPost,
  CertificationLevel,
  ChartEntry,
  ChatThread,
  ConcertCostBreakdown,
  ConcertLog,
  ConcertVenue,
  EventChoice,
  FinancialEntry,
  GameState,
  GenreId,
  LodgingTier,
  Mission,
  MusicProject,
  NotificationItem,
  OriginId,
  ProductionTier,
  ProjectFormat,
  Song,
  SongLifecyclePhase,
  StreamNewsItem,
  Tour,
  TourDateItem,
  TourDateStatus,
  TransportTier,
  WeeklySummary,
} from '../types/game';
import { formatShortDate } from '../utils/format';
import { getEventCooldown, maybeTriggerRandomEvent } from './events';

function clamp(val: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, val));
}

export function computeCertification(streams: number): CertificationLevel {
  if (streams >= 2_000_000) return 'diamond';
  if (streams >= 1_000_000) return 'multi_platinum';
  if (streams >= 500_000) return 'platinum';
  if (streams >= 100_000) return 'gold';
  if (streams >= 50_000) return 'silver';
  if (streams >= 25_000) return 'bronze';
  return 'none';
}

function addNotification(
  list: NotificationItem[],
  item: Omit<NotificationItem, 'id' | 'read'>
): NotificationItem[] {
  const entry: NotificationItem = {
    ...item,
    id: `notif_${Date.now()}_${Math.floor(Math.random() * 10000)}`,
    read: false,
  };
  return [entry, ...list].slice(0, 40);
}

function addFinanceEntry(
  list: FinancialEntry[],
  item: Omit<FinancialEntry, 'id'>
): FinancialEntry[] {
  const entry: FinancialEntry = {
    ...item,
    id: `fin_${Date.now()}_${Math.floor(Math.random() * 10000)}`,
  };
  return [entry, ...list].slice(0, 60);
}

function addStreamNews(
  list: StreamNewsItem[],
  item: Omit<StreamNewsItem, 'id'>
): StreamNewsItem[] {
  const entry: StreamNewsItem = {
    ...item,
    id: `news_${Date.now()}_${Math.floor(Math.random() * 10000)}`,
  };
  return [entry, ...list].slice(0, 25);
}

const GLOBAL_SYLLABLES_A = [
  'Nuit', 'Verre', 'Soleil', 'Ondes', 'Lune', 'Aube', 'Cristal', 'Mirage',
  'Horizon', 'Ombre', 'Écho', 'Feu', 'Satin', 'Chrome', 'Vitesse', 'Océan',
];
const GLOBAL_SYLLABLES_B = [
  'Blanc', 'Doré', 'Noir', 'Clair', 'Polaires', 'Urbain', 'Éternel', 'Pure',
  'Bleu', 'Sauvage', 'Doux', 'Liquide', 'Haut', 'Calme', 'Infini', 'Brut',
];
const GLOBAL_ARTIST_NAMES = [
  'Luka', 'Maya V', 'Tarek', 'Selena R', 'Hector', 'Noa', 'Kenza', 'Elias',
  'Amina', 'Jules B', 'Romy', 'Liam O', 'Sora', 'Nino', 'Clara Z', 'Yael',
  'Mateo S', 'Kira', 'Bastian', 'Lina', 'Vesper', 'Oslo', 'Aya K', 'Malik',
];

function generateInitialCharts(): ChartEntry[] {
  const entries: ChartEntry[] = [];
  let idxCounter = 0;

  // Top Rivals
  RIVAL_ARTISTS.forEach((rival) => {
    rival.titles.forEach((title, idx) => {
      const baseStreams =
        (rival.fameLevel * 1450 - idx * 12000) * (0.88 + Math.random() * 0.24);
      entries.push({
        id: `rival_${rival.name}_${idx}`,
        rank: 0,
        previousRank: null,
        title,
        artistName: rival.name,
        genre: rival.genre,
        weeklyStreams: Math.max(24_000, Math.round(baseStreams)),
        isPlayer: false,
        weeksOnChart: 2 + idx * 2,
        coverTone: COVER_TONES[idxCounter++ % COVER_TONES.length],
      });
    });
  });

  // Fill remaining up to 200 global entries
  const genreIds = GENRES.map((g) => g.id);
  while (entries.length < 200) {
    const n = entries.length;
    const a = GLOBAL_SYLLABLES_A[n % GLOBAL_SYLLABLES_A.length];
    const b = GLOBAL_SYLLABLES_B[(n * 3) % GLOBAL_SYLLABLES_B.length];
    const artistName = GLOBAL_ARTIST_NAMES[(n * 5) % GLOBAL_ARTIST_NAMES.length];
    const decay = Math.max(3_200, Math.round(78_000 * Math.pow(0.985, n - 40)));
    entries.push({
      id: `global_rival_${n}`,
      rank: 0,
      previousRank: null,
      title: `${a} ${b}`,
      artistName,
      genre: genreIds[n % genreIds.length],
      weeklyStreams: Math.round(decay * (0.9 + Math.random() * 0.2)),
      isPlayer: false,
      weeksOnChart: 1 + (n % 14),
      coverTone: COVER_TONES[n % COVER_TONES.length],
    });
  }

  entries.sort((a, b) => b.weeklyStreams - a.weeklyStreams);
  return entries.slice(0, 200).map((entry, index) => ({
    ...entry,
    rank: index + 1,
    previousRank: index + 1,
  }));
}

export function createInitialGameState(params: {
  stageName: string;
  genre: GenreId;
  origin: OriginId;
  avatarUrl?: string;
}): GameState {
  const originDef = ORIGINS.find((o) => o.id === params.origin) ?? ORIGINS[0];
  const fallbackAvatar =
    params.genre === 'urban' ||
    params.genre === 'hiphop' ||
    params.genre === 'trap' ||
    params.genre === 'rnb'
      ? ARTIST_AVATARS[1].url
      : params.genre === 'electro'
        ? ARTIST_AVATARS[2].url
        : ARTIST_AVATARS[0].url;

  const stageName = params.stageName.trim() || 'Carter Knowlls';

  return {
    version: 3,
    artist: {
      stageName,
      bio: `Artiste en ascension · ${params.genre.toUpperCase()}`,
      genre: params.genre,
      origin: params.origin,
      avatarUrl: params.avatarUrl ?? fallbackAvatar,
      cash: originDef.startingCash,
      energy: 50,
      maxEnergy: 100,
      hype: originDef.startingHype,
      reputation: 50,
      fame: originDef.startingFame,
      fans: originDef.startingFans,
      monthlyListeners: Math.round(originDef.startingFans * 1.35),
      skills: { ...originDef.bonusSkills },
      labelId: 'independent',
      hiredStaffIds: [],
      dayOffset: 0, // Lundi 30 octobre 2026
      weeksActive: 1,
      totalStreams: 0,
      totalRevenue: originDef.startingCash,
      totalExpenses: 0,
      concertsPlayed: 0,
    },
    songs: [],
    projects: [],
    concerts: [],
    activeTour: null,
    tourHistory: [],
    merch: INITIAL_MERCH_CATALOG.map((m) => ({ ...m })),
    charts: generateInitialCharts(),
    buzzPosts: INITIAL_BUZZ_POSTS.map((p) => ({ ...p })),
    allTubVideos: INITIAL_ALLTUB_VIDEOS.map((v) => ({ ...v })),
    streamNews: INITIAL_STREAM_NEWS.map((n) => ({ ...n })),
    chatThreads: [],
    finances: [
      {
        id: 'fin_init',
        week: 1,
        label: `Capital de départ (${originDef.name})`,
        category: 'event',
        amount: originDef.startingCash,
      },
    ],
    notifications: [
      {
        id: 'notif_welcome',
        week: 1,
        title: 'Bienvenue dans ALL STARZ',
        message: 'Crée ton premier single dans Music ou discute avec ta conseillère dans Chat.',
        category: 'music',
        targetTab: 'music',
        read: false,
      },
    ],
    claimedMissionIds: [],
    pendingEvent: null,
    eventHistory: [],
    lastWeeklySummary: null,
    awards: [],
    cooldownEventTemplates: {},
    lastEventWeek: 0,
  };
}

export function updateArtistProfile(
  state: GameState,
  updates: { stageName?: string; bio?: string; avatarUrl?: string; genre?: GenreId }
): GameState {
  return {
    ...state,
    artist: {
      ...state.artist,
      stageName: updates.stageName?.trim() || state.artist.stageName,
      bio: updates.bio !== undefined ? updates.bio : state.artist.bio,
      avatarUrl: updates.avatarUrl ?? state.artist.avatarUrl,
      genre: updates.genre ?? state.artist.genre,
    },
  };
}

export function trainArtistSkill(
  state: GameState,
  skill: keyof ArtistSkills | 'rest'
): GameState {
  if (skill === 'rest') {
    const cost = state.artist.cash >= 90 ? 90 : 0;
    let nextFinances = state.finances;
    if (cost > 0) {
      nextFinances = addFinanceEntry(nextFinances, {
        week: state.artist.weeksActive,
        label: 'Repos & récupération',
        category: 'event',
        amount: -cost,
      });
    }
    return {
      ...state,
      artist: {
        ...state.artist,
        cash: state.artist.cash - cost,
        totalExpenses: state.artist.totalExpenses + cost,
        energy: clamp(state.artist.energy + 38, 0, state.artist.maxEnergy),
      },
      finances: nextFinances,
    };
  }

  const energyCost = 15;
  const cashCost = 80;
  if (state.artist.energy < energyCost || state.artist.cash < cashCost) {
    return state;
  }

  const currentVal = state.artist.skills[skill];
  const gain = currentVal < 50 ? 4 : currentVal < 80 ? 3 : 2;

  return {
    ...state,
    artist: {
      ...state.artist,
      cash: state.artist.cash - cashCost,
      totalExpenses: state.artist.totalExpenses + cashCost,
      energy: state.artist.energy - energyCost,
      skills: {
        ...state.artist.skills,
        [skill]: clamp(currentVal + gain, 1, 99),
      },
    },
    finances: addFinanceEntry(state.finances, {
      week: state.artist.weeksActive,
      label: `Session coaching (${skill})`,
      category: 'studio',
      amount: -cashCost,
    }),
  };
}

export function recordNewSong(
  state: GameState,
  params: {
    title: string;
    genre: GenreId;
    mood: string;
    theme: string;
    vocalStyle: string;
    studioId: string;
    featuringName: string | null;
  }
): { nextState: GameState; song: Song | null; error?: string } {
  const studio = STUDIO_TIERS.find((s) => s.id === params.studioId) ?? STUDIO_TIERS[0];
  const feat = params.featuringName
    ? FEATURING_ARTISTS.find((f) => f.name === params.featuringName) ?? null
    : null;

  const totalCost = studio.cost + (feat ? feat.cost : 0);
  if (state.artist.cash < totalCost) {
    return { nextState: state, song: null, error: 'Solde insuffisant pour cette session.' };
  }
  if (state.artist.energy < studio.energyCost) {
    return { nextState: state, song: null, error: 'Énergie insuffisante. Repose-toi ou avance le temps.' };
  }

  const { vocals, writing, production } = state.artist.skills;
  const skillAvg = vocals * 0.36 + writing * 0.34 + production * 0.3;
  const producerBonus = state.artist.hiredStaffIds.includes('producer') ? 6 : 0;
  const genreCoherence = params.genre === state.artist.genre ? 4 : 0;
  const randomVariance = Math.round((Math.random() - 0.35) * 12);
  const featBonus = feat ? Math.round(feat.boost * 0.45) : 0;

  const quality = clamp(
    Math.round(
      skillAvg * 0.62 +
        studio.qualityBonus +
        producerBonus +
        genreCoherence +
        featBonus +
        randomVariance
    ),
    30,
    99
  );

  const genreObj = GENRES.find((g) => g.id === params.genre) ?? GENRES[0];
  const fallbackTitle =
    genreObj.songTitles[state.songs.length % genreObj.songTitles.length];

  const newSong: Song = {
    id: `song_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
    title: params.title.trim() || fallbackTitle,
    genre: params.genre,
    mood: params.mood,
    theme: params.theme,
    vocalStyle: params.vocalStyle,
    quality,
    studioName: studio.name,
    featuringArtist: feat ? feat.name : null,
    released: false,
    releaseWeek: null,
    releaseDayOffset: null,
    weeklyStreams: 0,
    dailyStreams: 0,
    totalStreams: 0,
    streamHistory: [],
    bestWeekStreams: 0,
    revenueEarned: 0,
    peakChartPos: null,
    currentChartPos: null,
    promoApplied: [],
    promoCount: 0,
    hasClip: false,
    clipStyle: null,
    certification: 'none',
    lifecyclePhase: 'sortie',
    viralBoostWeeks: 0,
  };

  let nextFinances = state.finances;
  if (totalCost > 0) {
    nextFinances = addFinanceEntry(nextFinances, {
      week: state.artist.weeksActive,
      label: `Enregistrement « ${newSong.title} » (${studio.name})`,
      category: 'studio',
      amount: -totalCost,
    });
  }

  return {
    nextState: {
      ...state,
      artist: {
        ...state.artist,
        cash: state.artist.cash - totalCost,
        totalExpenses: state.artist.totalExpenses + totalCost,
        energy: state.artist.energy - studio.energyCost,
        skills: {
          ...state.artist.skills,
          writing: clamp(state.artist.skills.writing + 1, 1, 99),
          production: clamp(state.artist.skills.production + 1, 1, 99),
        },
      },
      songs: [newSong, ...state.songs],
      finances: nextFinances,
    },
    song: newSong,
  };
}

export function releaseSongWithPromo(
  state: GameState,
  songId: string,
  promoIds: string[]
): { nextState: GameState; error?: string } {
  const song = state.songs.find((s) => s.id === songId);
  if (!song || song.released) {
    return { nextState: state, error: 'Titre introuvable ou déjà publié.' };
  }

  const selectedPromos = PROMO_CAMPAIGNS.filter((p) => promoIds.includes(p.id));
  const promoCost = selectedPromos.reduce((sum, p) => sum + p.cost, 0);
  if (state.artist.cash < promoCost) {
    return { nextState: state, error: 'Budget promotionnel insuffisant.' };
  }

  const label = LABEL_OFFERS.find((l) => l.id === state.artist.labelId) ?? LABEL_OFFERS[0];
  const hasPublicist = state.artist.hiredStaffIds.includes('publicist');
  const publicistBonus = hasPublicist ? 1.18 : 1.0;

  const promoHype = selectedPromos.reduce((sum, p) => sum + p.hypeGain, 0);
  const promoMultiplier =
    selectedPromos.reduce((mul, p) => mul * p.streamMultiplier, 1) * publicistBonus;

  const featObj = song.featuringArtist
    ? FEATURING_ARTISTS.find((f) => f.name === song.featuringArtist)
    : null;
  const featMultiplier = featObj ? 1 + featObj.boost / 45 : 1;

  const baseDebut =
    (state.artist.fans * 1.55 + 620) *
    (0.45 + song.quality / 65) *
    (1 + state.artist.hype / 110) *
    promoMultiplier *
    featMultiplier *
    label.streamBonus;

  const initialWeeklyStreams = Math.round(baseDebut);
  const initialDailyStreams = Math.round(initialWeeklyStreams / 7);
  const fansGained = Math.round(initialWeeklyStreams * 0.036);

  const updatedSongs = state.songs.map((s) =>
    s.id === songId
      ? {
          ...s,
          released: true,
          releaseWeek: state.artist.weeksActive,
          releaseDayOffset: state.artist.dayOffset,
          weeklyStreams: initialWeeklyStreams,
          dailyStreams: initialDailyStreams,
          totalStreams: initialWeeklyStreams,
          streamHistory: [initialWeeklyStreams],
          bestWeekStreams: initialWeeklyStreams,
          promoApplied: promoIds,
          promoCount: promoIds.length,
          certification: computeCertification(initialWeeklyStreams),
          lifecyclePhase: 'sortie' as SongLifecyclePhase,
        }
      : s
  );

  let nextFinances = state.finances;
  if (promoCost > 0) {
    nextFinances = addFinanceEntry(nextFinances, {
      week: state.artist.weeksActive,
      label: `Sortie & Promo « ${song.title} »`,
      category: 'promo',
      amount: -promoCost,
    });
  }

  const nextNews = addStreamNews(state.streamNews, {
    dateLabel: formatShortDate(state.artist.dayOffset),
    title: `Nouvelle sortie : « ${song.title} »`,
    detail: `Démarre fort sur Alltify avec ${initialDailyStreams.toLocaleString('fr-FR')} écoutes dès le premier jour.`,
    category: 'streams',
    deltaText: `+${initialWeeklyStreams.toLocaleString('fr-FR')}`,
  });

  const nextNotifs = addNotification(state.notifications, {
    week: state.artist.weeksActive,
    title: `Single publié : « ${song.title} »`,
    message: `${initialWeeklyStreams.toLocaleString('fr-FR')} écoutes enregistrées sur Alltify.`,
    category: 'music',
    targetTab: 'music',
  });

  const updatedState: GameState = {
    ...state,
    artist: {
      ...state.artist,
      cash: state.artist.cash - promoCost,
      totalExpenses: state.artist.totalExpenses + promoCost,
      hype: clamp(state.artist.hype + 7 + promoHype, 0, 100),
      fame: clamp(state.artist.fame + 3, 0, 100),
      fans: state.artist.fans + fansGained,
      totalStreams: state.artist.totalStreams + initialWeeklyStreams,
    },
    songs: updatedSongs,
    streamNews: nextNews,
    finances: nextFinances,
    notifications: nextNotifs,
  };

  return { nextState: recalculateCharts(updatedState) };
}

export function promoteReleasedSong(
  state: GameState,
  songId: string,
  promoId: string
): { nextState: GameState; error?: string } {
  const song = state.songs.find((s) => s.id === songId && s.released);
  const promo = PROMO_CAMPAIGNS.find((p) => p.id === promoId);
  if (!song || !promo) return { nextState: state, error: 'Campagne impossible.' };
  if (state.artist.cash < promo.cost) {
    return { nextState: state, error: 'Solde insuffisant pour cette campagne.' };
  }

  const diminishingFactor = Math.max(0.28, 1 - song.promoCount * 0.22);
  const effectiveMultiplier = 1 + (promo.streamMultiplier - 1) * diminishingFactor;
  const boostedWeekly = Math.round(song.weeklyStreams * effectiveMultiplier);
  const extraStreams = Math.max(200, boostedWeekly - song.weeklyStreams);
  const hypeGain = Math.max(2, Math.round(promo.hypeGain * diminishingFactor));

  const updatedSongs = state.songs.map((s) =>
    s.id === songId
      ? {
          ...s,
          weeklyStreams: boostedWeekly,
          dailyStreams: Math.round(boostedWeekly / 7),
          totalStreams: s.totalStreams + extraStreams,
          bestWeekStreams: Math.max(s.bestWeekStreams, boostedWeekly),
          promoApplied: [...s.promoApplied, promo.id],
          promoCount: s.promoCount + 1,
          viralBoostWeeks: Math.max(s.viralBoostWeeks, 1),
          lifecyclePhase:
            s.lifecyclePhase === 'declin'
              ? ('redecouverte' as SongLifecyclePhase)
              : s.lifecyclePhase,
        }
      : s
  );

  return {
    nextState: recalculateCharts({
      ...state,
      artist: {
        ...state.artist,
        cash: state.artist.cash - promo.cost,
        totalExpenses: state.artist.totalExpenses + promo.cost,
        hype: clamp(state.artist.hype + hypeGain, 0, 100),
        totalStreams: state.artist.totalStreams + extraStreams,
      },
      songs: updatedSongs,
      streamNews: addStreamNews(state.streamNews, {
        dateLabel: formatShortDate(state.artist.dayOffset),
        title: `Campagne ${promo.name} lancée`,
        detail: `« ${song.title} » regagne en visibilité (+${extraStreams.toLocaleString('fr-FR')} écoutes).`,
        category: 'streams',
        deltaText: `+${hypeGain} Pop.`,
      }),
      finances: addFinanceEntry(state.finances, {
        week: state.artist.weeksActive,
        label: `Promo ${promo.name} (« ${song.title} »)`,
        category: 'promo',
        amount: -promo.cost,
      }),
    }),
  };
}

export function createMusicVideoForSong(
  state: GameState,
  songId: string,
  clipId: string
): { nextState: GameState; error?: string } {
  const song = state.songs.find((s) => s.id === songId && s.released);
  const clip = CLIP_OPTIONS.find((c) => c.id === clipId);
  if (!song || !clip) return { nextState: state, error: 'Clip indisponible.' };
  if (song.hasClip) return { nextState: state, error: 'Ce titre possède déjà un clip sur AllTub.' };
  if (state.artist.cash < clip.cost) {
    return { nextState: state, error: 'Budget insuffisant pour tourner ce clip.' };
  }
  if (state.artist.energy < clip.energyCost) {
    return { nextState: state, error: 'Énergie insuffisante pour le tournage.' };
  }

  const boostedWeekly = Math.round(song.weeklyStreams * clip.streamMultiplier);
  const extraStreams = Math.max(500, boostedWeekly - song.weeklyStreams);
  const fansGained = Math.round(extraStreams * 0.045);
  const initialViews = Math.round(extraStreams * 1.45 + 1800);

  const updatedSongs = state.songs.map((s) =>
    s.id === songId
      ? {
          ...s,
          hasClip: true,
          clipStyle: clip.name,
          weeklyStreams: boostedWeekly,
          dailyStreams: Math.round(boostedWeekly / 7),
          totalStreams: s.totalStreams + extraStreams,
          bestWeekStreams: Math.max(s.bestWeekStreams, boostedWeekly),
          viralBoostWeeks: 2,
          lifecyclePhase:
            s.lifecyclePhase === 'declin'
              ? ('redecouverte' as SongLifecyclePhase)
              : ('croissance' as SongLifecyclePhase),
        }
      : s
  );

  const newVideo: AllTubVideo = {
    id: `vid_${Date.now()}`,
    title: `${state.artist.stageName} — ${song.title} (${clip.name})`,
    channelName: state.artist.stageName,
    videoType: 'Clip Officiel',
    songId: song.id,
    views: initialViews,
    likes: Math.round(initialViews * 0.09),
    week: state.artist.weeksActive,
    isPlayer: true,
  };

  return {
    nextState: recalculateCharts({
      ...state,
      artist: {
        ...state.artist,
        cash: state.artist.cash - clip.cost,
        totalExpenses: state.artist.totalExpenses + clip.cost,
        energy: state.artist.energy - clip.energyCost,
        hype: clamp(state.artist.hype + clip.hypeGain, 0, 100),
        fame: clamp(state.artist.fame + 4, 0, 100),
        fans: state.artist.fans + fansGained,
        totalStreams: state.artist.totalStreams + extraStreams,
      },
      songs: updatedSongs,
      allTubVideos: [newVideo, ...state.allTubVideos],
      streamNews: addStreamNews(state.streamNews, {
        dateLabel: formatShortDate(state.artist.dayOffset),
        title: `Clip publié sur AllTub : « ${song.title} »`,
        detail: `${initialViews.toLocaleString('fr-FR')} vues dès la mise en ligne.`,
        category: 'milestone',
        deltaText: 'AllTub',
      }),
      finances: addFinanceEntry(state.finances, {
        week: state.artist.weeksActive,
        label: `${clip.name} — « ${song.title} »`,
        category: 'promo',
        amount: -clip.cost,
      }),
      notifications: addNotification(state.notifications, {
        week: state.artist.weeksActive,
        title: `Clip publié sur AllTub`,
        message: `« ${song.title} » cumule déjà ${initialViews.toLocaleString('fr-FR')} vues.`,
        category: 'music',
        targetTab: 'apps',
        targetApp: 'alltub',
      }),
    }),
  };
}

export function publishAllTubVlog(
  state: GameState,
  title: string,
  videoType: 'Session Studio' | 'Live Performance' | 'Interview'
): { nextState: GameState; error?: string } {
  if (state.artist.energy < 10) {
    return { nextState: state, error: 'Énergie insuffisante (10 requis).' };
  }
  const views = Math.round((state.artist.fans * 0.9 + 650) * (0.85 + Math.random() * 0.5));
  const fansGained = Math.round(views * 0.03);
  const newVideo: AllTubVideo = {
    id: `vid_${Date.now()}`,
    title: title.trim() || `${state.artist.stageName} — ${videoType}`,
    channelName: state.artist.stageName,
    videoType,
    views,
    likes: Math.round(views * 0.1),
    week: state.artist.weeksActive,
    isPlayer: true,
  };

  return {
    nextState: {
      ...state,
      artist: {
        ...state.artist,
        energy: state.artist.energy - 10,
        fans: state.artist.fans + fansGained,
        hype: clamp(state.artist.hype + 4, 0, 100),
      },
      allTubVideos: [newVideo, ...state.allTubVideos],
    },
  };
}

export function releaseProjectFromVault(
  state: GameState,
  projectTitle: string,
  format: ProjectFormat,
  trackIds: string[],
  parentAlbumId?: string | null
): { nextState: GameState; project: MusicProject | null; error?: string } {
  const rule = PROJECT_FORMAT_RULES.find((r) => r.format === format) ?? PROJECT_FORMAT_RULES[0];
  const vaultTracks = state.songs.filter((s) => trackIds.includes(s.id) && !s.released);

  if (vaultTracks.length < rule.minTracks || vaultTracks.length > rule.maxTracks) {
    return {
      nextState: state,
      project: null,
      error: `Un format ${rule.label} doit contenir entre ${rule.minTracks} et ${rule.maxTracks} titres inédits.`,
    };
  }

  if (format === 'deluxe' && !parentAlbumId) {
    return {
      nextState: state,
      project: null,
      error: 'Sélectionne un album existant à étendre en Édition Deluxe.',
    };
  }

  const label = LABEL_OFFERS.find((l) => l.id === state.artist.labelId) ?? LABEL_OFFERS[0];
  const avgQuality = Math.round(
    vaultTracks.reduce((sum, t) => sum + t.quality, 0) / vaultTracks.length
  );

  const projectId = `proj_${Date.now()}`;
  const formatBonus = rule.streamMultiplier * label.streamBonus;

  let totalProjWeekStreams = 0;
  const updatedSongs = state.songs.map((s) => {
    if (!trackIds.includes(s.id)) return s;
    const trackStreams = Math.round(
      (state.artist.fans * 1.15 + 500) *
        (0.42 + s.quality / 70) *
        (1 + state.artist.hype / 120) *
        formatBonus
    );
    totalProjWeekStreams += trackStreams;
    return {
      ...s,
      released: true,
      releaseWeek: state.artist.weeksActive,
      releaseDayOffset: state.artist.dayOffset,
      weeklyStreams: trackStreams,
      dailyStreams: Math.round(trackStreams / 7),
      totalStreams: trackStreams,
      streamHistory: [trackStreams],
      bestWeekStreams: trackStreams,
      projectId,
      certification: computeCertification(trackStreams),
      lifecyclePhase: 'sortie' as SongLifecyclePhase,
    };
  });

  const parentAlb = parentAlbumId
    ? state.projects.find((p) => p.id === parentAlbumId)
    : null;

  const finalTitle =
    format === 'deluxe' && parentAlb
      ? `${parentAlb.title} (Deluxe)`
      : projectTitle.trim() || `Prisme ${rule.label}`;

  const newProject: MusicProject = {
    id: projectId,
    title: finalTitle,
    format,
    genre: state.artist.genre,
    trackIds,
    parentAlbumId: parentAlbumId ?? null,
    quality: avgQuality,
    releaseWeek: state.artist.weeksActive,
    totalStreams: totalProjWeekStreams,
    revenueEarned: 0,
    certification: computeCertification(totalProjWeekStreams),
  };

  const fansGained = Math.round(totalProjWeekStreams * 0.042);
  const hypeGain =
    format === 'album' || format === 'deluxe' ? 22 : format === 'mixtape' ? 17 : 13;
  const fameGain = format === 'album' || format === 'deluxe' ? 7 : 4;

  const nextState = recalculateCharts({
    ...state,
    artist: {
      ...state.artist,
      hype: clamp(state.artist.hype + hypeGain, 0, 100),
      fame: clamp(state.artist.fame + fameGain, 0, 100),
      fans: state.artist.fans + fansGained,
      totalStreams: state.artist.totalStreams + totalProjWeekStreams,
    },
    songs: updatedSongs,
    projects: [newProject, ...state.projects],
    streamNews: addStreamNews(state.streamNews, {
      dateLabel: formatShortDate(state.artist.dayOffset),
      title: `Sortie ${rule.label} : « ${newProject.title} »`,
      detail: `${vaultTracks.length} morceaux cumulés à ${totalProjWeekStreams.toLocaleString('fr-FR')} écoutes.`,
      category: 'milestone',
      deltaText: rule.label,
    }),
    notifications: addNotification(state.notifications, {
      week: state.artist.weeksActive,
      title: `${rule.label} disponible : « ${newProject.title} »`,
      message: `${vaultTracks.length} titres publiés sur Alltify.`,
      category: 'music',
      targetTab: 'music',
    }),
  });

  return { nextState, project: newProject };
}

export function computeConcertCosts(
  state: GameState,
  venue: ConcertVenue,
  transportTier: TransportTier = 'van',
  lodgingTier: LodgingTier = 'standard',
  productionTier: ProductionTier = 'acoustic'
): ConcertCostBreakdown {
  const hasManager = state.artist.hiredStaffIds.includes('manager');
  const hasTourDir = state.artist.hiredStaffIds.includes('tour_director');

  const venueCost = Math.round(venue.bookingCost * (hasManager ? 0.85 : 1));
  const region = venue.region ?? 'france';

  const transportOpt =
    TOUR_TRANSPORT_OPTIONS.find((t) => t.id === transportTier) ?? TOUR_TRANSPORT_OPTIONS[0];
  const transportCost = Math.round(
    transportOpt.baseCost *
      transportOpt.regionMultiplier[region] *
      (1 + Math.min(2.5, venue.capacity / 15000))
  );

  const lodgingOpt =
    TOUR_LODGING_OPTIONS.find((l) => l.id === lodgingTier) ?? TOUR_LODGING_OPTIONS[0];
  const lodgingCost = Math.round(
    lodgingOpt.baseCost * (1 + Math.min(2.2, venue.capacity / 18000))
  );

  const crewCost = Math.round(65 + venue.capacity * 0.35 + (hasTourDir ? 180 : 0));

  const prodOpt =
    TOUR_PRODUCTION_OPTIONS.find((p) => p.id === productionTier) ?? TOUR_PRODUCTION_OPTIONS[0];
  const productionCost = Math.round(prodOpt.baseCost + venue.capacity * prodOpt.capacityFactorCost);

  const totalCost = venueCost + transportCost + lodgingCost + crewCost + productionCost;
  return {
    venueCost,
    transportCost,
    lodgingCost,
    crewCost,
    productionCost,
    totalCost,
  };
}

export interface TourDateForecast {
  estimatedAttendance: number;
  fillRatePct: number;
  presoldTickets: number;
  ticketRevenue: number;
  merchRevenue: number;
  grossRevenue: number;
  costs: ConcertCostBreakdown;
  estimatedNetProfit: number;
  energyCost: number;
  demandFeedback: string;
}

export function estimateTourDateForecast(
  state: GameState,
  params: {
    venueId: string;
    ticketPrice: number;
    dayOffset?: number;
    transportTier?: TransportTier;
    lodgingTier?: LodgingTier;
    productionTier?: ProductionTier;
  }
): TourDateForecast | null {
  const venue = CONCERT_VENUES.find((v) => v.id === params.venueId);
  if (!venue) return null;

  const transportTier = params.transportTier ?? 'van';
  const lodgingTier = params.lodgingTier ?? 'standard';
  const productionTier = params.productionTier ?? 'acoustic';

  const hasTourDir = state.artist.hiredStaffIds.includes('tour_director');
  const transportOpt =
    TOUR_TRANSPORT_OPTIONS.find((t) => t.id === transportTier) ?? TOUR_TRANSPORT_OPTIONS[0];
  const lodgingOpt =
    TOUR_LODGING_OPTIONS.find((l) => l.id === lodgingTier) ?? TOUR_LODGING_OPTIONS[0];
  const prodOpt =
    TOUR_PRODUCTION_OPTIONS.find((p) => p.id === productionTier) ?? TOUR_PRODUCTION_OPTIONS[0];

  const priceRatio = venue.recommendedPrice / Math.max(5, params.ticketPrice);
  const priceElasticity = clamp(Math.pow(priceRatio, 1.35), 0.2, 1.25);
  const tourBonus = hasTourDir ? 1.15 : 1.0;
  const internationalFactor =
    venue.region === 'monde' && state.artist.fame < 25
      ? 0.78
      : venue.region === 'europe' && state.artist.fame < 12
        ? 0.88
        : 1.0;

  const rawDemand =
    (state.artist.fans * 0.42 + 45) *
    (0.75 + state.artist.hype / 130) *
    priceElasticity *
    tourBonus *
    prodOpt.attendanceBoost *
    internationalFactor;

  const minFloor = Math.min(18, venue.capacity);
  const estimatedAttendance = clamp(Math.round(rawDemand), minFloor, venue.capacity);
  const fillRatePct = Math.round((estimatedAttendance / venue.capacity) * 100);

  const daysUntil =
    params.dayOffset !== undefined ? Math.max(0, params.dayOffset - state.artist.dayOffset) : 0;
  const presaleRatio = clamp(0.88 - daysUntil * 0.032 + (hasTourDir ? 0.08 : 0), 0.18, 0.94);
  const presoldTickets = Math.min(
    estimatedAttendance,
    Math.round(estimatedAttendance * presaleRatio)
  );

  const ticketRevenue = Math.round(estimatedAttendance * params.ticketPrice);
  const unlockedMerchCount = state.merch.filter((m) => m.unlocked).length;
  const merchRevenue = Math.round(estimatedAttendance * unlockedMerchCount * 2.5);
  const grossRevenue = ticketRevenue + merchRevenue;

  const costs = computeConcertCosts(
    state,
    venue,
    transportTier,
    lodgingTier,
    productionTier
  );
  const estimatedNetProfit = grossRevenue - costs.totalCost;

  const energyCost = Math.max(
    6,
    venue.energyCost - (hasTourDir ? 4 : 0) - transportOpt.energyRelief - lodgingOpt.energyRelief
  );

  let demandFeedback = 'Affluence équilibrée selon ta popularité actuelle.';
  if (fillRatePct >= 95) {
    demandFeedback = 'Forte demande · Salle quasiment complète estimée.';
  } else if (priceRatio < 0.72) {
    demandFeedback = 'Prix élevé · Risque de freiner la billetterie.';
  } else if (state.artist.fans < venue.minFans) {
    demandFeedback = `Salle ambitieuse (${venue.minFans.toLocaleString('fr-FR')} fans conseillés).`;
  } else if (priceRatio > 1.25) {
    demandFeedback = 'Tarif accessible · Remplissage accéléré mais marge unitaire réduite.';
  }

  return {
    estimatedAttendance,
    fillRatePct,
    presoldTickets,
    ticketRevenue,
    merchRevenue,
    grossRevenue,
    costs,
    estimatedNetProfit,
    energyCost,
    demandFeedback,
  };
}

export function normalizeTour(tour: Tour | null, currentDayOffset = 0): Tour | null {
  if (!tour) return null;
  if (Array.isArray(tour.dates)) {
    return {
      ...tour,
      status: tour.status ?? (tour.active ? 'active' : 'completed'),
      defaultTransportTier: tour.defaultTransportTier ?? 'van',
      defaultLodgingTier: tour.defaultLodgingTier ?? 'standard',
      defaultProductionTier: tour.defaultProductionTier ?? 'acoustic',
      totalRevenue: tour.totalRevenue ?? Math.max(0, tour.totalProfit),
      totalExpenses: tour.totalExpenses ?? 0,
    };
  }

  const venue = CONCERT_VENUES.find((v) => v.id === tour.venueId) ?? CONCERT_VENUES[0];
  const dates: TourDateItem[] = Array.from({ length: Math.max(1, tour.totalDates) }, (_, idx) => ({
    id: `${tour.id}_d_${idx + 1}`,
    venueId: venue.id,
    cityId: venue.cityId,
    venueName: venue.name,
    city: venue.city,
    country: venue.country ?? 'France',
    continent: venue.continent ?? 'Europe',
    showType: venue.showType,
    capacity: venue.capacity,
    dayOffset: currentDayOffset + idx * 3,
    ticketPrice: tour.ticketPrice || venue.recommendedPrice,
    ticketsSold: idx < tour.completedDates ? venue.capacity : Math.round(venue.capacity * 0.45),
    status: idx < tour.completedDates ? 'played' : 'scheduled',
    transportTier: 'van',
    lodgingTier: 'standard',
    productionTier: 'acoustic',
    report: null,
  }));

  return {
    ...tour,
    status: tour.active ? 'active' : 'completed',
    dates,
    defaultTransportTier: 'van',
    defaultLodgingTier: 'standard',
    defaultProductionTier: 'acoustic',
    totalRevenue: tour.totalRevenue ?? Math.max(0, tour.totalProfit),
    totalExpenses: tour.totalExpenses ?? 0,
  };
}

function recalculateTourMetrics(tour: Tour): Tour {
  const dates = tour.dates ?? [];
  const played = dates.filter((d) => d.status === 'played');
  const activeDates = dates.filter((d) => d.status !== 'cancelled');
  const totalAttendance = played.reduce((s, d) => s + (d.report?.attendance ?? d.ticketsSold), 0);
  const totalRevenue = played.reduce((s, d) => s + (d.report?.grossRevenue ?? 0), 0);
  const totalExpenses = played.reduce((s, d) => s + (d.report?.costs?.totalCost ?? 0), 0);
  const totalProfit = played.reduce((s, d) => s + (d.report?.netProfit ?? 0), 0);

  return {
    ...tour,
    totalDates: activeDates.length,
    completedDates: played.length,
    totalAttendance,
    totalRevenue,
    totalExpenses,
    totalProfit,
  };
}

export function refreshTourPresales(state: GameState): GameState {
  const normalized = normalizeTour(state.activeTour, state.artist.dayOffset);
  if (!normalized || !normalized.dates) return state;

  const updatedDates = normalized.dates.map((d) => {
    if (d.status !== 'scheduled' && d.status !== 'postponed') return d;
    const forecast = estimateTourDateForecast(state, {
      venueId: d.venueId,
      ticketPrice: d.ticketPrice,
      dayOffset: d.dayOffset,
      transportTier: d.transportTier,
      lodgingTier: d.lodgingTier,
      productionTier: d.productionTier,
    });
    if (!forecast) return d;
    return {
      ...d,
      ticketsSold: Math.max(d.ticketsSold, forecast.presoldTickets),
    };
  });

  return {
    ...state,
    activeTour: {
      ...normalized,
      dates: updatedDates,
    },
  };
}

function executeConcertInternal(
  state: GameState,
  params: {
    venue: ConcertVenue;
    ticketPrice: number;
    dayOffset?: number;
    transportTier?: TransportTier;
    lodgingTier?: LodgingTier;
    productionTier?: ProductionTier;
    tourId?: string;
    tourName?: string;
  }
): { nextState: GameState; log: ConcertLog | null; error?: string } {
  const { venue, ticketPrice } = params;
  const transportTier = params.transportTier ?? 'van';
  const lodgingTier = params.lodgingTier ?? 'standard';
  const productionTier = params.productionTier ?? 'acoustic';

  const forecast = estimateTourDateForecast(state, {
    venueId: venue.id,
    ticketPrice,
    dayOffset: params.dayOffset ?? state.artist.dayOffset,
    transportTier,
    lodgingTier,
    productionTier,
  });

  if (!forecast) {
    return { nextState: state, log: null, error: 'Lieu introuvable.' };
  }

  const { costs, energyCost } = forecast;
  if (state.artist.cash < costs.totalCost) {
    return {
      nextState: state,
      log: null,
      error: `Solde insuffisant (${costs.totalCost.toLocaleString('fr-FR')} € requis pour la salle, l’équipe et la logistique).`,
    };
  }
  if (state.artist.energy < energyCost) {
    return {
      nextState: state,
      log: null,
      error: `Énergie insuffisante (${energyCost} requis). Repose-toi ou ajuste l’hébergement/transport.`,
    };
  }

  const variance = 0.94 + Math.random() * 0.12;
  const attendance = clamp(
    Math.round(forecast.estimatedAttendance * variance),
    Math.min(18, venue.capacity),
    venue.capacity
  );
  const fillRate = attendance / venue.capacity;

  const ticketRevenue = Math.round(attendance * ticketPrice);
  const unlockedMerchCount = state.merch.filter((m) => m.unlocked).length;
  const merchRevenue = Math.round(attendance * unlockedMerchCount * 2.5);
  const totalGross = ticketRevenue + merchRevenue;
  const netProfit = totalGross - costs.totalCost;

  const transportOpt =
    TOUR_TRANSPORT_OPTIONS.find((t) => t.id === transportTier) ?? TOUR_TRANSPORT_OPTIONS[0];
  const lodgingOpt =
    TOUR_LODGING_OPTIONS.find((l) => l.id === lodgingTier) ?? TOUR_LODGING_OPTIONS[0];
  const prodOpt =
    TOUR_PRODUCTION_OPTIONS.find((p) => p.id === productionTier) ?? TOUR_PRODUCTION_OPTIONS[0];

  const satisfaction = clamp(
    Math.round(
      state.artist.skills.stage * 0.5 +
        state.artist.skills.vocals * 0.3 +
        fillRate * 20 +
        lodgingOpt.satisfactionBonus +
        prodOpt.satisfactionBonus
    ),
    45,
    99
  );
  const fansGained = Math.round(attendance * (0.14 + satisfaction / 310));
  const hypeGained = Math.round(
    venue.prestigeGain * (0.6 + fillRate * 0.6) + transportOpt.hypeBonus + prodOpt.hypeBonus
  );

  const country = venue.country ?? 'France';
  const showDay = params.dayOffset ?? state.artist.dayOffset;

  const log: ConcertLog = {
    id: `show_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
    week: state.artist.weeksActive,
    dayOffset: showDay,
    venueName: venue.name,
    city: venue.city,
    country,
    showType: venue.showType,
    tourId: params.tourId,
    tourName: params.tourName,
    attendance,
    capacity: venue.capacity,
    ticketPrice,
    ticketRevenue,
    merchRevenue,
    grossRevenue: totalGross,
    costs,
    netProfit,
    fansGained,
    hypeGained,
    satisfaction,
  };

  let nextFinances = addFinanceEntry(state.finances, {
    week: state.artist.weeksActive,
    label: `Coûts Live · ${venue.name} (${venue.city})`,
    category: 'concert',
    amount: -costs.totalCost,
  });
  nextFinances = addFinanceEntry(nextFinances, {
    week: state.artist.weeksActive,
    label: `Billetterie & Merch · ${venue.name} (${attendance} spect.)`,
    category: 'concert',
    amount: totalGross,
  });

  return {
    nextState: {
      ...state,
      artist: {
        ...state.artist,
        cash: state.artist.cash - costs.totalCost + totalGross,
        totalRevenue: state.artist.totalRevenue + totalGross,
        totalExpenses: state.artist.totalExpenses + costs.totalCost,
        energy: state.artist.energy - energyCost,
        fans: state.artist.fans + fansGained,
        hype: clamp(state.artist.hype + hypeGained, 0, 100),
        fame: clamp(
          state.artist.fame + Math.max(1, Math.round((venue.prestigeGain + prodOpt.hypeBonus) / 3)),
          0,
          100
        ),
        concertsPlayed: state.artist.concertsPlayed + 1,
        skills: {
          ...state.artist.skills,
          stage: clamp(state.artist.skills.stage + 2, 1, 99),
        },
      },
      concerts: [log, ...state.concerts],
      streamNews: addStreamNews(state.streamNews, {
        dateLabel: formatShortDate(state.artist.dayOffset),
        title: `Live à ${venue.city} : ${venue.name}`,
        detail: `${attendance.toLocaleString('fr-FR')} spectateurs (${Math.round(fillRate * 100)}%) · Satisfaction ${satisfaction}%.`,
        category: 'milestone',
        deltaText: `+${fansGained} fans`,
      }),
      finances: nextFinances,
      notifications: addNotification(state.notifications, {
        week: state.artist.weeksActive,
        title: `Concert terminé : ${venue.name}`,
        message: `${attendance.toLocaleString('fr-FR')} spectateurs · Résultat ${netProfit >= 0 ? '+' : ''}${netProfit.toLocaleString('fr-FR')} €.`,
        category: 'live',
        targetTab: 'apps',
        targetApp: 'tours',
      }),
    },
    log,
  };
}

export function performConcertShow(
  state: GameState,
  venueId: string,
  ticketPrice: number,
  logistics?: {
    transportTier?: TransportTier;
    lodgingTier?: LodgingTier;
    productionTier?: ProductionTier;
  }
): { nextState: GameState; log: ConcertLog | null; error?: string } {
  const venue = CONCERT_VENUES.find((v) => v.id === venueId);
  if (!venue) return { nextState: state, log: null, error: 'Lieu introuvable.' };
  return executeConcertInternal(state, {
    venue,
    ticketPrice,
    transportTier: logistics?.transportTier ?? 'van',
    lodgingTier: logistics?.lodgingTier ?? 'standard',
    productionTier: logistics?.productionTier ?? 'acoustic',
  });
}

export function createCustomTour(
  state: GameState,
  params: {
    name: string;
    defaultTransportTier: TransportTier;
    defaultLodgingTier: LodgingTier;
    defaultProductionTier: ProductionTier;
  }
): { nextState: GameState; error?: string } {
  const existing = normalizeTour(state.activeTour, state.artist.dayOffset);
  if (existing && existing.status !== 'completed') {
    return {
      nextState: state,
      error: 'Une tournée est déjà ouverte. Modifie-la directement ou clôture-la avant d’en créer une nouvelle.',
    };
  }

  const tour: Tour = {
    id: `tour_${Date.now()}`,
    name: params.name.trim() || 'Nouvelle Tournée',
    scope: 'custom',
    status: 'draft',
    dates: [],
    defaultTransportTier: params.defaultTransportTier,
    defaultLodgingTier: params.defaultLodgingTier,
    defaultProductionTier: params.defaultProductionTier,
    totalDates: 0,
    completedDates: 0,
    venueId: CONCERT_VENUES[0].id,
    ticketPrice: CONCERT_VENUES[0].recommendedPrice,
    totalAttendance: 0,
    totalRevenue: 0,
    totalExpenses: 0,
    totalProfit: 0,
    active: false,
    createdDayOffset: state.artist.dayOffset,
  };

  return {
    nextState: {
      ...state,
      activeTour: tour,
    },
  };
}

export function updateCustomTourSettings(
  state: GameState,
  updates: {
    name?: string;
    status?: 'draft' | 'active';
    defaultTransportTier?: TransportTier;
    defaultLodgingTier?: LodgingTier;
    defaultProductionTier?: ProductionTier;
  }
): GameState {
  const tour = normalizeTour(state.activeTour, state.artist.dayOffset);
  if (!tour) return state;

  const nextStatus = updates.status ?? tour.status ?? 'draft';
  const updated: Tour = {
    ...tour,
    name: updates.name !== undefined ? updates.name.trim() || tour.name : tour.name,
    status: nextStatus,
    active: nextStatus === 'active',
    defaultTransportTier: updates.defaultTransportTier ?? tour.defaultTransportTier ?? 'van',
    defaultLodgingTier: updates.defaultLodgingTier ?? tour.defaultLodgingTier ?? 'standard',
    defaultProductionTier: updates.defaultProductionTier ?? tour.defaultProductionTier ?? 'acoustic',
  };

  return refreshTourPresales({
    ...state,
    activeTour: updated,
  });
}

export function addTourDate(
  state: GameState,
  params: {
    venueId: string;
    dayOffset: number;
    ticketPrice: number;
    transportTier?: TransportTier;
    lodgingTier?: LodgingTier;
    productionTier?: ProductionTier;
  }
): { nextState: GameState; error?: string } {
  const venue = CONCERT_VENUES.find((v) => v.id === params.venueId);
  if (!venue) return { nextState: state, error: 'Salle introuvable.' };

  let tour = normalizeTour(state.activeTour, state.artist.dayOffset);
  if (!tour) {
    tour = {
      id: `tour_${Date.now()}`,
      name: 'Ma Tournée Sur-Mesure',
      scope: 'custom',
      status: 'draft',
      dates: [],
      defaultTransportTier: params.transportTier ?? 'van',
      defaultLodgingTier: params.lodgingTier ?? 'standard',
      defaultProductionTier: params.productionTier ?? 'acoustic',
      totalDates: 0,
      completedDates: 0,
      venueId: venue.id,
      ticketPrice: params.ticketPrice,
      totalAttendance: 0,
      totalRevenue: 0,
      totalExpenses: 0,
      totalProfit: 0,
      active: false,
      createdDayOffset: state.artist.dayOffset,
    };
  }

  const transportTier = params.transportTier ?? tour.defaultTransportTier ?? 'van';
  const lodgingTier = params.lodgingTier ?? tour.defaultLodgingTier ?? 'standard';
  const productionTier = params.productionTier ?? tour.defaultProductionTier ?? 'acoustic';

  const forecast = estimateTourDateForecast(state, {
    venueId: venue.id,
    ticketPrice: params.ticketPrice,
    dayOffset: params.dayOffset,
    transportTier,
    lodgingTier,
    productionTier,
  });

  const newDate: TourDateItem = {
    id: `tdate_${Date.now()}_${Math.floor(Math.random() * 10000)}`,
    venueId: venue.id,
    cityId: venue.cityId,
    venueName: venue.name,
    city: venue.city,
    country: venue.country ?? 'France',
    continent: venue.continent ?? 'Europe',
    showType: venue.showType,
    capacity: venue.capacity,
    dayOffset: params.dayOffset,
    ticketPrice: params.ticketPrice,
    ticketsSold: forecast?.presoldTickets ?? 0,
    status: 'scheduled',
    transportTier,
    lodgingTier,
    productionTier,
    report: null,
  };

  const nextDates = [...(tour.dates ?? []), newDate];
  const updatedTour = recalculateTourMetrics({
    ...tour,
    dates: nextDates,
  });

  return {
    nextState: {
      ...state,
      activeTour: updatedTour,
    },
  };
}

export function updateTourDate(
  state: GameState,
  dateId: string,
  updates: Partial<{
    venueId: string;
    dayOffset: number;
    ticketPrice: number;
    transportTier: TransportTier;
    lodgingTier: LodgingTier;
    productionTier: ProductionTier;
    status: TourDateStatus;
  }>
): GameState {
  const tour = normalizeTour(state.activeTour, state.artist.dayOffset);
  if (!tour || !tour.dates) return state;

  const updatedDates = tour.dates.map((d) => {
    if (d.id !== dateId || d.status === 'played') return d;
    const nextVenue = updates.venueId
      ? CONCERT_VENUES.find((v) => v.id === updates.venueId)
      : undefined;

    const merged: TourDateItem = {
      ...d,
      venueId: nextVenue ? nextVenue.id : d.venueId,
      cityId: nextVenue ? nextVenue.cityId : d.cityId,
      venueName: nextVenue ? nextVenue.name : d.venueName,
      city: nextVenue ? nextVenue.city : d.city,
      country: nextVenue ? nextVenue.country ?? 'France' : d.country,
      continent: nextVenue ? nextVenue.continent ?? 'Europe' : d.continent,
      showType: nextVenue ? nextVenue.showType : d.showType,
      capacity: nextVenue ? nextVenue.capacity : d.capacity,
      dayOffset: updates.dayOffset ?? d.dayOffset,
      ticketPrice: updates.ticketPrice ?? d.ticketPrice,
      transportTier: updates.transportTier ?? d.transportTier,
      lodgingTier: updates.lodgingTier ?? d.lodgingTier,
      productionTier: updates.productionTier ?? d.productionTier,
      status: updates.status ?? d.status,
    };

    const forecast = estimateTourDateForecast(state, {
      venueId: merged.venueId,
      ticketPrice: merged.ticketPrice,
      dayOffset: merged.dayOffset,
      transportTier: merged.transportTier,
      lodgingTier: merged.lodgingTier,
      productionTier: merged.productionTier,
    });

    return {
      ...merged,
      ticketsSold: forecast ? forecast.presoldTickets : merged.ticketsSold,
    };
  });

  return {
    ...state,
    activeTour: recalculateTourMetrics({
      ...tour,
      dates: updatedDates,
    }),
  };
}

export function moveTourDate(
  state: GameState,
  dateId: string,
  direction: 'up' | 'down'
): GameState {
  const tour = normalizeTour(state.activeTour, state.artist.dayOffset);
  if (!tour || !tour.dates) return state;
  const idx = tour.dates.findIndex((d) => d.id === dateId);
  if (idx === -1) return state;
  const targetIdx = direction === 'up' ? idx - 1 : idx + 1;
  if (targetIdx < 0 || targetIdx >= tour.dates.length) return state;
  if (tour.dates[idx].status === 'played' || tour.dates[targetIdx].status === 'played') {
    return state;
  }

  const copy = [...tour.dates];
  const dayA = copy[idx].dayOffset;
  const dayB = copy[targetIdx].dayOffset;
  const [moved] = copy.splice(idx, 1);
  copy.splice(targetIdx, 0, moved);

  // Keep calendar slots aligned with the reordered itinerary
  copy[idx] = { ...copy[idx], dayOffset: dayA };
  copy[targetIdx] = { ...copy[targetIdx], dayOffset: dayB };

  return refreshTourPresales({
    ...state,
    activeTour: {
      ...tour,
      dates: copy,
    },
  });
}

export function reorderTourDates(
  state: GameState,
  orderedUnplayedIds: string[],
  syncCalendarSlots = true
): GameState {
  const tour = normalizeTour(state.activeTour, state.artist.dayOffset);
  if (!tour || !tour.dates) return state;

  const playedDates = tour.dates.filter((d) => d.status === 'played');
  const unplayedDates = tour.dates.filter((d) => d.status !== 'played');
  const byId = new Map(unplayedDates.map((d) => [d.id, d]));

  const reorderedUnplayed: TourDateItem[] = [];
  orderedUnplayedIds.forEach((id) => {
    const found = byId.get(id);
    if (found) {
      reorderedUnplayed.push(found);
      byId.delete(id);
    }
  });
  // Append any unplayed dates that weren't in the supplied list (defensive)
  byId.forEach((d) => reorderedUnplayed.push(d));

  let finalUnplayed = reorderedUnplayed;
  if (syncCalendarSlots && reorderedUnplayed.length > 0) {
    const sortedSlots = reorderedUnplayed
      .map((d) => d.dayOffset)
      .sort((a, b) => a - b);
    finalUnplayed = reorderedUnplayed.map((d, index) => ({
      ...d,
      dayOffset: sortedSlots[index],
    }));
  }

  return refreshTourPresales({
    ...state,
    activeTour: recalculateTourMetrics({
      ...tour,
      dates: [...playedDates, ...finalUnplayed],
    }),
  });
}

export function postponeTourDate(
  state: GameState,
  dateId: string,
  newDayOffset: number
): GameState {
  return updateTourDate(state, dateId, {
    dayOffset: Math.max(state.artist.dayOffset, newDayOffset),
    status: 'postponed',
  });
}

export function removeTourDate(state: GameState, dateId: string): GameState {
  const tour = normalizeTour(state.activeTour, state.artist.dayOffset);
  if (!tour || !tour.dates) return state;
  const target = tour.dates.find((d) => d.id === dateId);
  if (!target || target.status === 'played') return state;

  const updatedDates = tour.dates.filter((d) => d.id !== dateId);
  return {
    ...state,
    activeTour: recalculateTourMetrics({
      ...tour,
      dates: updatedDates,
    }),
  };
}

export function playTourDateById(
  state: GameState,
  dateId?: string
): {
  nextState: GameState;
  log: ConcertLog | null;
  tourFinished: boolean;
  error?: string;
} {
  const tour = normalizeTour(state.activeTour, state.artist.dayOffset);
  if (!tour || !tour.dates || tour.dates.length === 0) {
    return {
      nextState: state,
      log: null,
      tourFinished: false,
      error: 'Aucune date programmée dans cette tournée.',
    };
  }

  const targetDate = dateId
    ? tour.dates.find((d) => d.id === dateId && (d.status === 'scheduled' || d.status === 'postponed'))
    : tour.dates.find((d) => d.status === 'scheduled' || d.status === 'postponed');

  if (!targetDate) {
    return {
      nextState: state,
      log: null,
      tourFinished: false,
      error: 'Toutes les dates programmées ont déjà été jouées. Ajoute une nouvelle date ou clôture la tournée.',
    };
  }

  const venue = CONCERT_VENUES.find((v) => v.id === targetDate.venueId);
  if (!venue) {
    return { nextState: state, log: null, tourFinished: false, error: 'Salle introuvable.' };
  }

  const { nextState, log, error } = executeConcertInternal(state, {
    venue,
    ticketPrice: targetDate.ticketPrice,
    dayOffset: targetDate.dayOffset,
    transportTier: targetDate.transportTier,
    lodgingTier: targetDate.lodgingTier,
    productionTier: targetDate.productionTier,
    tourId: tour.id,
    tourName: tour.name,
  });

  if (error || !log) {
    return { nextState: state, log: null, tourFinished: false, error };
  }

  const updatedDates: TourDateItem[] = tour.dates.map((d) =>
    d.id === targetDate.id
      ? {
          ...d,
          status: 'played',
          ticketsSold: log.attendance,
          report: log,
        }
      : d
  );

  const updatedTour = recalculateTourMetrics({
    ...tour,
    status: 'active',
    active: true,
    dates: updatedDates,
  });

  const remaining = updatedDates.filter(
    (d) => d.status === 'scheduled' || d.status === 'postponed'
  ).length;

  return {
    nextState: {
      ...nextState,
      activeTour: updatedTour,
    },
    log,
    tourFinished: remaining === 0,
  };
}

export function completeAndArchiveTour(state: GameState): GameState {
  const tour = normalizeTour(state.activeTour, state.artist.dayOffset);
  if (!tour) return state;

  const archived: Tour = recalculateTourMetrics({
    ...tour,
    status: 'completed',
    active: false,
  });

  const nextNotifs =
    archived.completedDates > 0
      ? addNotification(state.notifications, {
          week: state.artist.weeksActive,
          title: `Tournée archivée : ${archived.name}`,
          message: `${archived.completedDates} date(s) · ${archived.totalAttendance.toLocaleString('fr-FR')} spectateurs · Bénéfice ${archived.totalProfit >= 0 ? '+' : ''}${archived.totalProfit.toLocaleString('fr-FR')} €.`,
          category: 'live',
          targetTab: 'apps',
          targetApp: 'tours',
        })
      : state.notifications;

  return {
    ...state,
    activeTour: null,
    tourHistory: archived.completedDates > 0 ? [archived, ...(state.tourHistory ?? [])] : state.tourHistory ?? [],
    notifications: nextNotifs,
  };
}

export function startNewTour(
  state: GameState,
  params: { name: string; scope: 'locale' | 'nationale' | 'internationale'; venueId: string; ticketPrice: number }
): { nextState: GameState; error?: string } {
  const created = createCustomTour(state, {
    name: params.name.trim() || `Tournée ${params.scope}`,
    defaultTransportTier: params.scope === 'internationale' ? 'flight' : params.scope === 'nationale' ? 'bus' : 'van',
    defaultLodgingTier: params.scope === 'internationale' ? 'luxury' : params.scope === 'nationale' ? 'comfort' : 'standard',
    defaultProductionTier: params.scope === 'internationale' ? 'arena_show' : params.scope === 'nationale' ? 'club' : 'acoustic',
  });
  if (created.error) return created;

  const count = params.scope === 'locale' ? 3 : params.scope === 'nationale' ? 5 : 8;
  let working = updateCustomTourSettings(created.nextState, { status: 'active' });
  for (let i = 0; i < count; i += 1) {
    const added = addTourDate(working, {
      venueId: params.venueId,
      dayOffset: state.artist.dayOffset + i * 3,
      ticketPrice: params.ticketPrice,
    });
    working = added.nextState;
  }
  return { nextState: working };
}

export function playNextTourDate(state: GameState): {
  nextState: GameState;
  log: ConcertLog | null;
  tourFinished: boolean;
  error?: string;
} {
  return playTourDateById(state);
}

export function unlockMerchItem(state: GameState, merchId: string): GameState {
  const item = state.merch.find((m) => m.id === merchId);
  if (!item || item.unlocked || state.artist.cash < item.unlockCost) {
    return state;
  }
  return {
    ...state,
    artist: {
      ...state.artist,
      cash: state.artist.cash - item.unlockCost,
      totalExpenses: state.artist.totalExpenses + item.unlockCost,
    },
    merch: state.merch.map((m) => (m.id === merchId ? { ...m, unlocked: true } : m)),
    finances: addFinanceEntry(state.finances, {
      week: state.artist.weeksActive,
      label: `Lancement Merch : ${item.name}`,
      category: 'merch',
      amount: -item.unlockCost,
    }),
  };
}

export function hireStaffMember(state: GameState, staffId: string): GameState {
  const staff = STAFF_CATALOG.find((s) => s.id === staffId);
  if (
    !staff ||
    state.artist.hiredStaffIds.includes(staffId) ||
    state.artist.cash < staff.hireCost ||
    state.artist.monthlyListeners < staff.minMonthlyListeners
  ) {
    return state;
  }

  return {
    ...state,
    artist: {
      ...state.artist,
      cash: state.artist.cash - staff.hireCost,
      totalExpenses: state.artist.totalExpenses + staff.hireCost,
      hiredStaffIds: [...state.artist.hiredStaffIds, staffId],
    },
    finances: addFinanceEntry(state.finances, {
      week: state.artist.weeksActive,
      label: `Recrutement ${staff.role} (${staff.name})`,
      category: 'label',
      amount: -staff.hireCost,
    }),
  };
}

export function signLabelContract(state: GameState, labelId: string): GameState {
  const offer = LABEL_OFFERS.find((l) => l.id === labelId);
  if (!offer || state.artist.labelId === labelId) return state;
  if (state.artist.monthlyListeners < offer.minMonthlyListeners) return state;

  let nextFinances = state.finances;
  if (offer.signingAdvance > 0) {
    nextFinances = addFinanceEntry(nextFinances, {
      week: state.artist.weeksActive,
      label: `Avance signature ${offer.name}`,
      category: 'label',
      amount: offer.signingAdvance,
    });
  }

  return {
    ...state,
    artist: {
      ...state.artist,
      labelId: offer.id,
      cash: state.artist.cash + offer.signingAdvance,
      totalRevenue: state.artist.totalRevenue + offer.signingAdvance,
      hype: clamp(state.artist.hype + offer.weeklyPromoSupport, 0, 100),
      fame: clamp(state.artist.fame + (offer.signingAdvance > 0 ? 6 : 0), 0, 100),
    },
    finances: nextFinances,
    notifications: addNotification(state.notifications, {
      week: state.artist.weeksActive,
      title: `Contrat signé : ${offer.name}`,
      message:
        offer.signingAdvance > 0
          ? `Avance de ${offer.signingAdvance.toLocaleString('fr-FR')} € créditée.`
          : 'Retour en autoproduction totale.',
      category: 'finance',
      targetTab: 'apps',
      targetApp: 'labels',
    }),
  };
}

export function publishBuzzPost(state: GameState, content: string): GameState {
  const trimmed = content.trim();
  if (!trimmed) return state;

  const viralRoll = Math.random();
  const isViral = viralRoll > 0.84;
  const reachFactor = isViral ? 2.8 : 0.65 + Math.random() * 0.7;

  const likes = Math.max(8, Math.round((state.artist.fans * 0.14 + 12) * reachFactor));
  const comments = Math.max(1, Math.round(likes * 0.09));
  const shares = Math.max(0, Math.round(likes * 0.12));

  const fansGained = Math.max(3, Math.round(likes * 0.08));
  const hypeGain = isViral ? 7 : 2;

  const fanReplies = isViral
    ? [
        { user: '@claire_musique', text: 'Ce post tourne partout sur AllGram !' },
        { user: '@theo_wav', text: 'L’énergie est incroyable en ce moment.' },
      ]
    : [{ user: '@fan_locale', text: 'Toujours présent dès la première heure.' }];

  const handle = `@${state.artist.stageName.toLowerCase().replace(/[^a-z0-9]/g, '') || 'artiste'}`;

  const newPost: BuzzPost = {
    id: `buzz_p_${Date.now()}`,
    authorName: state.artist.stageName,
    authorHandle: handle,
    isPlayer: true,
    week: state.artist.weeksActive,
    tag: isViral ? 'Tendance AllGram' : 'Publication',
    content: trimmed,
    likes,
    comments,
    shares,
    likedByPlayer: false,
    sampleComments: fanReplies,
  };

  return {
    ...state,
    artist: {
      ...state.artist,
      fans: state.artist.fans + fansGained,
      hype: clamp(state.artist.hype + hypeGain, 0, 100),
    },
    buzzPosts: [newPost, ...state.buzzPosts].slice(0, 25),
  };
}

export function toggleLikeBuzzPost(state: GameState, postId: string): GameState {
  return {
    ...state,
    buzzPosts: state.buzzPosts.map((p) => {
      if (p.id !== postId) return p;
      const nextLiked = !p.likedByPlayer;
      return {
        ...p,
        likedByPlayer: nextLiked,
        likes: p.likes + (nextLiked ? 1 : -1),
      };
    }),
  };
}

export function startOrOpenChatThread(state: GameState, contactId: string): GameState {
  const existing = state.chatThreads.find((t) => t.contactId === contactId);
  if (existing) {
    return {
      ...state,
      chatThreads: state.chatThreads.map((t) =>
        t.id === existing.id ? { ...t, unread: false } : t
      ),
    };
  }
  const contact = CHAT_CONTACTS.find((c) => c.id === contactId);
  if (!contact) return state;

  const thread: ChatThread = {
    id: `thread_${contactId}`,
    contactId: contact.id,
    contactName: contact.name,
    contactRole: contact.role,
    contactHandle: contact.handle,
    unread: false,
    messages: [
      {
        id: `msg_init_${Date.now()}`,
        sender: 'contact',
        text: contact.greeting,
        timeLabel: formatShortDate(state.artist.dayOffset),
      },
    ],
  };

  return {
    ...state,
    chatThreads: [thread, ...state.chatThreads],
  };
}

export function sendChatMessage(
  state: GameState,
  threadId: string,
  text: string
): GameState {
  const trimmed = text.trim();
  if (!trimmed) return state;
  const thread = state.chatThreads.find((t) => t.id === threadId);
  if (!thread) return state;

  const dateLabel = formatShortDate(state.artist.dayOffset);
  const playerMsg = {
    id: `msg_p_${Date.now()}`,
    sender: 'player' as const,
    text: trimmed,
    timeLabel: dateLabel,
  };

  // Context-aware reply based on real GameState!
  let replyText = 'Bien reçu ! On garde le cap pour la suite.';
  const lower = trimmed.toLowerCase();

  if (thread.contactId === 'contact_manager') {
    if (state.songs.filter((s) => s.released).length === 0) {
      replyText = `Conseil priorité : enregistre et publie ton premier single dans Music pour lancer tes revenus Alltify.`;
    } else if (lower.includes('concert') || lower.includes('tournée') || lower.includes('scène')) {
      replyText = `Avec ${state.artist.fans.toLocaleString('fr-FR')} fans, vise une salle adaptée et surveille ton énergie (${state.artist.energy}/100).`;
    } else {
      replyText = `Tes auditeurs mensuels sont à ${state.artist.monthlyListeners.toLocaleString('fr-FR')}. Une campagne AllGram ou un clip sur AllTub pourrait booster ta popularité (${state.artist.hype}/100).`;
    }
  } else if (thread.contactId === 'contact_kaelen' || thread.contactId === 'contact_naya') {
    if (state.artist.fame >= 30 || state.artist.fans >= 10_000) {
      replyText = `Tu commences à peser lourd dans les charts ! Si une collab passe dans tes événements, fonce.`;
    } else {
      replyText = `Gros respect pour le taf en studio. Monte encore ton public et on se fera un morceau ensemble.`;
    }
  } else if (thread.contactId === 'contact_starfeed') {
    const latest = state.songs.find((s) => s.released);
    replyText = latest
      ? `On suit déjà « ${latest.title} » de près. Continue d’alimenter AllGram et AllTub !`
      : `Dès que tu sors un projet, la rédaction couvrira ton actualité.`;
  } else if (thread.contactId === 'contact_fanclub') {
    replyText = `Merci pour la proximité ! Toute la commu est à fond derrière ${state.artist.stageName}.`;
  }

  const replyMsg = {
    id: `msg_c_${Date.now() + 1}`,
    sender: 'contact' as const,
    text: replyText,
    timeLabel: dateLabel,
  };

  return {
    ...state,
    artist: {
      ...state.artist,
      reputation: clamp(state.artist.reputation + 1, 0, 100),
    },
    chatThreads: state.chatThreads.map((t) =>
      t.id === threadId
        ? { ...t, unread: false, messages: [...t.messages, playerMsg, replyMsg] }
        : t
    ),
  };
}

export function computeMissions(state: GameState): Mission[] {
  const maxSongStreams = state.songs.reduce((max, s) => Math.max(max, s.totalStreams), 0);
  const topChartRank = state.charts
    .filter((c) => c.isPlayer)
    .reduce((best, c) => Math.min(best, c.rank), 999);

  const defs: Array<Omit<Mission, 'completed' | 'claimed'>> = [
    {
      id: 'm_first_song',
      title: 'Première session studio',
      description: 'Enregistre ton premier morceau dans Music.',
      rewardCash: 350,
      rewardHype: 5,
      targetValue: 1,
      currentValue: Math.min(1, state.songs.length),
    },
    {
      id: 'm_first_release',
      title: 'Première sortie officielle',
      description: 'Publie un premier single sur Alltify.',
      rewardCash: 500,
      rewardHype: 8,
      targetValue: 1,
      currentValue: Math.min(1, state.songs.filter((s) => s.released).length),
    },
    {
      id: 'm_first_concert',
      title: 'Baptême de la scène',
      description: 'Joue ton premier concert ou showcase.',
      rewardCash: 650,
      rewardHype: 8,
      targetValue: 1,
      currentValue: Math.min(1, state.artist.concertsPlayed),
    },
    {
      id: 'm_1000_fans',
      title: 'Cap des 1 000 fans',
      description: 'Construis une base de 1 000 fans fidèles.',
      rewardCash: 1200,
      rewardHype: 10,
      targetValue: 1000,
      currentValue: Math.min(1000, state.artist.fans),
    },
    {
      id: 'm_top_200',
      title: 'Entrée dans le Top 200 Global',
      description: 'Place un titre dans le classement mondial Chartz.',
      rewardCash: 1800,
      rewardHype: 12,
      targetValue: 1,
      currentValue: topChartRank <= 200 ? 1 : 0,
    },
    {
      id: 'm_first_project',
      title: 'Premier Album ou EP',
      description: 'Publie un EP, Mixtape, Album ou Deluxe.',
      rewardCash: 4500,
      rewardHype: 16,
      targetValue: 1,
      currentValue: Math.min(1, state.projects.filter((p) => p.format !== 'single').length),
    },
    {
      id: 'm_cert_gold',
      title: 'Disque d’Or (100k écoutes)',
      description: 'Atteins 100 000 écoutes cumulées sur un titre.',
      rewardCash: 8000,
      rewardHype: 20,
      targetValue: 100_000,
      currentValue: Math.min(100_000, maxSongStreams),
    },
  ];

  return defs.map((d) => ({
    ...d,
    completed: d.currentValue >= d.targetValue,
    claimed: state.claimedMissionIds.includes(d.id),
  }));
}

export function claimMissionReward(state: GameState, missionId: string): GameState {
  const missions = computeMissions(state);
  const target = missions.find((m) => m.id === missionId);
  if (!target || !target.completed || target.claimed) return state;

  return {
    ...state,
    artist: {
      ...state.artist,
      cash: state.artist.cash + target.rewardCash,
      totalRevenue: state.artist.totalRevenue + target.rewardCash,
      hype: clamp(state.artist.hype + target.rewardHype, 0, 100),
      fame: clamp(state.artist.fame + 2, 0, 100),
    },
    claimedMissionIds: [...state.claimedMissionIds, missionId],
    finances: addFinanceEntry(state.finances, {
      week: state.artist.weeksActive,
      label: `Objectif atteint : ${target.title}`,
      category: 'event',
      amount: target.rewardCash,
    }),
  };
}

export function applyEventChoice(state: GameState, choice: EventChoice): GameState {
  const event = state.pendingEvent;
  if (!event) return state;

  const delta = choice.delta;
  const cashCost = choice.costCash ?? 0;
  const energyCost = choice.costEnergy ?? 0;

  let nextSongs = [...state.songs];
  let extraStreams = 0;

  if (delta.activeTrackStreamMultiplier && nextSongs.length > 0) {
    const firstReleasedIdx = nextSongs.findIndex((s) => s.released);
    if (firstReleasedIdx !== -1) {
      const target = nextSongs[firstReleasedIdx];
      const boostedWeekly = Math.round(target.weeklyStreams * delta.activeTrackStreamMultiplier);
      const added = Math.max(0, boostedWeekly - target.weeklyStreams);
      extraStreams += added;
      nextSongs[firstReleasedIdx] = {
        ...target,
        weeklyStreams: boostedWeekly,
        dailyStreams: Math.round(boostedWeekly / 7),
        totalStreams: target.totalStreams + added,
        bestWeekStreams: Math.max(target.bestWeekStreams, boostedWeekly),
        viralBoostWeeks: 2,
        lifecyclePhase: 'redecouverte',
      };
    }
  }

  if (delta.autoReleaseCollabTitle) {
    const collabStreams = Math.round(
      (state.artist.fans * 2.1 + 4200) * (1 + state.artist.hype / 100)
    );
    extraStreams += collabStreams;
    const collabSong: Song = {
      id: `song_collab_${Date.now()}`,
      title: delta.autoReleaseCollabTitle,
      genre: state.artist.genre,
      mood: 'Énergique',
      theme: 'Ambition',
      vocalStyle: 'Duo studio',
      quality: clamp(Math.round(74 + Math.random() * 18), 70, 96),
      studioName: 'Session Collaboration VIP',
      featuringArtist: event.contextSubject ?? 'Artiste Invité',
      released: true,
      releaseWeek: state.artist.weeksActive,
      releaseDayOffset: state.artist.dayOffset,
      weeklyStreams: collabStreams,
      dailyStreams: Math.round(collabStreams / 7),
      totalStreams: collabStreams,
      streamHistory: [collabStreams],
      bestWeekStreams: collabStreams,
      revenueEarned: 0,
      peakChartPos: null,
      currentChartPos: null,
      promoApplied: ['collab_event'],
      promoCount: 0,
      hasClip: false,
      clipStyle: null,
      certification: computeCertification(collabStreams),
      lifecyclePhase: 'sortie',
      viralBoostWeeks: 2,
    };
    nextSongs = [collabSong, ...nextSongs];
  }

  const nextSkills: ArtistSkills = { ...state.artist.skills };
  if (delta.skillBoost) {
    (Object.keys(delta.skillBoost) as Array<keyof ArtistSkills>).forEach((k) => {
      const amount = delta.skillBoost?.[k] ?? 0;
      nextSkills[k] = clamp(nextSkills[k] + amount, 1, 99);
    });
  }

  const cashGain = delta.cash ?? 0;
  const cashDelta = cashGain - cashCost;
  const fansDelta = delta.fans ?? 0;
  const hypeDelta = delta.hype ?? 0;

  let nextFinances = state.finances;
  if (cashDelta !== 0) {
    nextFinances = addFinanceEntry(nextFinances, {
      week: state.artist.weeksActive,
      label: `Événement : ${event.title}`,
      category: 'event',
      amount: cashDelta,
    });
  }

  const historyEntry = {
    id: `hist_${event.id}`,
    week: state.artist.weeksActive,
    title: event.title,
    category: event.category,
    chosenLabel: choice.label,
    outcomeText: choice.outcomeText,
    sentimentResult: choice.sentimentResult,
    cashDelta,
    fansDelta,
    hypeDelta,
  };

  const cooldown = getEventCooldown(event.templateId);

  return recalculateCharts({
    ...state,
    artist: {
      ...state.artist,
      cash: Math.max(0, state.artist.cash + cashDelta),
      totalRevenue: state.artist.totalRevenue + (cashGain > 0 ? cashGain : 0),
      totalExpenses: state.artist.totalExpenses + cashCost,
      energy: clamp(state.artist.energy - energyCost + (delta.energy ?? 0), 0, state.artist.maxEnergy),
      fans: Math.max(50, state.artist.fans + fansDelta),
      hype: clamp(state.artist.hype + hypeDelta, 0, 100),
      fame: clamp(state.artist.fame + (delta.fame ?? (hypeDelta > 0 ? 2 : 0)), 0, 100),
      reputation: clamp(state.artist.reputation + (delta.reputation ?? 0), 0, 100),
      skills: nextSkills,
      totalStreams: state.artist.totalStreams + extraStreams,
    },
    songs: nextSongs,
    streamNews: addStreamNews(state.streamNews, {
      dateLabel: formatShortDate(state.artist.dayOffset),
      title: event.title,
      detail: choice.outcomeText,
      category: 'industry',
    }),
    finances: nextFinances,
    pendingEvent: null,
    eventHistory: [historyEntry, ...state.eventHistory].slice(0, 30),
    cooldownEventTemplates: {
      ...state.cooldownEventTemplates,
      [event.templateId]: state.artist.weeksActive + cooldown,
    },
    lastEventWeek: state.artist.weeksActive,
  });
}

export function recalculateCharts(state: GameState): GameState {
  const prevRanks = new Map<string, number>();
  state.charts.forEach((entry) => {
    prevRanks.set(entry.id, entry.rank);
  });

  const rivalPool: ChartEntry[] = state.charts
    .filter((c) => !c.isPlayer)
    .map((c) => {
      const drift = 0.94 + Math.random() * 0.12;
      return {
        ...c,
        previousRank: c.rank,
        weeklyStreams: Math.max(2_500, Math.round(c.weeklyStreams * drift)),
        weeksOnChart: c.weeksOnChart + 1,
      };
    });

  const playerEntries: ChartEntry[] = state.songs
    .filter((s) => s.released && s.weeklyStreams >= 2_500)
    .map((s) => ({
      id: s.id,
      rank: 0,
      previousRank: prevRanks.get(s.id) ?? null,
      title: s.featuringArtist ? `${s.title} (feat. ${s.featuringArtist})` : s.title,
      artistName: state.artist.stageName,
      genre: s.genre,
      weeklyStreams: s.weeklyStreams,
      isPlayer: true,
      weeksOnChart: Math.max(1, state.artist.weeksActive - (s.releaseWeek ?? state.artist.weeksActive) + 1),
      coverTone: COVER_TONES[0],
    }));

  const combined = [...playerEntries, ...rivalPool]
    .sort((a, b) => b.weeklyStreams - a.weeklyStreams)
    .slice(0, 200)
    .map((entry, idx) => ({
      ...entry,
      rank: idx + 1,
    }));

  const rankMap = new Map<string, number>();
  combined.forEach((c) => {
    if (c.isPlayer) rankMap.set(c.id, c.rank);
  });

  const updatedSongs = state.songs.map((s) => {
    const newRank = rankMap.get(s.id) ?? null;
    const peak =
      newRank !== null
        ? s.peakChartPos !== null
          ? Math.min(s.peakChartPos, newRank)
          : newRank
        : s.peakChartPos;
    return {
      ...s,
      currentChartPos: newRank,
      peakChartPos: peak,
    };
  });

  return {
    ...state,
    songs: updatedSongs,
    charts: combined,
  };
}

export function advanceSingleDay(state: GameState): GameState {
  const nextDayOffset = state.artist.dayOffset + 1;
  const crossesWeek = nextDayOffset % 7 === 0;

  if (crossesWeek) {
    const nextWeekState = advanceSingleWeek({
      ...state,
      artist: { ...state.artist, dayOffset: nextDayOffset - 1 },
    });
    return {
      ...nextWeekState,
      artist: { ...nextWeekState.artist, dayOffset: nextDayOffset },
    };
  }

  // Daily stream tick
  const label = LABEL_OFFERS.find((l) => l.id === state.artist.labelId) ?? LABEL_OFFERS[0];
  let dayStreams = 0;
  const updatedSongs = state.songs.map((s) => {
    if (!s.released) return s;
    const dStreams = Math.max(25, Math.round((s.weeklyStreams / 7) * (0.9 + Math.random() * 0.22)));
    dayStreams += dStreams;
    return {
      ...s,
      dailyStreams: dStreams,
      totalStreams: s.totalStreams + dStreams,
      revenueEarned: s.revenueEarned + dStreams * 0.0034 * label.royaltyRate,
      certification: computeCertification(s.totalStreams + dStreams),
    };
  });

  const dayRevenue = Math.round(dayStreams * 0.0034 * label.royaltyRate);
  const fansGained = Math.round(dayStreams * 0.015 + state.artist.hype * 0.35);

  let nextNews = state.streamNews;
  if (dayStreams > 0) {
    const topSong = [...updatedSongs]
      .filter((s) => s.released)
      .sort((a, b) => b.dailyStreams - a.dailyStreams)[0];
    nextNews = addStreamNews(nextNews, {
      dateLabel: formatShortDate(nextDayOffset),
      title: topSong ? `« ${topSong.title} » en rotation` : 'Bilan du jour sur Alltify',
      detail: `+${dayStreams.toLocaleString('fr-FR')} écoutes aujourd’hui · +${fansGained.toLocaleString('fr-FR')} fans.`,
      category: 'streams',
      deltaText: dayRevenue > 0 ? `+${dayRevenue} €` : undefined,
    });
  } else {
    const rival = RIVAL_ARTISTS[nextDayOffset % RIVAL_ARTISTS.length];
    nextNews = addStreamNews(nextNews, {
      dateLabel: formatShortDate(nextDayOffset),
      title: `${rival.name} grimpe sur Alltify`,
      detail: `Son titre « ${rival.titles[0]} » cumule de nouvelles écoutes dans les playlists du jour.`,
      category: 'industry',
    });
  }

  return refreshTourPresales({
    ...state,
    artist: {
      ...state.artist,
      dayOffset: nextDayOffset,
      cash: state.artist.cash + dayRevenue,
      totalRevenue: state.artist.totalRevenue + dayRevenue,
      energy: clamp(state.artist.energy + 12, 0, state.artist.maxEnergy),
      fans: state.artist.fans + fansGained,
      monthlyListeners: Math.round((state.artist.fans + fansGained) * 1.4 + dayStreams * 2.5),
      totalStreams: state.artist.totalStreams + dayStreams,
    },
    songs: updatedSongs,
    streamNews: nextNews,
  });
}

export function advanceSingleWeek(state: GameState): GameState {
  const nextWeek = state.artist.weeksActive + 1;
  const nextDayOffset = state.artist.dayOffset + 7;
  const label = LABEL_OFFERS.find((l) => l.id === state.artist.labelId) ?? LABEL_OFFERS[0];
  const hasManager = state.artist.hiredStaffIds.includes('manager');
  const hasPublicist = state.artist.hiredStaffIds.includes('publicist');

  let weekStreamsTotal = 0;
  const newCerts: Array<{ title: string; level: CertificationLevel }> = [];

  const updatedSongs = state.songs.map((song) => {
    if (!song.released) return song;
    const age = Math.max(0, nextWeek - (song.releaseWeek ?? nextWeek));
    const decayRate = age <= 2 ? 1.03 : age <= 5 ? 0.92 : age <= 8 ? 0.84 : 0.74;
    const hypeLift = 1 + state.artist.hype / 450;
    const viralMultiplier = song.viralBoostWeeks > 0 ? 1.25 : 1.0;

    const nextWeeklyStreams = Math.max(
      140,
      Math.round(song.weeklyStreams * decayRate * hypeLift * viralMultiplier * (0.94 + Math.random() * 0.12))
    );
    const nextTotal = song.totalStreams + nextWeeklyStreams;
    const nextCert = computeCertification(nextTotal);
    if (nextCert !== 'none' && nextCert !== song.certification) {
      newCerts.push({ title: song.title, level: nextCert });
    }

    let nextPhase: SongLifecyclePhase = 'stabilisation';
    if (song.viralBoostWeeks > 0 && age > 3) {
      nextPhase = 'redecouverte';
    } else if (nextWeeklyStreams > song.weeklyStreams * 1.04) {
      nextPhase = 'croissance';
    } else if (nextWeeklyStreams >= song.bestWeekStreams * 0.9) {
      nextPhase = 'pic';
    } else if (age > 6) {
      nextPhase = 'declin';
    }

    const songRevenue = nextWeeklyStreams * 0.0034 * label.royaltyRate * (hasManager ? 1.1 : 1);
    weekStreamsTotal += nextWeeklyStreams;

    return {
      ...song,
      weeklyStreams: nextWeeklyStreams,
      dailyStreams: Math.round(nextWeeklyStreams / 7),
      totalStreams: nextTotal,
      streamHistory: [...song.streamHistory, nextWeeklyStreams].slice(-12),
      bestWeekStreams: Math.max(song.bestWeekStreams, nextWeeklyStreams),
      revenueEarned: song.revenueEarned + songRevenue,
      certification: nextCert,
      lifecyclePhase: nextPhase,
      viralBoostWeeks: Math.max(0, song.viralBoostWeeks - 1),
    };
  });

  const updatedProjects = state.projects.map((proj) => {
    const tracks = updatedSongs.filter((s) => s.projectId === proj.id);
    const totalStreams = tracks.reduce((sum, t) => sum + t.totalStreams, 0);
    const revenueEarned = tracks.reduce((sum, t) => sum + t.revenueEarned, 0);
    return {
      ...proj,
      totalStreams,
      revenueEarned,
      certification: computeCertification(totalStreams),
    };
  });

  // Update AllTub videos views
  const updatedVideos = state.allTubVideos.map((v) => ({
    ...v,
    views: v.views + Math.round(v.views * (v.isPlayer ? 0.08 : 0.03)),
    likes: v.likes + Math.round(v.views * 0.004),
  }));

  const streamingRevenue = Math.round(
    weekStreamsTotal * 0.0034 * label.royaltyRate * (hasManager ? 1.1 : 1)
  );

  let merchRevenue = 0;
  const updatedMerch = state.merch.map((item) => {
    if (!item.unlocked) return item;
    const conversion = (state.artist.fans / 1700) * (0.7 + state.artist.hype / 100);
    const sold = Math.max(1, Math.round(conversion * (0.7 + Math.random() * 0.6)));
    merchRevenue += sold * item.unitMargin;
    return { ...item, unitsSold: item.unitsSold + sold };
  });

  const staffSalaries = STAFF_CATALOG.filter((s) =>
    state.artist.hiredStaffIds.includes(s.id)
  ).reduce((sum, s) => sum + s.weeklySalary, 0);

  const upkeepCost = Math.round(110 + Math.min(4000, state.artist.fans * 0.0035) + staffSalaries);
  const netCashDelta = streamingRevenue + merchRevenue - upkeepCost;
  const fansGained = Math.round(weekStreamsTotal * 0.015 + state.artist.hype * 2.4);

  const nextFans = state.artist.fans + fansGained;
  const monthlyListeners = Math.round(nextFans * 1.4 + weekStreamsTotal * 0.38);

  let nextFinances = state.finances;
  if (streamingRevenue > 0) {
    nextFinances = addFinanceEntry(nextFinances, {
      week: nextWeek,
      label: `Revenus Alltify (${weekStreamsTotal.toLocaleString('fr-FR')} écoutes)`,
      category: 'streaming',
      amount: streamingRevenue,
    });
  }
  if (merchRevenue > 0) {
    nextFinances = addFinanceEntry(nextFinances, {
      week: nextWeek,
      label: 'Ventes Boutique & Merchandising',
      category: 'merch',
      amount: merchRevenue,
    });
  }
  nextFinances = addFinanceEntry(nextFinances, {
    week: nextWeek,
    label: staffSalaries > 0 ? 'Frais de vie & salaires équipe' : 'Frais quotidiens & studio',
    category: 'label',
    amount: -upkeepCost,
  });

  let nextNotifs = state.notifications;
  newCerts.forEach((c) => {
    nextNotifs = addNotification(nextNotifs, {
      week: nextWeek,
      title: `Certification ${c.level.toUpperCase()}`,
      message: `« ${c.title} » franchit un nouveau palier historique.`,
      category: 'music',
      targetTab: 'apps',
      targetApp: 'awards',
    });
  });

  let nextBuzzPosts = state.buzzPosts;
  if (nextWeek % 2 === 0) {
    const rival = RIVAL_ARTISTS[nextWeek % RIVAL_ARTISTS.length];
    const rivalLines = [
      `Nouvelle semaine en studio. On prépare la suite sur Alltify.`,
      `Merci pour votre soutien sur « ${rival.titles[0]} » cette semaine.`,
      `Annonce spéciale bientôt disponible pour la tournée d’automne.`,
    ];
    nextBuzzPosts = [
      {
        id: `buzz_r_${nextWeek}`,
        authorName: rival.name,
        authorHandle: rival.handle,
        isPlayer: false,
        isRival: true,
        week: nextWeek,
        tag: 'Actu Artiste',
        content: rivalLines[nextWeek % rivalLines.length],
        likes: Math.round(rival.fameLevel * 180),
        comments: Math.round(rival.fameLevel * 12),
        shares: Math.round(rival.fameLevel * 24),
        likedByPlayer: false,
        sampleComments: [{ user: '@allstarz_fan', text: 'Toujours présent au rendez-vous !' }],
      },
      ...nextBuzzPosts,
    ].slice(0, 25);
  }

  let nextNews = state.streamNews;
  nextNews = addStreamNews(nextNews, {
    dateLabel: formatShortDate(nextDayOffset),
    title:
      weekStreamsTotal > 0
        ? `Bilan hebdo : +${weekStreamsTotal.toLocaleString('fr-FR')} écoutes`
        : 'Rapport hebdomadaire Chartz',
    detail:
      weekStreamsTotal > 0
        ? `Tes titres génèrent ${streamingRevenue.toLocaleString('fr-FR')} € cette semaine sur Alltify.`
        : 'Enregistre et publie ton premier single pour entrer dans le classement.',
    category: 'streams',
    deltaText: weekStreamsTotal > 0 ? `+${streamingRevenue} €` : undefined,
  });

  const newAwards: AwardTrophy[] = [...state.awards];
  if (nextWeek % 52 === 0 && updatedSongs.some((s) => s.released)) {
    const bestSong = [...updatedSongs]
      .filter((s) => s.released)
      .sort((a, b) => b.totalStreams - a.totalStreams)[0];
    if (bestSong && bestSong.totalStreams >= 45_000) {
      const year = Math.floor(nextWeek / 52);
      const awardTitle =
        bestSong.peakChartPos && bestSong.peakChartPos <= 3
          ? 'Song of the Year'
          : 'Best New Artist';
      newAwards.push({
        id: `award_${year}_${Date.now()}`,
        year,
        ceremony: 'All Star Awards',
        title: awardTitle,
        category: bestSong.peakChartPos && bestSong.peakChartPos <= 3 ? 'Grand Prix' : 'Révélation',
        workTitle: bestSong.title,
      });
      nextNotifs = addNotification(nextNotifs, {
        week: nextWeek,
        title: `Trophée remporté : ${awardTitle}`,
        message: `Récompensé aux All Star Awards pour « ${bestSong.title} » !`,
        category: 'event',
        targetTab: 'apps',
        targetApp: 'awards',
      });
    }
  }

  const publicistHype = hasPublicist ? 3 : 0;
  const fameGain = weekStreamsTotal >= 25_000 ? 2 : weekStreamsTotal > 0 ? 1 : 0;

  let nextState: GameState = {
    ...state,
    artist: {
      ...state.artist,
      dayOffset: nextDayOffset,
      weeksActive: nextWeek,
      cash: Math.max(0, state.artist.cash + netCashDelta),
      totalRevenue: state.artist.totalRevenue + streamingRevenue + merchRevenue,
      totalExpenses: state.artist.totalExpenses + upkeepCost,
      energy: clamp(state.artist.energy + 44, 0, state.artist.maxEnergy),
      hype: clamp(state.artist.hype - 3 + publicistHype + Math.round(label.weeklyPromoSupport * 0.15), 5, 100),
      fame: clamp(state.artist.fame + fameGain, 0, 100),
      fans: nextFans,
      monthlyListeners,
      totalStreams: state.artist.totalStreams + weekStreamsTotal,
    },
    songs: updatedSongs,
    projects: updatedProjects,
    allTubVideos: updatedVideos,
    merch: updatedMerch,
    buzzPosts: nextBuzzPosts,
    streamNews: nextNews,
    finances: nextFinances,
    notifications: nextNotifs,
    awards: newAwards,
  };

  nextState = recalculateCharts(nextState);

  const playerTopChart = nextState.charts.find((c) => c.isPlayer);
  const chartHighlight = playerTopChart
    ? `« ${playerTopChart.title} » est n°${playerTopChart.rank} sur Chartz`
    : null;

  const triggeredEvent = maybeTriggerRandomEvent(nextState);
  if (triggeredEvent) {
    nextState = {
      ...nextState,
      notifications: addNotification(nextState.notifications, {
        week: nextWeek,
        title: `Nouvel événement : ${triggeredEvent.title}`,
        message: 'Une décision importante attend ta réponse.',
        category: 'event',
        targetTab: 'accueil',
      }),
    };
  }

  const summary: WeeklySummary = {
    week: nextWeek,
    streamsGained: weekStreamsTotal,
    streamingRevenue,
    merchRevenue,
    upkeepCost,
    netCashDelta,
    fansGained,
    newCertifications: newCerts,
    chartHighlight,
    triggeredEventTitle: triggeredEvent ? triggeredEvent.title : null,
  };

  nextState = refreshTourPresales(nextState);

  return {
    ...nextState,
    pendingEvent: triggeredEvent,
    lastWeeklySummary: summary,
  };
}
