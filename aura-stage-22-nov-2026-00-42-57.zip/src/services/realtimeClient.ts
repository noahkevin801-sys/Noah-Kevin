import type {
  OnlinePlayerProfile,
  PublicChatRoom,
  ServerWsEvent,
  SharedChatMessage,
  SharedSocialPost,
  SocialPlatform,
  WorldSnapshot,
} from '../types/network';
import type { Artist } from '../types/game';
import {
  generateOfflineAiCommentsForPost,
  generateOfflineAiSocialPost,
} from '../engine/offlineAi';

const WORLD_CACHE_KEY = 'all_starz_world_cache_v1';
const PLAYER_ID_KEY = 'all_starz_player_uid_v1';

export function getOrCreatePlayerId(): string {
  try {
    const existing = localStorage.getItem(PLAYER_ID_KEY);
    if (existing) return existing;
    const fresh = `plr_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    localStorage.setItem(PLAYER_ID_KEY, fresh);
    return fresh;
  } catch {
    return `plr_${Date.now()}`;
  }
}

export function buildDmRoomId(idA: string, idB: string): string {
  return idA < idB ? `dm:${idA}:${idB}` : `dm:${idB}:${idA}`;
}

export function loadCachedWorld(): WorldSnapshot {
  try {
    const raw = localStorage.getItem(WORLD_CACHE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as WorldSnapshot;
      if (parsed && Array.isArray(parsed.posts) && Array.isArray(parsed.chatMessages)) {
        return parsed;
      }
    }
  } catch {
    // ignore
  }
  return {
    players: [],
    posts: [
      generateOfflineAiSocialPost('allgram'),
      generateOfflineAiSocialPost('alltok'),
      generateOfflineAiSocialPost('allx'),
      generateOfflineAiSocialPost('alltub'),
      generateOfflineAiSocialPost('allcloud'),
    ],
    chatMessages: [],
    rooms: [
      {
        id: 'room_global',
        name: 'Salon Général Artistes',
        description: 'Salon principal multi-joueurs (ou IA en mode hors-ligne).',
        badge: 'Live',
      },
      {
        id: 'room_collab',
        name: 'Featurings & Studio',
        description: 'Trouve d’autres artistes pour collaborer.',
        badge: 'Collab',
      },
      {
        id: 'room_promo',
        name: 'Club Promo & Charts',
        description: 'Partage tes sorties Alltify & AllTok.',
        badge: 'Charts',
      },
    ],
  };
}

export function saveCachedWorld(world: WorldSnapshot) {
  try {
    localStorage.setItem(WORLD_CACHE_KEY, JSON.stringify(world));
  } catch {
    // ignore
  }
}

export function getApiBaseUrl(): string {
  const configured = (import.meta.env.VITE_SERVER_URL as string | undefined)?.trim();
  if (configured) {
    return configured.replace(/\/+$/, '');
  }
  return '';
}

function isCapacitorNativeOrigin(): boolean {
  if (typeof window === 'undefined') return false;
  return (
    window.location.protocol === 'capacitor:' ||
    (window.location.hostname === 'localhost' && !window.location.port)
  );
}

export function resolveApiUrl(path: string): string {
  const base = getApiBaseUrl();
  return base ? `${base}${path}` : path;
}

export function getWsUrl(): string | null {
  const base = getApiBaseUrl();
  if (base) {
    const wsBase = base.replace(/^https:/i, 'wss:').replace(/^http:/i, 'ws:');
    return `${wsBase}/ws`;
  }
  if (isCapacitorNativeOrigin()) {
    // Standalone APK sans serveur distant configuré -> bascule fluide en mode IA hors-ligne
    return null;
  }
  const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  return `${proto}//${window.location.host}/ws`;
}

export async function fetchWorldSnapshot(): Promise<WorldSnapshot> {
  if (!getApiBaseUrl() && isCapacitorNativeOrigin()) {
    throw new Error('Offline native APK mode');
  }
  const res = await fetch(resolveApiUrl('/api/world/init'));
  if (!res.ok) throw new Error('Server unavailable');
  return (await res.json()) as WorldSnapshot;
}

export async function sendPresenceHttp(
  playerId: string,
  artist: Artist,
  topSongTitle?: string
): Promise<void> {
  if (!getApiBaseUrl() && isCapacitorNativeOrigin()) return;
  const handle = `@${artist.stageName.toLowerCase().replace(/[^a-z0-9]/g, '') || 'artiste'}`;
  await fetch(resolveApiUrl('/api/world/presence'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      playerId,
      stageName: artist.stageName,
      handle,
      genre: artist.genre,
      avatarUrl: artist.avatarUrl,
      fans: artist.fans,
      monthlyListeners: artist.monthlyListeners,
      totalStreams: artist.totalStreams,
      fame: artist.fame,
      hype: artist.hype,
      topSongTitle,
    }),
  });
}

export async function createPostHttp(payload: {
  id: string;
  platform: SocialPlatform;
  authorId: string;
  authorName: string;
  authorHandle: string;
  authorAvatar: string;
  verified: boolean;
  location?: string;
  tag?: string;
  title?: string;
  content: string;
  mediaTone: string;
  attachedSongTitle?: string;
  videoDuration?: string;
  initialLikes?: number;
}): Promise<SharedSocialPost | null> {
  if (!getApiBaseUrl() && isCapacitorNativeOrigin()) return null;
  const res = await fetch(resolveApiUrl('/api/social/post'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!res.ok) return null;
  const data = (await res.json()) as { post?: SharedSocialPost };
  return data.post ?? null;
}

export async function requestAiChatReply(params: {
  contactName: string;
  contactRole: string;
  userMessage: string;
  artistSummary: string;
}): Promise<string | null> {
  if (!getApiBaseUrl() && isCapacitorNativeOrigin()) return null;
  try {
    const res = await fetch(resolveApiUrl('/api/ai/chat-reply'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as { reply?: string };
    return data.reply ?? null;
  } catch {
    return null;
  }
}

export async function requestAiSocialReact(postId: string): Promise<SharedSocialPost | null> {
  if (!getApiBaseUrl() && isCapacitorNativeOrigin()) return null;
  try {
    const res = await fetch(resolveApiUrl('/api/ai/social-react'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ postId }),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as { post?: SharedSocialPost };
    return data.post ?? null;
  } catch {
    return null;
  }
}

export function applyOfflineAiComment(
  world: WorldSnapshot,
  postId: string,
  artistName: string
): WorldSnapshot {
  const target = world.posts.find((p) => p.id === postId);
  if (!target) return world;
  const newComments = generateOfflineAiCommentsForPost(target, artistName);
  const updated: SharedSocialPost = {
    ...target,
    likes: target.likes + Math.floor(3 + Math.random() * 14),
    comments: [...target.comments, ...newComments],
  };
  return {
    ...world,
    posts: world.posts.map((p) => (p.id === postId ? updated : p)),
  };
}

export function mergeWsEventIntoWorld(
  prev: WorldSnapshot,
  event: ServerWsEvent
): WorldSnapshot {
  switch (event.type) {
    case 'world:init':
      return event.payload;
    case 'players:update':
      return { ...prev, players: event.payload };
    case 'chat:message': {
      if (prev.chatMessages.some((m) => m.id === event.payload.id)) {
        return prev;
      }
      return {
        ...prev,
        chatMessages: [...prev.chatMessages, event.payload].slice(-250),
      };
    }
    case 'social:created': {
      if (prev.posts.some((p) => p.id === event.payload.id)) {
        return prev;
      }
      return {
        ...prev,
        posts: [event.payload, ...prev.posts].slice(0, 120),
      };
    }
    case 'social:updated': {
      const exists = prev.posts.some((p) => p.id === event.payload.id);
      if (!exists) {
        return {
          ...prev,
          posts: [event.payload, ...prev.posts].slice(0, 120),
        };
      }
      return {
        ...prev,
        posts: prev.posts.map((p) => (p.id === event.payload.id ? event.payload : p)),
      };
    }
  }
}

export type { OnlinePlayerProfile, PublicChatRoom, SharedChatMessage, SharedSocialPost, WorldSnapshot };
