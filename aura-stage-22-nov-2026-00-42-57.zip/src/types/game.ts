export type GenreId =
  | 'pop'
  | 'urban'
  | 'hiphop'
  | 'rnb'
  | 'afrobeat'
  | 'electro'
  | 'soul'
  | 'trap'
  | 'indie'
  | 'latin';

export type OriginId = 'bedroom' | 'stage' | 'viral';

export type TabId = 'accueil' | 'music' | 'charts' | 'apps' | 'chat' | 'parametres';

export type AppSubId =
  | 'home'
  | 'alltify'
  | 'allgram'
  | 'alltok'
  | 'allx'
  | 'alltub'
  | 'allcloud'
  | 'allpress'
  | 'allradio'
  | 'tours'
  | 'labels'
  | 'finances'
  | 'awards';

export type ProjectFormat = 'single' | 'ep' | 'mixtape' | 'album' | 'deluxe';

export type CertificationLevel =
  | 'none'
  | 'bronze'
  | 'silver'
  | 'gold'
  | 'platinum'
  | 'multi_platinum'
  | 'diamond';

export type SongLifecyclePhase =
  | 'sortie'
  | 'croissance'
  | 'pic'
  | 'stabilisation'
  | 'declin'
  | 'redecouverte';

export interface ArtistSkills {
  vocals: number;
  writing: number;
  production: number;
  stage: number;
}

export interface Artist {
  stageName: string;
  bio: string;
  genre: GenreId;
  origin: OriginId;
  avatarUrl: string;
  cash: number;
  energy: number;
  maxEnergy: number;
  hype: number; // Popularité 0..100
  reputation: number; // Réputation pro 0..100
  fame: number; // Fame globale 0..100
  fans: number;
  monthlyListeners: number;
  skills: ArtistSkills;
  labelId: string;
  hiredStaffIds: string[];
  dayOffset: number; // 0 = Lundi 30 octobre 2026
  weeksActive: number;
  totalStreams: number;
  totalRevenue: number;
  totalExpenses: number;
  concertsPlayed: number;
}

export interface StudioTier {
  id: string;
  name: string;
  subtitle: string;
  cost: number;
  energyCost: number;
  qualityBonus: number;
  minFans: number;
}

export interface PromoCampaign {
  id: string;
  name: string;
  category: string;
  description: string;
  cost: number;
  hypeGain: number;
  streamMultiplier: number;
}

export interface ClipOption {
  id: string;
  name: string;
  style: string;
  cost: number;
  energyCost: number;
  streamMultiplier: number;
  hypeGain: number;
}

export interface Song {
  id: string;
  title: string;
  genre: GenreId;
  mood: string;
  theme: string;
  vocalStyle: string;
  quality: number;
  studioName: string;
  featuringArtist: string | null;
  released: boolean;
  releaseWeek: number | null;
  releaseDayOffset: number | null;
  weeklyStreams: number;
  dailyStreams: number;
  totalStreams: number;
  streamHistory: number[];
  bestWeekStreams: number;
  revenueEarned: number;
  peakChartPos: number | null;
  currentChartPos: number | null;
  promoApplied: string[];
  promoCount: number;
  hasClip: boolean;
  clipStyle: string | null;
  certification: CertificationLevel;
  lifecyclePhase: SongLifecyclePhase;
  viralBoostWeeks: number;
  projectId?: string | null;
}

export interface MusicProject {
  id: string;
  title: string;
  format: ProjectFormat;
  genre: GenreId;
  trackIds: string[];
  parentAlbumId?: string | null;
  quality: number;
  releaseWeek: number;
  totalStreams: number;
  revenueEarned: number;
  certification: CertificationLevel;
}

export type TransportTier = 'van' | 'bus' | 'flight';
export type LodgingTier = 'standard' | 'comfort' | 'luxury';
export type ProductionTier = 'acoustic' | 'club' | 'arena_show';
export type TourDateStatus = 'scheduled' | 'postponed' | 'played' | 'cancelled';
export type TourContinent =
  | 'Europe'
  | 'Amérique du Nord'
  | 'Asie'
  | 'Océanie'
  | 'Amérique du Sud'
  | 'Afrique';

export interface TourCityDestination {
  id: string;
  name: string;
  country: string;
  countryCode: string;
  continent: TourContinent;
  lat: number;
  lng: number;
  region: 'france' | 'europe' | 'monde';
}

export interface ConcertVenue {
  id: string;
  cityId?: string;
  name: string;
  city: string;
  country?: string;
  countryCode?: string;
  continent?: TourContinent;
  region?: 'france' | 'europe' | 'monde';
  lat?: number;
  lng?: number;
  showType: string;
  capacity: number;
  bookingCost: number;
  energyCost: number;
  minFans: number;
  recommendedPrice: number;
  prestigeGain: number;
}

export interface ConcertCostBreakdown {
  venueCost: number;
  transportCost: number;
  lodgingCost: number;
  crewCost: number;
  productionCost: number;
  totalCost: number;
}

export interface ConcertLog {
  id: string;
  week: number;
  dayOffset?: number;
  venueName: string;
  city: string;
  country?: string;
  showType: string;
  tourId?: string;
  tourName?: string;
  attendance: number;
  capacity: number;
  ticketPrice: number;
  ticketRevenue?: number;
  merchRevenue?: number;
  grossRevenue: number;
  costs?: ConcertCostBreakdown;
  netProfit: number;
  fansGained: number;
  hypeGained: number;
  satisfaction: number;
}

export interface TourDateItem {
  id: string;
  venueId: string;
  cityId?: string;
  venueName: string;
  city: string;
  country: string;
  continent?: TourContinent;
  showType: string;
  capacity: number;
  dayOffset: number;
  ticketPrice: number;
  ticketsSold: number;
  status: TourDateStatus;
  transportTier: TransportTier;
  lodgingTier: LodgingTier;
  productionTier: ProductionTier;
  report?: ConcertLog | null;
}

export interface Tour {
  id: string;
  name: string;
  scope: 'locale' | 'nationale' | 'internationale' | 'custom';
  status?: 'draft' | 'active' | 'completed';
  dates?: TourDateItem[];
  defaultTransportTier?: TransportTier;
  defaultLodgingTier?: LodgingTier;
  defaultProductionTier?: ProductionTier;
  totalDates: number;
  completedDates: number;
  venueId: string;
  ticketPrice: number;
  totalAttendance: number;
  totalRevenue?: number;
  totalExpenses?: number;
  totalProfit: number;
  active: boolean;
  createdDayOffset?: number;
}

export interface MerchItem {
  id: string;
  name: string;
  category: string;
  unlockCost: number;
  unitPrice: number;
  unitMargin: number;
  minFans: number;
  unlocked: boolean;
  unitsSold: number;
}

export interface StaffMember {
  id: string;
  role: string;
  name: string;
  specialty: string;
  weeklySalary: number;
  hireCost: number;
  minMonthlyListeners: number;
  bonusDescription: string;
}

export interface LabelOffer {
  id: string;
  name: string;
  tier: string;
  description: string;
  royaltyRate: number;
  signingAdvance: number;
  weeklyPromoSupport: number;
  streamBonus: number;
  minMonthlyListeners: number;
}

export interface ChartEntry {
  id: string;
  rank: number;
  previousRank: number | null;
  title: string;
  artistName: string;
  genre: GenreId;
  weeklyStreams: number;
  isPlayer: boolean;
  weeksOnChart: number;
  coverTone: string;
}

export interface BuzzPost {
  id: string;
  authorName: string;
  authorHandle: string;
  isPlayer: boolean;
  isRival?: boolean;
  week: number;
  content: string;
  tag?: string;
  likes: number;
  comments: number;
  shares: number;
  likedByPlayer: boolean;
  sampleComments: Array<{ user: string; text: string }>;
}

export interface AllTubVideo {
  id: string;
  title: string;
  channelName: string;
  videoType: 'Clip Officiel' | 'Session Studio' | 'Live Performance' | 'Interview';
  songId?: string;
  views: number;
  likes: number;
  week: number;
  isPlayer: boolean;
}

export interface StreamNewsItem {
  id: string;
  dateLabel: string;
  title: string;
  detail: string;
  category: 'streams' | 'chart' | 'industry' | 'milestone';
  deltaText?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'player' | 'contact';
  text: string;
  timeLabel: string;
}

export interface ChatThread {
  id: string;
  contactId: string;
  contactName: string;
  contactRole: string;
  contactHandle: string;
  unread: boolean;
  messages: ChatMessage[];
}

export interface FinancialEntry {
  id: string;
  week: number;
  label: string;
  category: 'streaming' | 'concert' | 'merch' | 'studio' | 'promo' | 'label' | 'event';
  amount: number;
}

export interface NotificationItem {
  id: string;
  week: number;
  title: string;
  message: string;
  category: 'music' | 'chart' | 'event' | 'live' | 'finance' | 'social';
  targetTab: TabId;
  targetApp?: AppSubId;
  read: boolean;
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  rewardCash: number;
  rewardHype: number;
  targetValue: number;
  currentValue: number;
  completed: boolean;
  claimed: boolean;
}

export type EventCategory =
  | 'collaboration'
  | 'tour'
  | 'press'
  | 'industry'
  | 'viral'
  | 'health';

export type EventSentiment = 'positive' | 'negative' | 'dilemma';

export interface EventOutcomeDelta {
  cash?: number;
  fans?: number;
  hype?: number;
  fame?: number;
  energy?: number;
  reputation?: number;
  skillBoost?: Partial<ArtistSkills>;
  activeTrackStreamMultiplier?: number;
  autoReleaseCollabTitle?: string;
}

export interface EventChoice {
  id: string;
  label: string;
  summary: string;
  costCash?: number;
  costEnergy?: number;
  requiresMinFans?: number;
  outcomeText: string;
  sentimentResult: 'positive' | 'negative' | 'neutral';
  delta: EventOutcomeDelta;
}

export interface RandomEvent {
  id: string;
  templateId: string;
  week: number;
  title: string;
  description: string;
  category: EventCategory;
  sentiment: EventSentiment;
  contextSubject?: string;
  choices: EventChoice[];
}

export interface EventHistoryEntry {
  id: string;
  week: number;
  title: string;
  category: EventCategory;
  chosenLabel: string;
  outcomeText: string;
  sentimentResult: 'positive' | 'negative' | 'neutral';
  cashDelta: number;
  fansDelta: number;
  hypeDelta: number;
}

export interface WeeklySummary {
  week: number;
  streamsGained: number;
  streamingRevenue: number;
  merchRevenue: number;
  upkeepCost: number;
  netCashDelta: number;
  fansGained: number;
  newCertifications: Array<{ title: string; level: CertificationLevel }>;
  chartHighlight: string | null;
  triggeredEventTitle: string | null;
}

export interface AwardTrophy {
  id: string;
  year: number;
  ceremony: string;
  title: string;
  category: string;
  workTitle: string;
}

export interface GameState {
  version: number;
  artist: Artist;
  songs: Song[];
  projects: MusicProject[];
  concerts: ConcertLog[];
  activeTour: Tour | null;
  tourHistory?: Tour[];
  merch: MerchItem[];
  charts: ChartEntry[];
  buzzPosts: BuzzPost[];
  allTubVideos: AllTubVideo[];
  streamNews: StreamNewsItem[];
  chatThreads: ChatThread[];
  finances: FinancialEntry[];
  notifications: NotificationItem[];
  claimedMissionIds: string[];
  pendingEvent: RandomEvent | null;
  eventHistory: EventHistoryEntry[];
  lastWeeklySummary: WeeklySummary | null;
  awards: AwardTrophy[];
  cooldownEventTemplates: Record<string, number>;
  lastEventWeek: number;
}
