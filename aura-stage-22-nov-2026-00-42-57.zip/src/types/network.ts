import { GenreId } from './game';

export type SocialPlatform = 'allgram' | 'alltok' | 'allx' | 'alltub' | 'allcloud';

export interface OnlinePlayerProfile {
  playerId: string;
  stageName: string;
  handle: string;
  genre: GenreId;
  avatarUrl: string;
  fans: number;
  monthlyListeners: number;
  totalStreams?: number;
  fame?: number;
  hype?: number;
  verified: boolean;
  isOnline: boolean;
  lastSeenAt: number;
  topSongTitle?: string;
}

export interface SharedComment {
  id: string;
  authorId: string;
  authorName: string;
  authorHandle: string;
  authorAvatar?: string;
  isAi?: boolean;
  text: string;
  createdAt: number;
}

export interface SharedSocialPost {
  id: string;
  platform: SocialPlatform;
  authorId: string;
  authorName: string;
  authorHandle: string;
  authorAvatar: string;
  verified: boolean;
  isPlayer: boolean;
  isAi?: boolean;
  location?: string;
  tag?: string;
  title?: string; // AllTub / AllCloud
  content: string;
  mediaTone: string;
  attachedSongTitle?: string;
  videoDuration?: string;
  likes: number;
  likedByIds: string[];
  reposts: number;
  repostedByIds: string[];
  views: number;
  comments: SharedComment[];
  createdAt: number;
}

export interface SharedChatMessage {
  id: string;
  roomId: string; // 'room_global' | 'room_collab' | 'room_promo' | 'dm:<idA>:<idB>'
  senderId: string;
  senderName: string;
  senderHandle: string;
  senderAvatar: string;
  isAi?: boolean;
  text: string;
  createdAt: number;
}

export interface PublicChatRoom {
  id: string;
  name: string;
  description: string;
  badge: string;
}

export interface WorldSnapshot {
  players: OnlinePlayerProfile[];
  posts: SharedSocialPost[];
  chatMessages: SharedChatMessage[];
  rooms: PublicChatRoom[];
}

export type ServerWsEvent =
  | { type: 'world:init'; payload: WorldSnapshot }
  | { type: 'players:update'; payload: OnlinePlayerProfile[] }
  | { type: 'chat:message'; payload: SharedChatMessage }
  | { type: 'social:created'; payload: SharedSocialPost }
  | { type: 'social:updated'; payload: SharedSocialPost };
