import { CertificationLevel, GenreId, ProjectFormat, SongLifecyclePhase } from '../types/game';

export function formatCurrency(amount: number): string {
  const rounded = Math.round(amount);
  return new Intl.NumberFormat('fr-FR', {
    style: 'currency',
    currency: 'EUR',
    maximumFractionDigits: 0,
  }).format(rounded);
}

export function formatCompactNumber(num: number): string {
  const n = Math.round(num);
  if (n >= 1_000_000_000) {
    return `${(n / 1_000_000_000).toFixed(2).replace('.', ',')} Md`;
  }
  if (n >= 1_000_000) {
    return `${(n / 1_000_000).toFixed(2).replace('.', ',')} M`;
  }
  if (n >= 10_000) {
    return `${(n / 1_000).toFixed(1).replace('.', ',')} k`;
  }
  return new Intl.NumberFormat('fr-FR').format(n);
}

export function formatFullNumber(num: number): string {
  return new Intl.NumberFormat('fr-FR').format(Math.round(num));
}

// Base date: Lundi 30 octobre 2026 (aligned with user's wireframe!)
const BASE_DATE_MS = new Date(2026, 9, 30, 12, 0, 0).getTime();

export function formatGameDate(dayOffset: number): string {
  const d = new Date(BASE_DATE_MS + dayOffset * 86_400_000);
  const formatted = new Intl.DateTimeFormat('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(d);
  return formatted.charAt(0).toUpperCase() + formatted.slice(1);
}

export function formatShortDate(dayOffset: number): string {
  const d = new Date(BASE_DATE_MS + dayOffset * 86_400_000);
  return new Intl.DateTimeFormat('fr-FR', {
    day: 'numeric',
    month: 'short',
  }).format(d);
}

export function formatWeekLabel(weeksActive: number): string {
  const year = Math.floor((weeksActive - 1) / 52) + 1;
  const weekInYear = ((weeksActive - 1) % 52) + 1;
  return `An ${year} · Sem. ${weekInYear}`;
}

export function getCareerRank(monthlyListeners: number): {
  step: number;
  title: string;
  nextThreshold: number | null;
} {
  if (monthlyListeners < 5_000) {
    return { step: 1, title: 'Débutant', nextThreshold: 5_000 };
  }
  if (monthlyListeners < 50_000) {
    return { step: 2, title: 'Artiste émergent', nextThreshold: 50_000 };
  }
  if (monthlyListeners < 350_000) {
    return { step: 3, title: 'Artiste confirmé', nextThreshold: 350_000 };
  }
  if (monthlyListeners < 2_500_000) {
    return { step: 4, title: 'Superstar', nextThreshold: 2_500_000 };
  }
  return { step: 5, title: 'Icône mondiale', nextThreshold: null };
}

export function getFanbaseTier(fans: number): string {
  if (fans < 400) return 'Auditeur occasionnel';
  if (fans < 2_000) return 'Curieux';
  if (fans < 15_000) return 'Fan';
  if (fans < 80_000) return 'Fan fidèle';
  if (fans < 400_000) return 'Superfan';
  return 'Fan historique';
}

export function getCertificationLabel(level: CertificationLevel): string {
  switch (level) {
    case 'diamond':
      return 'Diamant';
    case 'multi_platinum':
      return 'Multi-Platine';
    case 'platinum':
      return 'Platine';
    case 'gold':
      return 'Or';
    case 'silver':
      return 'Argent';
    case 'bronze':
      return 'Bronze';
    default:
      return 'Non certifié';
  }
}

export function getLifecycleLabel(phase: SongLifecyclePhase): string {
  switch (phase) {
    case 'sortie':
      return 'Sortie';
    case 'croissance':
      return 'Croissance';
    case 'pic':
      return 'Pic d’écoutes';
    case 'stabilisation':
      return 'Stabilisation';
    case 'declin':
      return 'Déclin progressif';
    case 'redecouverte':
      return 'Redécouverte';
  }
}

export function getProjectFormatLabel(format: ProjectFormat): string {
  switch (format) {
    case 'single':
      return 'Single';
    case 'ep':
      return 'EP';
    case 'mixtape':
      return 'Mixtape';
    case 'album':
      return 'Album';
    case 'deluxe':
      return 'Édition Deluxe';
  }
}

export function getGenreLabel(genre: GenreId): string {
  switch (genre) {
    case 'pop':
      return 'Pop';
    case 'urban':
      return 'Rap';
    case 'hiphop':
      return 'Hip-hop';
    case 'rnb':
      return 'R&B';
    case 'afrobeat':
      return 'Afrobeat';
    case 'electro':
      return 'Électro';
    case 'soul':
      return 'Soul';
    case 'trap':
      return 'Trap';
    case 'indie':
      return 'Rock / Indé';
    case 'latin':
      return 'Latin';
  }
}
